//! Platform-independent shaped text geometry consumed by editors and selection widgets.
use crate::scene::Rect;
use std::ops::Range;
use unicode_segmentation::UnicodeSegmentation;
/// Portable font selection. Named families fall back through the platform font database.
#[derive(Clone, Debug, Default, PartialEq, Eq, Hash)]
pub enum FontFamily {
    #[default]
    SansSerif,
    Serif,
    Monospace,
    Named(std::sync::Arc<str>),
}
impl From<&str> for FontFamily {
    fn from(value: &str) -> Self {
        Self::Named(value.into())
    }
}
impl From<String> for FontFamily {
    fn from(value: String) -> Self {
        Self::Named(value.into())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct FontStyle {
    pub family: FontFamily,
    /// OpenType weight in the inclusive range 1..=1000 (400 regular, 700 bold).
    pub weight: u16,
    pub italic: bool,
}
impl Default for FontStyle {
    fn default() -> Self {
        Self {
            family: FontFamily::SansSerif,
            weight: 400,
            italic: false,
        }
    }
}
/// Font-aware shaping callback. The legacy TextShaper remains available for default fonts.
pub trait FontTextShaper {
    fn shape(
        &self,
        text: &str,
        size: f32,
        width: Option<f32>,
        font: &FontStyle,
    ) -> Box<dyn TextLayout>;
}
impl<F: Fn(&str, f32, Option<f32>, &FontStyle) -> Box<dyn TextLayout>> FontTextShaper for F {
    fn shape(
        &self,
        text: &str,
        size: f32,
        width: Option<f32>,
        font: &FontStyle,
    ) -> Box<dyn TextLayout> {
        self(text, size, width, font)
    }
}
pub trait TextLayout {
    fn size(&self) -> (f32, f32);
    /// Returns a UTF-8 byte offset on a grapheme boundary.
    fn hit_test(&self, x: f32, y: f32) -> usize;
    fn caret(&self, byte_offset: usize) -> Rect;
    /// Visual spans may be disjoint for bidirectional text.
    fn selection(&self, range: Range<usize>) -> Vec<Rect>;
}
pub trait TextShaper {
    fn shape(&self, text: &str, font_size: f32, max_width: Option<f32>) -> Box<dyn TextLayout>;
}
impl<F: Fn(&str, f32, Option<f32>) -> Box<dyn TextLayout>> TextShaper for F {
    fn shape(&self, text: &str, font_size: f32, max_width: Option<f32>) -> Box<dyn TextLayout> {
        self(text, font_size, max_width)
    }
}
/// Approximate grapheme cells for headless/core use. Native hosts install a real shaper.
pub struct FallbackTextLayout {
    cells: Vec<(Range<usize>, Rect)>,
    end: Rect,
    size: (f32, f32),
}
impl FallbackTextLayout {
    pub fn new(text: &str, size: f32, max_width: Option<f32>) -> Self {
        let advance = size.max(1.) * 0.6;
        let height = (size.max(1.) * 1.4).ceil();
        let mut x = 0.;
        let mut y = 0.;
        let mut width = 0_f32;
        let mut cells = Vec::new();
        for (index, grapheme) in text.grapheme_indices(true) {
            if grapheme.contains(['\n', '\r']) {
                cells.push((index..index + grapheme.len(), Rect::new(x, y, 0., height)));
                width = width.max(x);
                x = 0.;
                y += height;
                continue;
            }
            if max_width.is_some_and(|w| w > 0. && x > 0. && x + advance > w) {
                width = width.max(x);
                x = 0.;
                y += height
            }
            cells.push((
                index..index + grapheme.len(),
                Rect::new(x, y, advance, height),
            ));
            x += advance;
        }
        width = width.max(x);
        Self {
            cells,
            end: Rect::new(x, y, 1., height),
            size: (width, y + height),
        }
    }
}
impl TextLayout for FallbackTextLayout {
    fn size(&self) -> (f32, f32) {
        self.size
    }
    fn hit_test(&self, x: f32, y: f32) -> usize {
        let mut result = 0;
        for (range, r) in &self.cells {
            if y >= r.y && y < r.y + r.height {
                if x < r.x + r.width * 0.5 {
                    return range.start;
                }
                result = range.end;
            } else if y >= r.y + r.height {
                result = range.end;
            }
        }
        result
    }
    fn caret(&self, byte_offset: usize) -> Rect {
        for (range, r) in &self.cells {
            if byte_offset <= range.start || range.contains(&byte_offset) {
                return Rect::new(r.x, r.y, 1., r.height);
            }
        }
        self.end
    }
    fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        let start = range.start.min(range.end);
        let end = range.start.max(range.end);
        let mut result: Vec<Rect> = Vec::new();
        for (index, r) in &self.cells {
            if index.start < end && index.end > start && r.width > 0. {
                if let Some(last) = result.last_mut()
                    && last.y == r.y
                    && last.x + last.width >= r.x
                {
                    *last = last.union(*r);
                    continue;
                }
                result.push(*r);
            }
        }
        result
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn grapheme_offsets_newlines_and_wrap() {
        let layout = FallbackTextLayout::new("e\u{301}👩‍💻\nx", 10., None);
        assert_eq!(layout.hit_test(1., 2.), 0);
        assert_eq!(layout.hit_test(8., 2.), 3);
        assert_eq!(layout.caret(3).x, 6.);
        assert_eq!(layout.selection(0..3).len(), 1);
        assert_eq!(layout.size().1, 28.);
    }
}
