//! Placement for a retained popover portal; ownership and focus live in compose_modal.
use crate::{
    scene::{NodeId, Rect, Transform},
    widgets::Ui,
};

/// Position the private placement host, preserving the public panel's styles.
/// Registrations belong to the logical owner so disposal removes subscriptions.
pub(crate) fn mount(
    ui: &mut Ui,
    owner: NodeId,
    anchor: NodeId,
    overlay: NodeId,
    position: NodeId,
    panel: NodeId,
) {
    let anchor_bounds = ui.observe_bounds(anchor);
    let viewport = ui.observe_bounds(overlay);
    let panel_bounds = ui.observe_bounds(panel);
    let position_bounds = ui.observe_bounds(position);
    let weak = ui.downgrade();
    ui.bind(owner, move || {
        let anchor = anchor_bounds.get();
        let viewport = viewport.get();
        let panel = panel_bounds.get();
        let current = position_bounds.get();
        let desired = placement(anchor, viewport, panel.width, panel.height);
        let Some(ui) = weak.upgrade() else {
            return;
        };
        let mut scene = ui.scene.borrow_mut();
        if !scene.contains(position) {
            return;
        }
        let previous = scene.transform(position);
        let dx = desired.0 - current.x;
        let dy = desired.1 - current.y;
        // Avoid introducing an allocation feedback cycle through float rounding.
        if dx.abs() > 0.01 || dy.abs() > 0.01 {
            scene.set_transform(
                position,
                Transform {
                    x: previous.x + dx,
                    y: previous.y + dy,
                },
            );
        }
    });
}

fn placement(anchor: Rect, viewport: Rect, width: f32, height: f32) -> (f32, f32) {
    let right = viewport.x + viewport.width;
    let bottom = viewport.y + viewport.height;
    let below = anchor.y + anchor.height + 4.;
    let above = anchor.y - height - 4.;
    let y = if below + height > bottom && above >= viewport.y {
        above
    } else {
        below
    };
    (
        anchor.x.clamp(viewport.x, (right - width).max(viewport.x)),
        y.clamp(viewport.y, (bottom - height).max(viewport.y)),
    )
}
