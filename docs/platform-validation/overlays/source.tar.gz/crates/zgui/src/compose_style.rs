//! Styling lowered onto retained nodes; state changes preserve mounted children.
use crate::{
    input::{EventPhase, InputEvent, Key, PointerButton},
    reactive::Signal,
    scene::{Color, NodeId, NodeKind, QuadStyle},
    style::Styles,
    widgets::Ui,
};

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct Typography {
    pub color: Color,
    pub size: f32,
    pub wrap: bool,
    pub font: crate::text_layout::FontStyle,
}
#[derive(Default)]
pub(crate) struct Variants {
    pub hover: Option<Styles>,
    pub active: Option<Styles>,
    pub focus: Option<Styles>,
    pub disabled: Option<Styles>,
}
#[derive(Clone, Copy, Default, PartialEq)]
struct Interaction {
    hover: bool,
    active: bool,
    focus: bool,
}

#[cfg(test)]
#[allow(clippy::too_many_arguments)]
pub(crate) fn mount_style(
    ui: &mut Ui,
    node: NodeId,
    base: Styles,
    inherited: Signal<Typography>,
    dynamic: Option<Box<dyn FnMut() -> Styles>>,
    variants: Variants,
    disabled: Option<Box<dyn FnMut() -> bool>>,
    interactive: bool,
) -> Signal<Typography> {
    mount_style_with_intrinsic(
        ui,
        node,
        base,
        inherited,
        dynamic,
        variants,
        disabled,
        interactive,
        None,
    )
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn mount_style_with_intrinsic(
    ui: &mut Ui,
    node: NodeId,
    base: Styles,
    inherited: Signal<Typography>,
    mut dynamic: Option<Box<dyn FnMut() -> Styles>>,
    variants: Variants,
    mut disabled: Option<Box<dyn FnMut() -> bool>>,
    interactive: bool,
    intrinsic: Option<Signal<(f32, f32)>>,
) -> Signal<Typography> {
    let typography = ui.signal(inherited.with_untracked(Clone::clone));
    let output = typography.clone();
    let interaction = ui.signal(Interaction::default());
    if interactive
        || variants.hover.is_some()
        || variants.active.is_some()
        || variants.focus.is_some()
    {
        let interaction = interaction.clone();
        ui.on_event(node, interactive, move |event| {
            if event.phase == EventPhase::Capture {
                return;
            }
            interaction.update(|state| match event.event {
                InputEvent::PointerEnter => state.hover = true,
                InputEvent::PointerLeave => {
                    state.hover = false;
                    state.active = false;
                }
                InputEvent::PointerDown {
                    button: PointerButton::Primary,
                    ..
                } => {
                    state.active = true;
                    if event.target == node {
                        event.capture_pointer();
                    }
                }
                InputEvent::PointerUp {
                    button: PointerButton::Primary,
                    ..
                }
                | InputEvent::PointerCancel => state.active = false,
                InputEvent::Focus if event.target == node => state.focus = true,
                InputEvent::Blur if event.target == node => {
                    state.focus = false;
                    state.active = false;
                }
                InputEvent::KeyDown {
                    key: Key::Space | Key::Enter,
                    ..
                } if event.target == node => state.active = true,
                InputEvent::KeyUp {
                    key: Key::Space | Key::Enter,
                    ..
                } if event.target == node => state.active = false,
                _ => {}
            });
        });
    }
    let weak = ui.downgrade();
    let original_style = ui.scene.borrow().style(node);
    let original_effects = ui.scene.borrow().effects(node);
    let original_transform = ui.scene.borrow().transform(node);
    let original_isolated = ui.scene.borrow().is_isolated(node);
    let original_kind = ui.scene.borrow().kind(node).clone();
    let mut previous_disabled = None;
    ui.bind(node, move || {
        let Some(mut ui) = weak.upgrade() else { return };
        if !ui.scene.borrow().contains(node) { return; }
        let mut resolved = base.clone();
        if let Some(dynamic) = &mut dynamic { resolved.merge(&dynamic()); }
        let state = interaction.get();
        let is_disabled = disabled.as_mut().is_some_and(|read| read());
        for (enabled, variant) in [(!is_disabled && state.hover, &variants.hover), (!is_disabled && state.active, &variants.active), (!is_disabled && state.focus, &variants.focus), (is_disabled, &variants.disabled)] {
            if enabled && let Some(variant) = variant { resolved.merge(variant); }
        }
        if disabled.is_some() && previous_disabled != Some(is_disabled) {
            previous_disabled = Some(is_disabled);
            ui.runtime.clone().untracked(|| ui.set_disabled(node, is_disabled));
        }
        // Only observe inherited typography when a field is actually inherited.
        let parent = if resolved.text_color.is_none() || resolved.text_size.is_none() || resolved.text_wrap.is_none() || resolved.font_family.is_none() || resolved.font_weight.is_none() || resolved.italic.is_none() {
            inherited.get()
        } else {
            inherited.with_untracked(Clone::clone)
        };
        let current = Typography { color: resolved.text_color.unwrap_or(parent.color), size: resolved.text_size.unwrap_or(parent.size), wrap: resolved.text_wrap.unwrap_or(parent.wrap), font: crate::text_layout::FontStyle { family: resolved.font_family.clone().unwrap_or(parent.font.family), weight: resolved.font_weight.unwrap_or(parent.font.weight), italic: resolved.italic.unwrap_or(parent.font.italic) } };
        output.set(current.clone());
        let mut style = original_style;
        macro_rules! field { ($($field:ident),* $(,)?) => { $(if let Some(value) = resolved.$field { style.$field = value; })* }; }
        macro_rules! dimension { ($($field:ident),* $(,)?) => { $(if let Some(value) = resolved.$field { style.$field = Some(value); })* }; }
        dimension!(width,height,min_width,max_width,min_height,max_height);
        field!(absolute,gap,clip,flex_grow,flex_shrink,align,justify,text_wrap,margin);
        if matches!(original_kind, NodeKind::Text { .. }) { style.text_wrap = current.wrap; }
        if let Some(padding) = resolved.padding { style.padding_edges = Some(padding); }
        if let Some(intrinsic) = &intrinsic {
            let (width, height) = intrinsic.get();
            let padding = style.padding_edges.unwrap_or(crate::scene::Insets::all(style.padding));
            if resolved.width.is_none() { style.width = Some(width + padding.left.max(0.) + padding.right.max(0.)); }
            if resolved.height.is_none() { style.height = Some(height + padding.top.max(0.) + padding.bottom.max(0.)); }
        }

        let mut effects = original_effects;
        if let Some(value) = resolved.opacity { effects.opacity = value; }
        if let Some(value) = resolved.blur { effects.blur_radius = value; }
        if let Some(value) = resolved.edge_fade { effects.edge_fade = value; }
        let mut scene = ui.scene.borrow_mut();
        scene.set_style(node, style);
        scene.set_effects(node, effects);
        scene.set_transform(node, resolved.transform.unwrap_or(original_transform));
        scene.set_isolated(node, resolved.isolated.unwrap_or(original_isolated));
        let kind = match &original_kind {
            NodeKind::Container(layout) | NodeKind::Panel { layout, .. } => {
                let mut quad = match original_kind { NodeKind::Panel { quad, .. } => quad, _ => QuadStyle::default() };
                if let Some(value) = resolved.background { quad.fill = value; }
                if let Some(value) = resolved.radius { quad.radius = value; }
                if let Some(value) = resolved.border_color { quad.border_color = value; }
                if let Some(value) = resolved.border_width { quad.border_width = value; }
                if let Some(value) = resolved.shadow { quad.shadow = value; }
                if quad == QuadStyle::default() { NodeKind::Container(resolved.layout.unwrap_or(*layout)) }
                else { NodeKind::Panel { layout: resolved.layout.unwrap_or(*layout), quad } }
            }
            NodeKind::Text { .. } => match scene.kind(node) {
                NodeKind::Text { text, .. } => NodeKind::Text { text: text.clone(), color: current.color, font_size: current.size },
                kind => kind.clone(),
            },
            _ => scene.kind(node).clone(),
        };
        if matches!(kind, NodeKind::Text { .. }) { scene.set_font(node, current.font); }
        scene.set_kind(node, kind);
    });
    typography
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scene::{Layout, Style};
    fn color(value: u8) -> Styles {
        Styles {
            background: Some(Color(value, 0, 0, 255)),
            ..Default::default()
        }
    }
    fn fill(ui: &Ui, node: NodeId) -> Color {
        match ui.scene.borrow().kind(node) {
            NodeKind::Panel { quad, .. } => quad.fill,
            _ => panic!("expected panel"),
        }
    }
    fn inherited(ui: &Ui) -> Signal<Typography> {
        ui.signal(Typography {
            color: Color(255, 255, 255, 255),
            size: 16.,
            wrap: false,
            font: Default::default(),
        })
    }
    #[test]
    fn interaction_variants_restore_and_disabled_wins_without_layout() {
        let mut ui = Ui::new(100., 100.);
        let node = ui.container(
            ui.root(),
            Layout::Column,
            Style {
                width: Some(50.),
                height: Some(50.),
                ..Default::default()
            },
        );
        let disabled = ui.signal(false);
        let read_disabled = disabled.clone();
        let inherited = inherited(&ui);
        mount_style(
            &mut ui,
            node,
            color(1),
            inherited,
            None,
            Variants {
                hover: Some(color(2)),
                active: Some(color(3)),
                focus: Some(Styles {
                    border_width: Some(2.),
                    ..Default::default()
                }),
                disabled: Some(color(4)),
            },
            Some(Box::new(move || read_disabled.get())),
            true,
        );
        ui.scene.borrow_mut().flush();
        ui.dispatch(InputEvent::PointerMove { x: 10., y: 10. });
        assert_eq!(fill(&ui, node), Color(2, 0, 0, 255));
        ui.dispatch(InputEvent::PointerDown {
            x: 10.,
            y: 10.,
            button: PointerButton::Primary,
        });
        assert_eq!(fill(&ui, node), Color(3, 0, 0, 255));
        assert_eq!(ui.input.focused(), Some(node));
        assert!(
            matches!(ui.scene.borrow().kind(node), NodeKind::Panel { quad, .. } if quad.border_width == 2.)
        );
        assert_eq!(ui.scene.borrow_mut().flush().layout_nodes, 0);
        disabled.set(true);
        assert_eq!(fill(&ui, node), Color(4, 0, 0, 255));
        assert_eq!(ui.input.focused(), None);
        assert!(
            matches!(ui.scene.borrow().kind(node), NodeKind::Panel { quad, .. } if quad.border_width == 0.)
        );
        assert!(ui.semantics.borrow().get(node).unwrap().disabled);
        disabled.set(false);
        assert_eq!(fill(&ui, node), Color(2, 0, 0, 255));
        ui.dispatch(InputEvent::PointerLeave);
        assert_eq!(fill(&ui, node), Color(1, 0, 0, 255));
    }
    #[test]
    fn typography_inherits_and_explicit_overrides_are_stable() {
        let mut ui = Ui::new(100., 100.);
        let parent = inherited(&ui);
        let text = ui.label(ui.root(), "retained", Style::default());
        let output = mount_style(
            &mut ui,
            text,
            Styles::default(),
            parent.clone(),
            None,
            Variants::default(),
            None,
            false,
        );
        let explicit = ui.label(ui.root(), "fixed", Style::default());
        let fixed = Typography {
            color: Color(12, 34, 56, 255),
            size: 20.,
            wrap: false,
            font: Default::default(),
        };
        let stable = mount_style(
            &mut ui,
            explicit,
            Styles {
                text_color: Some(fixed.color),
                text_size: Some(fixed.size),
                ..Default::default()
            },
            parent.clone(),
            None,
            Variants::default(),
            None,
            false,
        );
        ui.scene.borrow_mut().flush();
        parent.set(Typography {
            color: Color(1, 2, 3, 255),
            size: 16.,
            wrap: false,
            font: Default::default(),
        });
        assert_eq!(output.get().color, Color(1, 2, 3, 255));
        assert_eq!(stable.get(), fixed);
        assert_eq!(ui.scene.borrow_mut().flush().layout_nodes, 0);
        parent.set(Typography {
            color: Color(1, 2, 3, 255),
            size: 24.,
            wrap: false,
            font: Default::default(),
        });
        assert_eq!(output.get().size, 24.);
        assert_eq!(stable.get(), fixed);
        assert!(ui.scene.borrow_mut().flush().layout_nodes > 0);
    }
    #[test]
    fn removing_dynamic_properties_restores_base_and_inheritance() {
        let mut ui = Ui::new(100., 100.);
        let node = ui.container(ui.root(), Layout::Row, Style::default());
        let toggled = ui.signal(true);
        let read = toggled.clone();
        let parent = inherited(&ui);
        let output = mount_style(
            &mut ui,
            node,
            color(1),
            parent.clone(),
            Some(Box::new(move || {
                if read.get() {
                    Styles {
                        background: Some(Color(9, 0, 0, 255)),
                        text_size: Some(40.),
                        opacity: Some(0.5),
                        ..Default::default()
                    }
                } else {
                    Styles::default()
                }
            })),
            Variants::default(),
            None,
            false,
        );
        assert_eq!(output.get().size, 40.);
        assert_eq!(fill(&ui, node), Color(9, 0, 0, 255));
        toggled.set(false);
        assert_eq!(output.get().size, 16.);
        assert_eq!(fill(&ui, node), Color(1, 0, 0, 255));
        assert_eq!(ui.scene.borrow().effects(node).opacity, 1.);
        parent.set(Typography {
            size: 20.,
            ..parent.get()
        });
        assert_eq!(output.get().size, 20.);
    }
    #[test]
    fn styled_noninteractive_child_preserves_button_activation() {
        use crate::{
            compose::{button, text},
            style::Styled,
        };
        let mut ui = Ui::new(120., 80.);
        let clicks = ui.signal(0);
        let write = clicks.clone();
        ui.mount(
            button()
                .size(100., 60.)
                .child(text("Child").hover(|s| s.text_color(Color(255, 0, 0, 255))))
                .on_click(move || {
                    write.update(|count| *count += 1);
                }),
        );
        ui.dispatch(InputEvent::PointerMove { x: 15., y: 15. });
        ui.dispatch(InputEvent::PointerDown {
            x: 15.,
            y: 15.,
            button: PointerButton::Primary,
        });
        ui.dispatch(InputEvent::PointerUp {
            x: 15.,
            y: 15.,
            button: PointerButton::Primary,
        });
        assert_eq!(clicks.get(), 1);
    }
    #[test]
    fn nested_button_activation_stops_at_nearest_clickable_owner() {
        use crate::{
            compose::{button, text},
            style::Styled,
        };
        let mut ui = Ui::new(140., 100.);
        let outer = ui.signal(0);
        let inner = ui.signal(0);
        let outer_write = outer.clone();
        let inner_write = inner.clone();
        let mounted = ui.mount(
            button()
                .size(120., 80.)
                .p(0.)
                .on_click(move || {
                    outer_write.update(|n| *n += 1);
                })
                .child(
                    button()
                        .id("inner")
                        .size(80., 40.)
                        .on_click(move || {
                            inner_write.update(|n| *n += 1);
                        })
                        .child(text("Inner").hover(|s| s.opacity(0.8))),
                ),
        );
        ui.scene.borrow_mut().prepare_layout();
        let bounds = ui.scene.borrow().bounds(mounted.find("inner").unwrap());
        let x = bounds.x + 15.;
        let y = bounds.y + 15.;
        ui.dispatch(InputEvent::PointerMove { x, y });
        ui.dispatch(InputEvent::PointerDown {
            x,
            y,
            button: PointerButton::Primary,
        });
        ui.dispatch(InputEvent::PointerUp {
            x,
            y,
            button: PointerButton::Primary,
        });
        assert_eq!(inner.get(), 1);
        assert_eq!(outer.get(), 0);
    }
    #[test]
    fn boxed_text_reactive_wrapping_reflows_without_remounting() {
        use crate::{compose::text, style::Styled};
        let mut ui = Ui::new(300., 200.);
        ui.scene
            .borrow_mut()
            .set_text_measurer(|text: &str, _: f32, limit: Option<f32>| {
                let natural = text.len() as f32 * 10.;
                let width = limit.unwrap_or(natural).min(natural).max(1.);
                (width, (natural / width).ceil() * 20.)
            });
        let wrap = ui.signal(false);
        let read = wrap.clone();
        let view = ui.mount(
            text("abcdefghijabcdefghij")
                .id("box")
                .w(70.)
                .p(10.)
                .bg(Color(1, 2, 3, 255))
                .text_wrap(false)
                .reactive_style(move || Styles::new().text_wrap(read.get())),
        );
        ui.scene.borrow_mut().flush();
        let outer = view.node();
        let inner = ui.scene.borrow().children(outer)[0];
        assert_eq!(ui.scene.borrow().bounds(outer).height, 40.);
        wrap.set(true);
        let report = ui.scene.borrow_mut().flush();
        assert!(report.layout_nodes > 0);
        assert_eq!(ui.scene.borrow().bounds(outer).height, 100.);
        assert_eq!(ui.scene.borrow().bounds(inner).width, 50.);
        assert_eq!(ui.scene.borrow().children(outer), &[inner]);
        assert_eq!(view.find("box"), Some(outer));
        wrap.set(false);
        ui.scene.borrow_mut().flush();
        assert_eq!(ui.scene.borrow().bounds(outer).height, 40.);
        assert_eq!(ui.scene.borrow().children(outer), &[inner]);
    }
    #[test]
    fn font_properties_inherit_override_and_update_without_remount() {
        use crate::{
            compose::{column, text},
            style::Styled,
            text_layout::FontFamily,
        };
        let mut ui = Ui::new(300., 200.);
        let bold = ui.signal(false);
        let read = bold.clone();
        let view = ui.mount(
            column()
                .font_family(FontFamily::Serif)
                .italic(true)
                .reactive_style(move || {
                    Styles::new().font_weight(if read.get() { 700 } else { 400 })
                })
                .child(text("inherited").id("a"))
                .child(
                    text("override")
                        .id("b")
                        .font_family(FontFamily::Monospace)
                        .font_weight(500)
                        .italic(false),
                ),
        );
        let a = view.find("a").unwrap();
        let b = view.find("b").unwrap();
        ui.scene.borrow_mut().flush();
        assert_eq!(ui.scene.borrow().font(a).family, FontFamily::Serif);
        assert!(ui.scene.borrow().font(a).italic);
        assert_eq!(ui.scene.borrow().font(b).weight, 500);
        assert!(!ui.scene.borrow().font(b).italic);
        bold.set(true);
        assert_eq!(view.find("a"), Some(a));
        assert_eq!(ui.scene.borrow().font(a).weight, 700);
        assert_eq!(ui.scene.borrow().font(b).weight, 500);
        assert!(ui.scene.borrow_mut().flush().layout_nodes > 0);
        bold.set(true);
        assert!(ui.scene.borrow_mut().flush().is_idle());
    }
}
