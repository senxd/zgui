//! Reusable shaped text geometry for editor hit testing, carets and bidi selections.
pub use cosmic_text::Affinity;
use cosmic_text::{Attrs, Buffer, Family, FontSystem, Metrics, Shaping};
use std::{ops::Range, sync::Arc};
use unicode_segmentation::UnicodeSegmentation;
use zgui::scene::Rect;
pub(crate) fn attrs(font: &zgui::text_layout::FontStyle) -> Attrs<'_> {
    use zgui::text_layout::FontFamily;
    let family = match &font.family {
        FontFamily::SansSerif => Family::SansSerif,
        FontFamily::Serif => Family::Serif,
        FontFamily::Monospace => Family::Monospace,
        FontFamily::Named(name) => Family::Name(name),
    };
    Attrs::new()
        .family(family)
        .weight(cosmic_text::Weight(font.weight.clamp(1, 1000)))
        .style(if font.italic {
            cosmic_text::Style::Italic
        } else {
            cosmic_text::Style::Normal
        })
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TextCursor {
    pub byte_index: usize,
    pub affinity: Affinity,
}
/// Owns a shaped text buffer. Reuse it until text/font/width changes.
/// Coordinates are logical pixels relative to the text node origin.
/// Ligature interiors divide the advance among graphemes, matching cosmic-text's
/// editor convention. This does not read font-specific GDEF ligature caret tables.
pub struct ShapedText {
    buffer: Buffer,
    text: Arc<str>,
    line_offsets: Vec<usize>,
    line_height: f32,
}
impl ShapedText {
    pub fn new(
        fonts: &mut FontSystem,
        text: impl Into<Arc<str>>,
        font_size: f32,
        width: Option<f32>,
    ) -> Self {
        Self::with_font(fonts, text, font_size, width, &Default::default())
    }
    pub fn with_font(
        fonts: &mut FontSystem,
        text: impl Into<Arc<str>>,
        font_size: f32,
        width: Option<f32>,
        font: &zgui::text_layout::FontStyle,
    ) -> Self {
        let text = text.into();
        let size = font_size.max(1.);
        let line_height = (size * 1.4).ceil();
        let mut buffer = Buffer::new(fonts, Metrics::new(size, line_height));
        buffer.set_size(fonts, width, None);
        buffer.set_text(fonts, &text, &attrs(font), Shaping::Advanced);
        buffer.shape_until_scroll(fonts, false);
        let mut offset = 0;
        let line_offsets = buffer
            .lines
            .iter()
            .map(|line| {
                let start = offset;
                offset += line.text().len() + line.ending().as_str().len();
                start
            })
            .collect();
        Self {
            buffer,
            text,
            line_offsets,
            line_height,
        }
    }
    pub fn text(&self) -> &str {
        &self.text
    }
    pub fn size(&self) -> (f32, f32) {
        self.buffer
            .layout_runs()
            .fold((0_f32, 0_f32), |(w, h), run| {
                (w.max(run.line_w), h.max(run.line_top + run.line_height))
            })
    }
    pub fn hit_test(&self, x: f32, y: f32) -> Option<TextCursor> {
        let cursor = self.buffer.hit(x, y)?;
        Some(TextCursor {
            byte_index: self.line_offsets.get(cursor.line)? + cursor.index,
            affinity: cursor.affinity,
        })
    }
    pub fn caret(&self, cursor: TextCursor) -> Option<Rect> {
        if cursor.byte_index > self.text.len() || !self.text.is_char_boundary(cursor.byte_index) {
            return None;
        }
        let mut fallback = None;
        for run in self.buffer.layout_runs() {
            let offset = self.line_offsets[run.line_i];
            if run.glyphs.is_empty() && cursor.byte_index == offset {
                return Some(Rect::new(0., run.line_top, 1., run.line_height));
            }
            for glyph in run.glyphs {
                let start = offset + glyph.start;
                let end = offset + glyph.end;
                if cursor.byte_index < start || cursor.byte_index > end {
                    continue;
                }
                let cluster = &self.text[start..end];
                let count = cluster.graphemes(true).count().max(1);
                let before = cluster
                    .grapheme_indices(true)
                    .filter(|(i, _)| start + i < cursor.byte_index)
                    .count();
                let fraction = before as f32 / count as f32;
                let x = if glyph.level.is_rtl() {
                    glyph.x + glyph.w * (1. - fraction)
                } else {
                    glyph.x + glyph.w * fraction
                };
                let rect = Rect::new(x, run.line_top, 1., run.line_height);
                if (cursor.byte_index == start && cursor.affinity == Affinity::After)
                    || (cursor.byte_index == end && cursor.affinity == Affinity::Before)
                    || (cursor.byte_index > start && cursor.byte_index < end)
                {
                    return Some(rect);
                }
                fallback = Some(rect);
            }
        }
        fallback
    }
    /// Returns visual rectangles, including disjoint spans for mixed-direction text.
    pub fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        let start = range.start.min(range.end);
        let end = range.start.max(range.end).min(self.text.len());
        if start >= end {
            return Vec::new();
        }
        let mut rectangles: Vec<Rect> = Vec::new();
        for run in self.buffer.layout_runs() {
            let offset = self.line_offsets[run.line_i];
            let mut spans = Vec::new();
            for glyph in run.glyphs {
                let cluster_start = offset + glyph.start;
                let cluster_end = offset + glyph.end;
                if cluster_start >= end || cluster_end <= start {
                    continue;
                }
                let cluster = &self.text[cluster_start..cluster_end];
                let count = cluster.graphemes(true).count().max(1);
                for (index, (local, grapheme)) in cluster.grapheme_indices(true).enumerate() {
                    if cluster_start + local >= end
                        || cluster_start + local + grapheme.len() <= start
                    {
                        continue;
                    }
                    let width = glyph.w / count as f32;
                    let x = if glyph.level.is_rtl() {
                        glyph.x + glyph.w - (index + 1) as f32 * width
                    } else {
                        glyph.x + index as f32 * width
                    };
                    spans.push(Rect::new(x, run.line_top, width, run.line_height));
                }
            }
            spans.sort_by(|a, b| a.x.total_cmp(&b.x));
            for span in spans {
                if let Some(last) = rectangles.last_mut()
                    && last.y == span.y
                    && last.x + last.width >= span.x - 0.01
                {
                    *last = last.union(span);
                    continue;
                }
                rectangles.push(span);
            }
        }
        rectangles
    }
    pub fn line_height(&self) -> f32 {
        self.line_height
    }
}

impl zgui::text_layout::TextLayout for ShapedText {
    fn size(&self) -> (f32, f32) {
        ShapedText::size(self)
    }
    fn hit_test(&self, x: f32, y: f32) -> usize {
        ShapedText::hit_test(self, x, y).map_or(0, |cursor| cursor.byte_index)
    }
    fn caret(&self, byte_offset: usize) -> Rect {
        let mut offset = byte_offset.min(self.text.len());
        while !self.text.is_char_boundary(offset) {
            offset -= 1;
        }
        ShapedText::caret(
            self,
            TextCursor {
                byte_index: offset,
                affinity: Affinity::After,
            },
        )
        .or_else(|| {
            ShapedText::caret(
                self,
                TextCursor {
                    byte_index: offset,
                    affinity: Affinity::Before,
                },
            )
        })
        .unwrap_or(Rect::new(0., 0., 1., self.line_height))
    }
    fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        ShapedText::selection(self, range)
    }
}

/// Lazy software shaping/rasterization for the reference backend's styled fonts.
/// Glyph images are not retained in Swash's unbounded internal image map.
pub struct CpuTextRaster {
    fonts: FontSystem,
    swash: cosmic_text::SwashCache,
}
impl Default for CpuTextRaster {
    fn default() -> Self {
        Self {
            fonts: FontSystem::new(),
            swash: cosmic_text::SwashCache::new(),
        }
    }
}
impl CpuTextRaster {
    pub fn rasterize(
        &mut self,
        text: &str,
        size: f32,
        width: f32,
        height: f32,
        font: &zgui::text_layout::FontStyle,
    ) -> Vec<(i32, i32, cosmic_text::SwashImage)> {
        let size = size.max(1.);
        let mut buffer = Buffer::new(&mut self.fonts, Metrics::new(size, (size * 1.4).ceil()));
        buffer.set_size(&mut self.fonts, Some(width), Some(height));
        buffer.set_text(&mut self.fonts, text, &attrs(font), Shaping::Advanced);
        buffer.shape_until_scroll(&mut self.fonts, false);
        let mut images = Vec::new();
        for run in buffer.layout_runs() {
            for glyph in run.glyphs {
                let physical = glyph.physical((0., 0.), 1.);
                if let Some(image) = self
                    .swash
                    .get_image_uncached(&mut self.fonts, physical.cache_key)
                {
                    images.push((physical.x, physical.y + run.line_y as i32, image));
                }
            }
        }
        images
    }
}
