//! Native Linux/macOS application host with GPU rendering, accessibility, clipboard,
//! and IME. A software raster backend is available for reference and headless tests.
//!
//! ```no_run
//! use zgui::{scene::{Layout, Style}, widgets::fixed};
//! use zgui_desktop::{Application, WindowOptions};
//! fn main() -> Result<(), Box<dyn std::error::Error>> {
//!     Application::new().window(WindowOptions {
//!         title: "Example".into(), ..Default::default()
//!     }).run(|cx| {
//!         let ui = &mut cx.ui;
//!         let column = ui.container(ui.root(), Layout::Column,
//!             Style { padding: 24.0, gap: 12.0, ..Default::default() });
//!         let title = ui.signal(String::from("Ready"));
//!         ui.label_signal(column, title.clone(), fixed(320.0, 28.0));
//!         ui.button(column, "Update", 140.0, move || {
//!             title.set(String::from("Updated"));
//!         });
//!     })
//! }
//! ```
mod focus_memory;
pub mod presentation;
pub mod raster;

pub mod accessibility;

pub mod application;
pub use application::{
    Application, TaskSpawner, WindowContext, WindowFactory, WindowHandle, WindowOptions,
};

mod scoped_task;
pub use scoped_task::ScopedTask;

#[cfg(doctest)]
#[doc = include_str!("../../../README.md")]
mod readme_examples {}

mod presentation_retry;

#[cfg(doctest)]
#[doc = include_str!("../../../docs/window-controls.md")]
mod window_control_examples {}
