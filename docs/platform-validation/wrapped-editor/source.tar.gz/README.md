# zgui

A retained Rust GUI framework focused on **Linux and macOS**, fine-grained updates, bounded rendering resources, and low idle CPU usage. It has a platform-independent core, a wgpu renderer, and a desktop host with native input, clipboard, IME, accessibility, and multiple windows.

```sh
cargo run --release -p zgui-desktop --example components
cargo run --release -p zgui-desktop --example form
cargo run --release -p zgui-desktop --example wrapped_editor
cargo run --release -p zgui-desktop --example overlays
cargo run --release -p zgui-desktop --example menus
cargo run --release -p zgui-desktop --example submenus
ZGUI_MODE=both ZGUI_SECONDS=10 cargo run --release -p zgui-desktop --example component_workload
cargo run --release -p zgui-desktop --example gallery
cargo run --release -p zgui-desktop --example workbench
cargo run --release -p zgui-desktop --example windows
cargo run --release -p zgui-desktop --example effects
```

Applications describe components and children. They mount once; reactive properties update only their retained targets:

```rust,no_run
use zgui::compose::prelude::*;
use zgui_desktop::Application;

fn counter() -> View {
    component(|cx| {
        let count = cx.state(0_u32);
        let label = count.clone();
        column().p(24.0).gap(12.0)
            .bg(rgb(0x172030)).rounded(12.0)
            .child(text_signal(move || format!("Count: {}", label.get())))
            .child(button()
                .px(16.0).py(10.0).rounded(8.0)
                .bg(rgb(0x345888))
                .hover(|s| s.bg(rgb(0x426da4)))
                .focus(|s| s.border(2.0).border_color(rgb(0x9ac7ff)))
                .child("Increment")
                .on_click(move || { count.update(|n| *n += 1); }))
    })
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    Application::new().run(|cx| { cx.render(counter()); })
}
```

Components resolve typed services with `cx.service::<Model>()`, initialize local state with `cx.state`, and capture caller-owned lexical providers in `cx.slot`. Rows, columns, buttons and slots take child views; `text_input` and `text_area` bind editable values with fluent styles and inherited typography; application components do not manipulate scene parent IDs. `provide`/`provide_with`, keyed children and conditional regions preserve ownership across fine-grained updates. See the [exact model example](crates/zgui/examples/model.rs), [component architecture](docs/composition.md), and [fluent styling](docs/styling.md).

The framework includes:

- Tracked signals, equal-write suppression, batching, scoped providers, stable reactive collection rows, keyed views, explicit ownership, cancellation, bounded background workers and wake-driven async tasks.
- Cached constraint-aware row/column/overlay layout, absolute positioning, min/max sizes, margins, flex grow/shrink, alignment, justification and native text measurement.
- GPU text shaping, bounded glyph/image caches, persistent damage rendering, rounded rectangles, borders, shadows, RGBA images, PNG/JPEG/SVG decoding, transparency, edge fades, backdrop blur and explicit cached compositor layers.
- Pointer capture, bubbling/capture event routing, focus navigation and trapping, keyboard activation, Unicode selection/editing, IME preedit, clipboard, and bounded undo/redo.
- Buttons, checkboxes, sliders, progress indicators, labels, text inputs, scroll views, keyed virtual lists, dialogs, popovers and menus.
- Winit window lifecycle, GPU presentation, display scaling, multiple windows, platform shortcuts and AccessKit semantics/actions.

Read [components and slots](docs/composition.md), [styling](docs/styling.md), [application development](docs/application.md), [architecture and template lowering](docs/architecture.md), and the [remaining completion plan](docs/ROADMAP.md). The proposed template language remains independent of the idiomatic Rust API; no parser is imposed on Rust applications.

## Performance comparison

The same deterministic streaming-text and 100,000-row virtual-list UI is implemented in zgui, GPUI and QuickGUI. Only viewport rows are mounted. All adapters have locked dependencies and share the workload source.

```sh
ZGUI_MODE=both ZGUI_SECONDS=10 cargo run --release -p zgui-desktop --example component_workload
ZGUI_MODE=idle ZGUI_SECONDS=0 cargo run --release -p zgui-desktop --example component_workload
```

The component workload uses the native GPU host and owned declarative views. `ZGUI_MODE` accepts `idle`, `stream`, `scroll`, or `both`; zero seconds keeps the window open. The older `zgui-demo` executable remains available for low-level renderer diagnostics, including `ZGUI_RENDERER=software` and display-free `--headless` checks.

See [benchmark commands and methodology](docs/benchmarking.md). The [normalized component comparison](docs/results/component-comparison/README.md) records 24 trials on Mesa llvmpipe. zgui showed lower sampled active-workload CPU than both references; its 124.53–127.48 MiB mean RSS medians were below QuickGUI and above GPUI. A later [backend initialization ablation](docs/results/component-memory/README.md) measured 106.96 MiB median idle RSS with Vulkan-only initialization; it does not update the frozen active-workload comparison. Raw samples, binary hashes, source archives, spread and workload counts are retained. These are software-GPU environment results, **not hardware-GPU rankings or proof of minimum resource use**.

## Validation and current boundaries

```sh
cargo test --workspace --all-targets --locked
cargo test --workspace --doc --locked
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo fmt --all -- --check
```

GPU tests require a Vulkan or Metal adapter, including software Vulkan for CI. Linux native windows and offscreen GPU pixels are tested here. Linux/macOS CI is configured; **macOS runtime behavior and hardware GPU performance still need validation on their target hardware**.

Development remains active. Backdrop blur currently reconstructs the backdrop on changed frames. Core-only text measurement uses a fallback until a native shaper is installed. See the [GPU renderer's precise resource limits](crates/zgui-gpu/README.md) and [completion plan](docs/ROADMAP.md) for unresolved work; the project does not claim that every GUI feature is finished or that minimum possible CPU/RAM use has been proved.

References: [GPUI](https://gpui.rs/), [zui](https://github.com/zeronsh/zui), [QuickGUI](https://github.com/egoist/quickgui), [React](https://github.com/react/react). Their designs informed this framework. zgui uses direct dependency subscriptions instead of rerunning whole component functions. Font and dependency licenses are retained alongside their assets and manifests.
