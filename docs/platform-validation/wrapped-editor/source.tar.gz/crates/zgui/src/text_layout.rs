//! Platform-independent shaped text geometry consumed by editors and selection widgets.
use crate::scene::Rect;
use std::ops::Range;
use unicode_segmentation::UnicodeSegmentation;
/// Portable font selection. Named families fall back through the platform font database.
#[derive(Clone, Debug, Default, PartialEq, Eq, Hash)]
pub enum FontFamily {
    #[default]
    SansSerif,
    Serif,
    Monospace,
    Named(std::sync::Arc<str>),
}
impl From<&str> for FontFamily {
    fn from(value: &str) -> Self {
        Self::Named(value.into())
    }
}
impl From<String> for FontFamily {
    fn from(value: String) -> Self {
        Self::Named(value.into())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct FontStyle {
    pub family: FontFamily,
    /// OpenType weight in the inclusive range 1..=1000 (400 regular, 700 bold).
    pub weight: u16,
    pub italic: bool,
}
impl Default for FontStyle {
    fn default() -> Self {
        Self {
            family: FontFamily::SansSerif,
            weight: 400,
            italic: false,
        }
    }
}
/// Font-aware shaping callback. The legacy TextShaper remains available for default fonts.
pub trait FontTextShaper {
    fn shape(
        &self,
        text: &str,
        size: f32,
        width: Option<f32>,
        font: &FontStyle,
    ) -> Box<dyn TextLayout>;
}
impl<F: Fn(&str, f32, Option<f32>, &FontStyle) -> Box<dyn TextLayout>> FontTextShaper for F {
    fn shape(
        &self,
        text: &str,
        size: f32,
        width: Option<f32>,
        font: &FontStyle,
    ) -> Box<dyn TextLayout> {
        self(text, size, width, font)
    }
}
/// Which side of a shared cluster or soft-wrap boundary owns a caret.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum TextAffinity {
    /// Trailing edge of the preceding logical cluster; upstream at a soft wrap.
    Before,
    /// Leading edge of the following logical cluster; downstream at a soft wrap.
    #[default]
    After,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct TextPosition {
    /// UTF-8 byte offset on a grapheme boundary.
    pub byte_offset: usize,
    pub affinity: TextAffinity,
}
pub trait TextLayout {
    fn size(&self) -> (f32, f32);
    /// Returns a UTF-8 byte offset on a grapheme boundary.
    fn hit_test(&self, x: f32, y: f32) -> usize;
    fn caret(&self, byte_offset: usize) -> Rect;
    /// Visual spans may be disjoint for bidirectional text.
    fn selection(&self, range: Range<usize>) -> Vec<Rect>;
    /// Affinity-aware geometry; defaults preserve compatibility with custom shapers.
    fn hit_position(&self, x: f32, y: f32) -> TextPosition {
        TextPosition {
            byte_offset: self.hit_test(x, y),
            affinity: TextAffinity::After,
        }
    }
    fn caret_position(&self, position: TextPosition) -> Rect {
        self.caret(position.byte_offset)
    }
    /// Physical left/right edge of the caret's visual line, excluding line endings.
    fn visual_line_edge(&self, position: TextPosition, end: bool) -> TextPosition {
        let caret = self.caret_position(position);
        self.hit_position(
            if end { f32::MAX } else { -f32::MAX },
            caret.y + caret.height * 0.5,
        )
    }
}
pub trait TextShaper {
    fn shape(&self, text: &str, font_size: f32, max_width: Option<f32>) -> Box<dyn TextLayout>;
}
impl<F: Fn(&str, f32, Option<f32>) -> Box<dyn TextLayout>> TextShaper for F {
    fn shape(&self, text: &str, font_size: f32, max_width: Option<f32>) -> Box<dyn TextLayout> {
        self(text, font_size, max_width)
    }
}
/// Approximate grapheme cells for headless/core use. Native hosts install a real shaper.
pub struct FallbackTextLayout {
    cells: Vec<(Range<usize>, Rect)>,
    end: Rect,
    size: (f32, f32),
}
impl FallbackTextLayout {
    pub fn new(text: &str, size: f32, max_width: Option<f32>) -> Self {
        let advance = size.max(1.) * 0.6;
        let height = (size.max(1.) * 1.4).ceil();
        let mut x = 0.;
        let mut y = 0.;
        let mut width = 0_f32;
        let mut cells = Vec::new();
        for (index, grapheme) in text.grapheme_indices(true) {
            if grapheme.contains(['\n', '\r']) {
                cells.push((index..index + grapheme.len(), Rect::new(x, y, 0., height)));
                width = width.max(x);
                x = 0.;
                y += height;
                continue;
            }
            if max_width.is_some_and(|w| w > 0. && x > 0. && x + advance > w) {
                width = width.max(x);
                x = 0.;
                y += height
            }
            cells.push((
                index..index + grapheme.len(),
                Rect::new(x, y, advance, height),
            ));
            x += advance;
        }
        width = width.max(x);
        Self {
            cells,
            end: Rect::new(x, y, 1., height),
            size: (width, y + height),
        }
    }
}
impl TextLayout for FallbackTextLayout {
    fn size(&self) -> (f32, f32) {
        self.size
    }
    fn hit_test(&self, x: f32, y: f32) -> usize {
        self.hit_position(x, y).byte_offset
    }
    fn hit_position(&self, x: f32, y: f32) -> TextPosition {
        let y = y.max(0.);
        let mut result = TextPosition::default();
        for (range, r) in &self.cells {
            if y >= r.y && y < r.y + r.height {
                if r.width == 0. || x < r.x + r.width * 0.5 {
                    return TextPosition {
                        byte_offset: range.start,
                        affinity: TextAffinity::After,
                    };
                }
                result = TextPosition {
                    byte_offset: range.end,
                    affinity: TextAffinity::Before,
                };
            } else if y >= r.y + r.height {
                result = TextPosition {
                    byte_offset: range.end,
                    affinity: TextAffinity::After,
                };
            }
        }
        result
    }
    fn caret_position(&self, position: TextPosition) -> Rect {
        if position.affinity == TextAffinity::Before {
            for (range, rect) in &self.cells {
                if range.end == position.byte_offset && rect.width > 0. {
                    return Rect::new(rect.x + rect.width, rect.y, 1., rect.height);
                }
            }
        }
        self.caret(position.byte_offset)
    }
    fn caret(&self, byte_offset: usize) -> Rect {
        for (range, r) in &self.cells {
            if byte_offset <= range.start || range.contains(&byte_offset) {
                return Rect::new(r.x, r.y, 1., r.height);
            }
        }
        self.end
    }
    fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        let start = range.start.min(range.end);
        let end = range.start.max(range.end);
        if start == end {
            return Vec::new();
        }
        let mut result: Vec<Rect> = Vec::new();
        for (index, r) in &self.cells {
            if index.start < end && index.end > start && r.width > 0. {
                if let Some(last) = result.last_mut()
                    && last.y == r.y
                    && last.x + last.width >= r.x
                {
                    *last = last.union(*r);
                    continue;
                }
                result.push(*r);
            }
        }
        result
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn grapheme_offsets_newlines_and_wrap() {
        let layout = FallbackTextLayout::new("e\u{301}👩‍💻\nx", 10., None);
        assert_eq!(layout.hit_test(1., 2.), 0);
        assert_eq!(layout.hit_test(8., 2.), 3);
        assert_eq!(layout.caret(3).x, 6.);
        assert_eq!(layout.selection(0..3).len(), 1);
        assert_eq!(layout.size().1, 28.);
    }
    #[test]
    fn wrapped_grapheme_boundary_preserves_visual_affinity() {
        let layout = FallbackTextLayout::new("a👩‍💻e\u{301}z", 10., Some(12.));
        let end = layout.visual_line_edge(TextPosition::default(), true);
        assert_eq!(
            end,
            TextPosition {
                byte_offset: 12,
                affinity: TextAffinity::Before
            }
        );
        assert_eq!(layout.caret_position(end), Rect::new(12., 0., 1., 14.));
        let next = TextPosition {
            affinity: TextAffinity::After,
            ..end
        };
        assert_eq!(layout.caret_position(next), Rect::new(0., 14., 1., 14.));
        assert_eq!(layout.visual_line_edge(next, false), next);
        assert_eq!(layout.hit_position(100., 5.), end);
        assert_eq!(layout.hit_position(-10., 18.), next);
        assert_eq!(
            layout.selection(1..15),
            vec![Rect::new(6., 0., 6., 14.), Rect::new(0., 14., 6., 14.)]
        );
        assert!(layout.selection(2..2).is_empty());
    }
    #[test]
    fn visual_edges_exclude_crlf_and_preserve_empty_final_lines() {
        let layout = FallbackTextLayout::new("ab\r\n\n", 10., Some(30.));
        assert_eq!(layout.hit_test(100., 2.), 2);
        assert_eq!(layout.hit_test(100., 16.), 4);
        assert_eq!(layout.hit_test(100., 30.), 5);
        assert_eq!(layout.caret(5).y, 28.);
        assert_eq!(layout.hit_test(10., -10.), 2);
    }
}
