//! Platform-independent accessibility information attached to retained nodes.
use crate::scene::{NodeId, Scene};
use std::collections::HashMap;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Role {
    Window,
    Group,
    Label,
    Button,
    CheckBox,
    Slider,
    TextInput,
    MultilineTextInput,
    Progress,
    ScrollView,
    ScrollBar,
    ListItem,
    Dialog,
    Menu,
    MenuItem,
    Image,
}
/// The single scrolling axis supported by a semantic scroll view.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScrollAxis {
    Horizontal,
    Vertical,
}
/// Kind of popup exposed by an interactive trigger.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PopupKind {
    Menu,
    Dialog,
}
#[derive(Clone, Debug, PartialEq)]
pub struct SemanticNode {
    pub role: Role,
    pub label: String,
    pub value: Option<String>,
    /// Committed-text UTF-8 byte offsets, preserving anchor/focus direction.
    pub text_selection: Option<(usize, usize)>,
    pub checked: Option<bool>,
    pub disabled: bool,
    /// Readable and selectable, but not editable through user input.
    pub read_only: bool,
    /// Whether this dialog traps interaction within its subtree.
    pub modal: bool,
    pub expanded: Option<bool>,
    pub has_popup: Option<PopupKind>,
    /// Accessible ownership for a portal whose physical parent differs. Native
    /// projection ignores missing, hidden, self-referential or cyclic parents.
    pub logical_parent: Option<NodeId>,
    pub min: Option<f64>,
    pub max: Option<f64>,
    pub numeric_value: Option<f64>,
    /// None preserves the vertical default of legacy scroll views.
    pub scroll_axis: Option<ScrollAxis>,
    /// One-based position of a retained item in a potentially virtual set.
    pub position_in_set: Option<usize>,
    /// Total set size, including items not currently mounted.
    pub size_of_set: Option<usize>,
}
impl SemanticNode {
    pub fn new(role: Role, label: impl Into<String>) -> Self {
        Self {
            role,
            label: label.into(),
            value: None,
            text_selection: None,
            checked: None,
            disabled: false,
            read_only: false,
            modal: false,
            expanded: None,
            has_popup: None,
            logical_parent: None,
            min: None,
            max: None,
            numeric_value: None,
            scroll_axis: None,
            position_in_set: None,
            size_of_set: None,
        }
    }
}
#[derive(Default)]
pub struct Semantics {
    nodes: HashMap<NodeId, SemanticNode>,
    revision: u64,
}
impl Semantics {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn set(&mut self, id: NodeId, node: SemanticNode) {
        if self.nodes.get(&id) != Some(&node) {
            self.nodes.insert(id, node);
            self.revision = self.revision.wrapping_add(1);
        }
    }
    pub fn get(&self, id: NodeId) -> Option<&SemanticNode> {
        self.nodes.get(&id)
    }
    pub fn update(&mut self, id: NodeId, f: impl FnOnce(&mut SemanticNode)) {
        if let Some(node) = self.nodes.get_mut(&id) {
            let before = node.clone();
            f(node);
            if *node != before {
                self.revision = self.revision.wrapping_add(1);
            }
        }
    }
    /// Update committed editor text, byte selection and read-only state together.
    /// Equal text preserves its allocation; changed text reuses existing capacity.
    /// Other semantic properties are untouched. Missing nodes are ignored.
    pub fn update_text_input(
        &mut self,
        id: NodeId,
        value: &str,
        selection: (usize, usize),
        read_only: bool,
    ) {
        let Some(node) = self.nodes.get_mut(&id) else {
            return;
        };
        let value_changed = node.value.as_deref() != Some(value);
        if !value_changed && node.text_selection == Some(selection) && node.read_only == read_only {
            return;
        }
        if value_changed {
            if let Some(stored) = &mut node.value {
                value.clone_into(stored);
            } else {
                node.value = Some(value.to_owned());
            }
        }
        node.text_selection = Some(selection);
        node.read_only = read_only;
        self.revision = self.revision.wrapping_add(1);
    }
    pub fn remove(&mut self, id: NodeId) {
        if self.nodes.remove(&id).is_some() {
            self.revision = self.revision.wrapping_add(1);
        }
    }
    pub fn retain_mounted(&mut self, scene: &Scene) {
        let count = self.nodes.len();
        self.nodes.retain(|id, _| scene.contains(*id));
        if self.nodes.len() != count {
            self.revision = self.revision.wrapping_add(1);
        }
    }
    pub fn iter(&self) -> impl Iterator<Item = (NodeId, &SemanticNode)> {
        self.nodes.iter().map(|(id, n)| (*id, n))
    }
    pub fn revision(&self) -> u64 {
        self.revision
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::scene::{Color, NodeKind, Style};
    #[test]
    fn text_input_update_reuses_payload_and_changes_revision_once() {
        let mut scene = Scene::new(100., 100.);
        let id = scene.append(
            scene.root(),
            NodeKind::Rect(Color(0, 0, 0, 0)),
            Style::default(),
        );
        let mut semantics = Semantics::new();
        let mut node = SemanticNode::new(Role::MultilineTextInput, "Document");
        node.disabled = true;
        node.modal = true;
        node.checked = Some(true);
        node.expanded = Some(false);
        node.numeric_value = Some(7.);
        let mut stored = String::with_capacity(1024);
        stored.push_str("unchanged");
        node.value = Some(stored);
        semantics.set(id, node.clone());
        let pointer = semantics.get(id).unwrap().value.as_ref().unwrap().as_ptr();
        let capacity = semantics
            .get(id)
            .unwrap()
            .value
            .as_ref()
            .unwrap()
            .capacity();
        let revision = semantics.revision();
        semantics.update_text_input(id, "unchanged", (3, 1), false);
        assert_eq!(semantics.revision(), revision + 1);
        assert_eq!(
            semantics.get(id).unwrap().value.as_ref().unwrap().as_ptr(),
            pointer
        );
        semantics.update_text_input(id, "unchanged", (3, 1), false);
        assert_eq!(semantics.revision(), revision + 1);
        semantics.update_text_input(id, "new", (0, 3), true);
        assert_eq!(semantics.revision(), revision + 2);
        let current = semantics.get(id).unwrap();
        assert_eq!(current.value.as_deref(), Some("new"));
        assert_eq!(current.value.as_ref().unwrap().as_ptr(), pointer);
        assert_eq!(current.value.as_ref().unwrap().capacity(), capacity);
        node.value = Some("new".into());
        node.text_selection = Some((0, 3));
        node.read_only = true;
        assert_eq!(current, &node, "all unrelated fields remain unchanged");
        semantics.remove(id);
        let removed_revision = semantics.revision();
        semantics.update_text_input(id, "missing", (0, 0), false);
        assert_eq!(semantics.revision(), removed_revision);
        assert!(semantics.get(id).is_none());
    }
    #[test]
    fn text_input_update_initializes_missing_value_and_handles_empty_text() {
        let scene = Scene::new(100., 100.);
        let id = scene.root();
        let mut semantics = Semantics::new();
        semantics.set(id, SemanticNode::new(Role::TextInput, "Empty"));
        let revision = semantics.revision();
        semantics.update_text_input(id, "", (0, 0), false);
        assert_eq!(semantics.revision(), revision + 1);
        assert_eq!(semantics.get(id).unwrap().value.as_deref(), Some(""));
        semantics.update_text_input(id, "", (0, 0), false);
        assert_eq!(semantics.revision(), revision + 1);
    }
    #[test]
    fn semantic_updates_are_equal_suppressed_and_unmounted_nodes_removed() {
        let mut s = Scene::new(100., 100.);
        let n = s.append(
            s.root(),
            NodeKind::Rect(Color(0, 0, 0, 255)),
            Style::default(),
        );
        let mut a = Semantics::new();
        let node = SemanticNode::new(Role::Button, "Save");
        a.set(n, node.clone());
        let rev = a.revision();
        a.set(n, node);
        assert_eq!(a.revision(), rev);
        a.update(n, |n| n.disabled = true);
        assert_eq!(a.revision(), rev + 1);
        s.remove(n);
        a.retain_mounted(&s);
        assert!(a.get(n).is_none());
    }
}
