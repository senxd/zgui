//! Reactive variable-height virtualization, sharing retained component ownership.
use super::*;
use crate::virtual_list::{HeightError, HeightIndex};

/// Cloneable indexed heights with logarithmic point updates and no whole-index clones.
///
/// Heights belong to positions; callers must reorder them with their data. A point
/// update preserves the viewport's first visible index and intra-row offset.
/// Count changes preserve/clamp the pixel offset. Natural child measurement is
/// not inferred: applications supply the allocated height of every row.
#[derive(Clone)]
pub struct VariableHeights {
    index: Rc<RefCell<HeightIndex>>,
    revision: Signal<u64>,
}
impl VariableHeights {
    pub fn new(runtime: &Runtime, count: usize, estimate: f32) -> Self {
        Self::try_new(runtime, count, estimate).expect("valid variable row heights")
    }
    pub fn try_new(runtime: &Runtime, count: usize, estimate: f32) -> Result<Self, HeightError> {
        Ok(Self {
            index: Rc::new(RefCell::new(HeightIndex::try_new(count, estimate)?)),
            revision: runtime.signal(0),
        })
    }
    fn changed(&self) {
        self.revision
            .update(|revision| *revision = revision.wrapping_add(1));
    }
    pub fn set_height(&self, index: usize, height: f32) -> Result<bool, HeightError> {
        let changed = self.index.borrow_mut().set_height(index, height)?;
        if changed {
            self.changed();
        }
        Ok(changed)
    }
    pub fn resize(&self, count: usize) -> Result<bool, HeightError> {
        let changed = self.index.borrow_mut().resize(count)?;
        if changed {
            self.changed();
        }
        Ok(changed)
    }
    pub fn len(&self) -> usize {
        self.revision.get();
        self.index.borrow().count()
    }
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
    pub fn row_height(&self, index: usize) -> Option<f32> {
        self.revision.get();
        self.index.borrow().row_height(index)
    }
    pub fn row_offset(&self, index: usize) -> f32 {
        self.revision.get();
        self.index.borrow().row_offset(index)
    }
    pub fn content_height(&self) -> f32 {
        self.revision.get();
        self.index.borrow().content_height()
    }
    pub fn row_at(&self, offset: f32) -> Option<usize> {
        self.revision.get();
        self.index.borrow().row_at(offset)
    }
}
struct Anchor {
    revision: u64,
    length: usize,
    position: f32,
    index: usize,
    within: f32,
}

/// Mount only visible variable-height keyed rows and an overscan margin.
///
/// Rows take their allocated height from `heights`; child constructors run once
/// per mounted key. Point height updates keep the first visible index anchored,
/// unless the caller also changes `offset`. Keys are unique among mounted rows.
/// Reordering data must also reorder its indexed heights; it does not relocate
/// the viewport by key. Persistent offscreen row state belongs in the model.
pub fn variable_virtual_list<K: Eq + std::hash::Hash + Clone + 'static>(
    offset: Signal<f32>,
    heights: VariableHeights,
    overscan: usize,
    mut key: impl FnMut(usize) -> K + 'static,
    mut build: impl FnMut(Signal<usize>, K, &mut Context) -> View + 'static,
) -> View {
    View::new(Kind::VirtualList(Box::new(
        move |ui, root, environment, scrollbar, keyboard_navigation| {
            let size = ui.observe_content_size(root);
            let extent = ui.signal(0.0_f32);
            // Clip rows to the allocated content box, keeping root padding clear.
            let viewport = ui.container(root, Layout::Overlay, Default::default());
            let content = ui.container(viewport, Layout::Overlay, Default::default());
            let navigation = keyboard_navigation.then(|| {
                crate::compose_virtual_keyboard::Navigation::new_variable(
                    ui,
                    root,
                    offset.clone(),
                    size.clone(),
                    heights.clone(),
                )
            });
            let wheel_offset = offset.clone();
            let wheel_size = size.clone();
            let wheel_extent = extent.clone();
            ui.on_event(root, false, move |cx| {
                if cx.phase == EventPhase::Capture || cx.default_prevented() {
                    return;
                }
                if let InputEvent::Scroll { delta_y, .. } = cx.event {
                    if !delta_y.is_finite() {
                        return;
                    }
                    let before = wheel_offset.get();
                    let after = (before + delta_y)
                        .max(0.0)
                        .min((wheel_extent.get() - wheel_size.get().1).max(0.0));
                    if before != after {
                        wheel_offset.set(after);
                        cx.prevent_default();
                        cx.stop_propagation();
                    }
                }
            });
            if scrollbar {
                crate::compose_scrollbar::mount(
                    ui,
                    root,
                    offset.clone(),
                    size.clone(),
                    extent.clone(),
                    false,
                );
            }
            let weak = ui.downgrade();
            let runtime = ui.runtime.clone();
            let mut entries: HashMap<K, (NodeId, Signal<usize>)> = HashMap::new();
            let mut handled_request = 0;
            let mut anchor: Option<Anchor> = None;
            ui.bind(root, move || {
                let revision = heights.revision.get();
                let (width, height) = size.get();
                let requested = offset.get();
                let request = navigation
                    .as_ref()
                    .map(|navigation| navigation.request.get());
                let (length, total, position, target, geometry, next_anchor) = {
                    let model = heights.index.borrow();
                    let length = model.count();
                    let total = model.content_height();
                    let limit = (total - height).max(0.);
                    let mut position = if requested.is_finite() {
                        requested.max(0.)
                    } else {
                        0.
                    }
                    .min(limit);
                    if let Some(previous) = &anchor
                        && previous.revision != revision
                        && previous.length == length
                        && requested == previous.position
                        && let Some(row_height) = model.row_height(previous.index)
                    {
                        let top = model.row_offset(previous.index);
                        let bottom = (top as f64 + row_height as f64).min(f32::MAX as f64) as f32;
                        // Clamp the final coordinate, too: adding a sub-height
                        // intra-row offset can round up to the following row.
                        let last = bottom.next_down().max(top);
                        position = ((top as f64 + previous.within as f64).min(f32::MAX as f64)
                            as f32)
                            .min(last)
                            .min(limit);
                    }
                    let target = request
                        .filter(|(serial, _)| *serial != handled_request)
                        .and_then(|(_, index)| {
                            (length > 0).then_some(index.min(length.saturating_sub(1)))
                        });
                    if let Some(index) = target {
                        let top = model.row_offset(index);
                        let row_height = model.row_height(index).unwrap();
                        let bottom = (top as f64 + row_height as f64).min(f32::MAX as f64) as f32;
                        position = if top < position || row_height > height {
                            top
                        } else if bottom as f64 > position as f64 + height as f64 {
                            (bottom - height).max(0.)
                        } else {
                            position
                        }
                        .min(limit);
                    }
                    let range = model.visible_range(position, height, overscan);
                    let geometry: Vec<_> = model.rows(range).collect();
                    let next_anchor = model.row_at(position).map(|index| Anchor {
                        revision,
                        length,
                        position,
                        index,
                        within: (position - model.row_offset(index)).max(0.),
                    });
                    (length, total, position, target, geometry, next_anchor)
                };
                // Release the index borrow before application key/build callbacks.
                let keys: Vec<_> = geometry
                    .into_iter()
                    .map(|(index, top, row_height)| (key(index), index, top, row_height))
                    .collect();
                let unique: std::collections::HashSet<_> =
                    keys.iter().map(|(key, ..)| key).collect();
                assert_eq!(unique.len(), keys.len(), "duplicate virtual list child key");
                let Some(mut ui) = weak.upgrade() else {
                    return;
                };
                if !ui.scene.borrow().contains(root) {
                    return;
                }
                runtime.untracked(|| {
                    let mut transaction = MountTransaction::new(&ui, content);
                    // Construct first: a failed row constructor leaves old rows intact.
                    let mut added = Vec::new();
                    for (key, index, _, row_height) in &keys {
                        if entries.contains_key(key) {
                            continue;
                        }
                        let index_signal = ui.signal(*index);
                        let mut cx = Context::new(runtime.clone(), environment.clone());
                        let view = build(index_signal.clone(), key.clone(), &mut cx);
                        let row = ui.container(content, Layout::Overlay, Default::default());
                        let node = mount(&mut ui, row, view, environment.clone());
                        cx.finish(&mut ui, node);
                        if let Some(navigation) = &navigation {
                            navigation.mount_row(&mut ui, row, *row_height);
                        }
                        added.push((key.clone(), (row, index_signal)));
                    }
                    entries.extend(added);
                    let mut removed_focus = false;
                    entries.retain(|key, (node, _)| {
                        if unique.contains(key) {
                            true
                        } else {
                            if navigation.is_some()
                                && let Some(focused) = ui.input.focused()
                            {
                                let scene = ui.scene.borrow();
                                removed_focus |= focused == *node
                                    || (scene.contains(focused)
                                        && scene
                                            .ancestors(focused)
                                            .any(|ancestor| ancestor == *node));
                            }
                            ui.remove(*node);
                            false
                        }
                    });
                    for (key, index, ..) in &keys {
                        entries[key].1.set(*index);
                    }
                    {
                        let mut scene = ui.scene.borrow_mut();
                        scene.set_style(
                            viewport,
                            crate::scene::Style {
                                clip: true,
                                ..crate::widgets::fixed(width, height)
                            },
                        );
                        scene.set_style(content, crate::widgets::fixed(width, total));
                        scene.set_transform(
                            content,
                            crate::scene::Transform {
                                x: 0.0,
                                y: -position,
                            },
                        );
                        for (key, _, top, row_height) in &keys {
                            let node = entries[key].0;
                            scene.set_style(node, crate::widgets::fixed(width, *row_height));
                            scene.set_transform(node, crate::scene::Transform { x: 0.0, y: *top });
                        }
                        let order: Vec<_> = keys.iter().map(|(key, ..)| entries[key].0).collect();
                        assert!(scene.reorder_children(content, &order));
                    }
                    transaction.commit();
                    extent.set(total);
                    // Application key/build callbacks may request a new scroll
                    // position. Let the queued pass handle it instead of
                    // replacing that request with this pass's old geometry.
                    let request_unchanged = offset.get().to_bits() == requested.to_bits();
                    if request_unchanged {
                        anchor = next_anchor;
                        offset.set(position);
                    } else {
                        anchor = None;
                    }
                    if let Some(navigation) = &navigation {
                        navigation.update(
                            &ui,
                            root,
                            length,
                            keys.iter()
                                .map(|(key, index, ..)| (*index, entries[key].0))
                                .collect(),
                        );
                        if let Some((serial, _)) = request {
                            handled_request = serial;
                        }
                        if let Some(index) = target.filter(|_| request_unchanged) {
                            if let Some((key, ..)) =
                                keys.iter().find(|(_, candidate, ..)| *candidate == index)
                            {
                                ui.input.focus(&ui.scene, Some(entries[key].0));
                            }
                        } else if removed_focus && ui.input.focused().is_none() {
                            ui.input.focus(&ui.scene, Some(root));
                        }
                    }
                });
            });
        },
    )))
}
