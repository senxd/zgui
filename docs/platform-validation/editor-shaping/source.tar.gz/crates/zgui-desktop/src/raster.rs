use fontdue::{Font, FontSettings, Metrics};
use std::collections::HashMap;
use zgui::scene::{Color, Effects, NodeKind, Rect, Scene};

type StyledGlyphKey = (String, u32, u32, u32, zgui::text_layout::FontStyle);
type StyledGlyphImages = Vec<(i32, i32, cosmic_text::SwashImage)>;
const STYLED_GLYPH_BUDGET: usize = 8 * 1024 * 1024;
fn styled_bytes(key: &StyledGlyphKey, images: &StyledGlyphImages) -> usize {
    key.0.capacity()
        + images.capacity() * std::mem::size_of::<(i32, i32, cosmic_text::SwashImage)>()
        + images
            .iter()
            .map(|(_, _, image)| image.data.capacity())
            .sum::<usize>()
}

/// Persistent CPU backing store with cached glyph masks and damage-only rasterization.
/// Glyph cache is bounded; this backend intentionally favors a small portable implementation.
pub struct Raster {
    pub pixels: Vec<u32>,
    width: usize,
    height: usize,
    font: Font,
    styled_fonts: std::rc::Rc<std::cell::RefCell<Option<zgui_gpu::text::CpuTextRaster>>>,
    styled_glyphs: HashMap<StyledGlyphKey, StyledGlyphImages>,
    glyphs: HashMap<(char, u32), (Metrics, Vec<u8>)>,
    scratch: Vec<u32>,
    background: u32,
    origin: (f32, f32),
}
impl Raster {
    pub fn new(width: usize, height: usize) -> Self {
        Self {
            pixels: vec![0x10141c; width * height],
            width,
            height,
            font: Font::from_bytes(
                include_bytes!("../../../assets/DejaVuSans.ttf") as &[u8],
                FontSettings::default(),
            )
            .expect("bundled font"),
            styled_fonts: Default::default(),
            styled_glyphs: HashMap::new(),
            glyphs: HashMap::new(),
            scratch: Vec::new(),
            background: 0x10141c,
            origin: (0., 0.),
        }
    }
    pub fn resize(&mut self, width: usize, height: usize) {
        self.width = width;
        self.height = height;
        self.pixels.resize(width * height, 0x10141c);
    }
    pub fn render(&mut self, scene: &Scene, damage: &[Rect]) {
        self.render_flat(scene, scene.layer_items(None), damage);
    }
    fn render_flat(
        &mut self,
        scene: &Scene,
        items: Vec<zgui::scene::PaintItem<'_>>,
        damage: &[Rect],
    ) {
        if damage.is_empty() {
            return;
        }
        // Backdrop filters require already-composited pixels behind the filter. The CPU
        // reference path conservatively rebuilds the surface when a filter is present.
        let full = [Rect {
            x: 0.,
            y: 0.,
            width: self.width as f32,
            height: self.height as f32,
        }];
        let has_blur = items.iter().any(|item| item.effects.blur_radius > 0.);
        let damage = if has_blur { &full[..] } else { damage };
        for &dirty in damage {
            let (x0, y0, x1, y1) = self.region(dirty);
            for y in y0..y1 {
                self.pixels[y * self.width + x0..y * self.width + x1].fill(self.background);
            }
            for item in &items {
                let Some(clip) = intersect(dirty, item.clip.unwrap_or(full[0])) else {
                    continue;
                };
                if item.isolated {
                    self.isolated(scene, item, clip);
                    continue;
                }
                let Some(visible) = intersect(
                    clip,
                    if let NodeKind::Quad(style) | NodeKind::Panel { quad: style, .. } = item.kind {
                        style.paint_bounds(item.bounds)
                    } else {
                        item.bounds
                    },
                ) else {
                    continue;
                };
                if item.effects.blur_radius > 0. {
                    self.blur(visible, item.effects.blur_radius.ceil().min(64.) as usize);
                }
                match item.kind {
                    NodeKind::Rect(color) => self.rect(item.bounds, clip, *color, item.effects),
                    NodeKind::Quad(style) | NodeKind::Panel { quad: style, .. } => {
                        self.quad(item.bounds, clip, *style, item.effects)
                    }
                    NodeKind::Image(image) => self.image(item.bounds, clip, image, item.effects),
                    NodeKind::Text {
                        text,
                        color,
                        font_size,
                    } => {
                        if *item.font == Default::default() {
                            self.text(text, item.bounds, clip, *color, *font_size, item.effects)
                        } else {
                            self.styled_text(
                                text,
                                item.bounds,
                                clip,
                                *color,
                                *font_size,
                                item.effects,
                                item.font,
                            )
                        }
                    }
                    _ => {}
                }
            }
        }
    }
    fn isolated(&mut self, scene: &Scene, item: &zgui::scene::PaintItem<'_>, clip: Rect) {
        let bounds = scene.layer_bounds(item.id);
        let x = bounds.x.floor();
        let y = bounds.y.floor();
        let width = ((bounds.x + bounds.width).ceil() - x).max(1.) as usize;
        let height = ((bounds.y + bounds.height).ceil() - y).max(1.) as usize;
        // Reference backend extracts coverage using black/white mattes, preserving
        // its public opaque RGB pixel format. GPU layers store premultiplied RGBA.
        if width
            .checked_mul(height)
            .is_none_or(|n| n > 16 * 1024 * 1024)
        {
            return;
        }
        let make = |background| Self {
            pixels: vec![background; width * height],
            width,
            height,
            font: self.font.clone(),
            styled_fonts: self.styled_fonts.clone(),
            styled_glyphs: HashMap::new(),
            glyphs: HashMap::new(),
            scratch: Vec::new(),
            background,
            origin: (x, y),
        };
        let mut black = make(0);
        let mut white = make(0xffffff);
        let items: Vec<_> = scene
            .layer_items(Some(item.id))
            .into_iter()
            .map(|mut i| {
                i.bounds.x -= x;
                i.bounds.y -= y;
                i.clip = i
                    .clip
                    .map(|r| Rect::new(r.x - x, r.y - y, r.width, r.height));
                i
            })
            .collect();
        let full = [Rect::new(0., 0., width as f32, height as f32)];
        black.render_flat(scene, items.clone(), &full);
        white.render_flat(scene, items, &full);
        let output = Rect::new(
            x - self.origin.0,
            y - self.origin.1,
            width as f32,
            height as f32,
        );
        let Some(visible) = intersect(output, clip) else {
            return;
        };
        if item.effects.blur_radius > 0. {
            self.blur(visible, item.effects.blur_radius.ceil().min(64.) as usize)
        }
        let (x0, y0, x1, y1) = self.region(visible);
        for py in y0..y1 {
            for px in x0..x1 {
                let sx = (px as f32 - output.x) as usize;
                let sy = (py as f32 - output.y) as usize;
                let b = black.pixels[sy * width + sx];
                let w = white.pixels[sy * width + sx];
                let alpha = 255 - ((w & 255) as i32 - (b & 255) as i32).clamp(0, 255);
                if alpha == 0 {
                    continue;
                }
                let channel = |shift: u32| {
                    ((((b >> shift) & 255) * 255 + alpha as u32 / 2) / alpha as u32).min(255) as u8
                };
                let color = Color(channel(16), channel(8), channel(0), alpha as u8);
                blend(
                    &mut self.pixels[py * self.width + px],
                    color,
                    item.effects.opacity
                        * edge_alpha(py as f32, item.bounds, item.effects.edge_fade),
                );
            }
        }
    }
    fn region(&self, rect: Rect) -> (usize, usize, usize, usize) {
        (
            rect.x.floor().clamp(0., self.width as f32) as usize,
            rect.y.floor().clamp(0., self.height as f32) as usize,
            (rect.x + rect.width).ceil().clamp(0., self.width as f32) as usize,
            (rect.y + rect.height).ceil().clamp(0., self.height as f32) as usize,
        )
    }
    fn rect(&mut self, bounds: Rect, clip: Rect, color: Color, effects: Effects) {
        let Some(r) = intersect(bounds, clip) else {
            return;
        };
        let (x0, y0, x1, y1) = self.region(r);
        for y in y0..y1 {
            let edge = edge_alpha(y as f32, bounds, effects.edge_fade);
            for x in x0..x1 {
                blend(
                    &mut self.pixels[y * self.width + x],
                    color,
                    effects.opacity * edge,
                );
            }
        }
    }
    fn image(
        &mut self,
        bounds: Rect,
        clip: Rect,
        image: &zgui::image::ImageData,
        effects: Effects,
    ) {
        let Some(visible) = intersect(bounds, clip) else {
            return;
        };
        let (x0, y0, x1, y1) = self.region(visible);
        for y in y0..y1 {
            for x in x0..x1 {
                let sx = (((x as f32 + 0.5 - bounds.x) / bounds.width * image.width() as f32)
                    as u32)
                    .min(image.width() - 1);
                let sy = (((y as f32 + 0.5 - bounds.y) / bounds.height * image.height() as f32)
                    as u32)
                    .min(image.height() - 1);
                let i = ((sy * image.width() + sx) * 4) as usize;
                let p = &image.pixels()[i..i + 4];
                blend(
                    &mut self.pixels[y * self.width + x],
                    Color(p[0], p[1], p[2], p[3]),
                    effects.opacity * edge_alpha(y as f32, bounds, effects.edge_fade),
                );
            }
        }
    }
    fn quad(&mut self, bounds: Rect, clip: Rect, style: zgui::scene::QuadStyle, effects: Effects) {
        if let Some(shadow) = style.shadow {
            let core = bounds.expand(shadow.spread.max(0.));
            let core = Rect::new(
                core.x + shadow.offset.x,
                core.y + shadow.offset.y,
                core.width,
                core.height,
            );
            if let Some(visible) = intersect(core.expand(shadow.blur_radius.max(0.) * 3.), clip) {
                let (x0, y0, x1, y1) = self.region(visible);
                for y in y0..y1 {
                    for x in x0..x1 {
                        let d = rounded_distance(
                            x as f32 + 0.5,
                            y as f32 + 0.5,
                            core,
                            style.radius + shadow.spread.max(0.),
                        );
                        let alpha =
                            (-0.5 * (d.max(0.) / shadow.blur_radius.max(0.001)).powi(2)).exp();
                        blend(
                            &mut self.pixels[y * self.width + x],
                            shadow.color,
                            alpha * effects.opacity,
                        );
                    }
                }
            }
        }
        let Some(visible) = intersect(bounds, clip) else {
            return;
        };
        let (x0, y0, x1, y1) = self.region(visible);
        for y in y0..y1 {
            for x in x0..x1 {
                let d = rounded_distance(x as f32 + 0.5, y as f32 + 0.5, bounds, style.radius);
                let outer = (0.5 - d).clamp(0., 1.);
                let inner = (0.5 - d - style.border_width.max(0.)).clamp(0., 1.);
                let amount = effects.opacity * edge_alpha(y as f32, bounds, effects.edge_fade);
                let a = style.fill.3 as f32 / 255. * inner
                    + style.border_color.3 as f32 / 255. * (outer - inner);
                if a > 0. {
                    let channel = |fill: u8, border: u8| {
                        ((fill as f32 * style.fill.3 as f32 / 255. * inner
                            + border as f32 * style.border_color.3 as f32 / 255. * (outer - inner))
                            / a)
                            .round() as u8
                    };
                    let c = Color(
                        channel(style.fill.0, style.border_color.0),
                        channel(style.fill.1, style.border_color.1),
                        channel(style.fill.2, style.border_color.2),
                        (a * 255.).round() as u8,
                    );
                    blend(&mut self.pixels[y * self.width + x], c, amount);
                }
            }
        }
    }
    #[allow(clippy::too_many_arguments)]
    fn styled_text(
        &mut self,
        text: &str,
        bounds: Rect,
        clip: Rect,
        color: Color,
        size: f32,
        effects: Effects,
        font: &zgui::text_layout::FontStyle,
    ) {
        let Some(clip) = intersect(bounds, clip) else {
            return;
        };
        let (x0, y0, x1, y1) = self.region(clip);
        // Bound retained shaped data; default-font text keeps the lightweight fontdue path.
        let key = (
            text.to_owned(),
            size.to_bits(),
            bounds.width.to_bits(),
            bounds.height.to_bits(),
            font.clone(),
        );
        let mut oversized = false;
        if !self.styled_glyphs.contains_key(&key) {
            let images = self
                .styled_fonts
                .borrow_mut()
                .get_or_insert_with(Default::default)
                .rasterize(text, size, bounds.width, bounds.height, font);
            let new_bytes = styled_bytes(&key, &images);
            let bytes: usize = self
                .styled_glyphs
                .iter()
                .map(|(key, images)| styled_bytes(key, images))
                .sum();
            if self.styled_glyphs.len() >= 128
                || bytes.saturating_add(new_bytes) > STYLED_GLYPH_BUDGET
            {
                self.styled_glyphs.clear();
            }
            oversized = new_bytes > STYLED_GLYPH_BUDGET;
            self.styled_glyphs.insert(key.clone(), images);
        }
        for (x, y, image) in &self.styled_glyphs[&key] {
            let gx = bounds.x.floor() as i32 + x + image.placement.left;
            let gy = bounds.y.floor() as i32 + y - image.placement.top;
            for by in 0..image.placement.height as usize {
                let py = gy + by as i32;
                if py < y0 as i32 || py >= y1 as i32 {
                    continue;
                }
                for bx in 0..image.placement.width as usize {
                    let px = gx + bx as i32;
                    if px < x0 as i32 || px >= x1 as i32 {
                        continue;
                    }
                    let i = by * image.placement.width as usize + bx;
                    let (ink, alpha) = match image.content {
                        cosmic_text::SwashContent::Mask => (color, image.data[i] as f32 / 255.),
                        cosmic_text::SwashContent::Color => (
                            Color(
                                image.data[i * 4],
                                image.data[i * 4 + 1],
                                image.data[i * 4 + 2],
                                color.3,
                            ),
                            image.data[i * 4 + 3] as f32 / 255.,
                        ),
                        cosmic_text::SwashContent::SubpixelMask => {
                            (color, image.data[i * 4] as f32 / 255.)
                        }
                    };
                    blend(
                        &mut self.pixels[py as usize * self.width + px as usize],
                        ink,
                        effects.opacity * edge_alpha(py as f32, bounds, effects.edge_fade) * alpha,
                    );
                }
            }
        }
        if oversized {
            self.styled_glyphs.remove(&key);
        }
    }
    fn text(
        &mut self,
        text: &str,
        bounds: Rect,
        clip: Rect,
        color: Color,
        size: f32,
        effects: Effects,
    ) {
        let Some(clip) = intersect(bounds, clip) else {
            return;
        };
        let (x0, y0, x1, y1) = self.region(clip);
        let mut x = bounds.x;
        let mut baseline = bounds.y + size;
        let line_height = zgui::text_layout::LineHeight::default().resolve(size);
        for ch in text.chars() {
            if ch == '\n' {
                x = bounds.x;
                baseline += line_height;
                continue;
            }
            if self.glyphs.len() >= 4096 {
                self.glyphs.clear();
            }
            let (m, bitmap) = self
                .glyphs
                .entry((ch, size.to_bits()))
                .or_insert_with(|| self.font.rasterize(ch, size));
            if x + m.advance_width > bounds.x + bounds.width {
                x = bounds.x;
                baseline += line_height;
            }
            if baseline - size > clip.y + clip.height {
                break;
            }
            let gx = x.floor() as i32 + m.xmin;
            let gy = baseline.floor() as i32 - m.height as i32 - m.ymin;
            for by in 0..m.height {
                let py = gy + by as i32;
                if py < y0 as i32 || py >= y1 as i32 {
                    continue;
                }
                for bx in 0..m.width {
                    let px = gx + bx as i32;
                    if px < x0 as i32 || px >= x1 as i32 {
                        continue;
                    }
                    blend(
                        &mut self.pixels[py as usize * self.width + px as usize],
                        color,
                        effects.opacity
                            * edge_alpha(py as f32, bounds, effects.edge_fade)
                            * bitmap[by * m.width + bx] as f32
                            / 255.,
                    );
                }
            }
            x += m.advance_width;
        }
    }
    // Separable sliding-window box filter: O(area), independent of blur radius.
    fn blur(&mut self, bounds: Rect, radius: usize) {
        if radius == 0 {
            return;
        }
        let expanded = Rect {
            x: bounds.x - radius as f32,
            y: bounds.y - radius as f32,
            width: bounds.width + 2. * radius as f32,
            height: bounds.height + 2. * radius as f32,
        };
        let (x0, y0, x1, y1) = self.region(expanded);
        if x0 >= x1 || y0 >= y1 {
            return;
        }
        let w = x1 - x0;
        let h = y1 - y0;
        self.scratch.resize(w * h, 0);
        for y in 0..h {
            let mut sum = [0u64; 3];
            let mut left = 0;
            let mut right = 0;
            for x in 0..w {
                let end = (x + radius + 1).min(w);
                while right < end {
                    add(&mut sum, self.pixels[(y + y0) * self.width + x0 + right]);
                    right += 1;
                }
                let start = x.saturating_sub(radius);
                while left < start {
                    sub(&mut sum, self.pixels[(y + y0) * self.width + x0 + left]);
                    left += 1;
                }
                self.scratch[y * w + x] = pack(sum, (right - left) as u64);
            }
        }
        let (bx0, by0, bx1, by1) = self.region(bounds);
        for x in bx0..bx1 {
            let mut sum = [0u64; 3];
            let mut top = 0;
            let mut bottom = 0;
            for y in 0..h {
                let end = (y + radius + 1).min(h);
                while bottom < end {
                    add(&mut sum, self.scratch[bottom * w + x - x0]);
                    bottom += 1;
                }
                let start = y.saturating_sub(radius);
                while top < start {
                    sub(&mut sum, self.scratch[top * w + x - x0]);
                    top += 1;
                }
                if y + y0 >= by0 && y + y0 < by1 {
                    self.pixels[(y + y0) * self.width + x] = pack(sum, (bottom - top) as u64);
                }
            }
        }
    }
    pub fn write_ppm(&self, path: &std::path::Path) -> std::io::Result<()> {
        use std::io::Write;
        let mut out = std::io::BufWriter::new(std::fs::File::create(path)?);
        write!(out, "P6\n{} {}\n255\n", self.width, self.height)?;
        for p in &self.pixels {
            out.write_all(&[(p >> 16) as u8, (p >> 8) as u8, *p as u8])?;
        }
        Ok(())
    }
}
fn add(s: &mut [u64; 3], p: u32) {
    s[0] += ((p >> 16) & 255) as u64;
    s[1] += ((p >> 8) & 255) as u64;
    s[2] += (p & 255) as u64;
}
fn sub(s: &mut [u64; 3], p: u32) {
    s[0] -= ((p >> 16) & 255) as u64;
    s[1] -= ((p >> 8) & 255) as u64;
    s[2] -= (p & 255) as u64;
}
fn pack(s: [u64; 3], n: u64) -> u32 {
    ((s[0] / n) as u32) << 16 | ((s[1] / n) as u32) << 8 | (s[2] / n) as u32
}
fn blend(pixel: &mut u32, c: Color, opacity: f32) {
    let a = (c.3 as f32 * opacity.clamp(0., 1.)).round() as u32;
    let inv = 255 - a;
    let r = (c.0 as u32 * a + ((*pixel >> 16) & 255) * inv + 127) / 255;
    let g = (c.1 as u32 * a + ((*pixel >> 8) & 255) * inv + 127) / 255;
    let b = (c.2 as u32 * a + (*pixel & 255) * inv + 127) / 255;
    *pixel = (r << 16) | (g << 8) | b;
}
fn intersect(a: Rect, b: Rect) -> Option<Rect> {
    let x = a.x.max(b.x);
    let y = a.y.max(b.y);
    let width = (a.x + a.width).min(b.x + b.width) - x;
    let height = (a.y + a.height).min(b.y + b.height) - y;
    (width > 0. && height > 0.).then_some(Rect {
        x,
        y,
        width,
        height,
    })
}

fn edge_alpha(y: f32, bounds: Rect, fade: f32) -> f32 {
    if fade > 0. {
        ((y + 0.5 - bounds.y).min(bounds.y + bounds.height - y - 0.5) / fade).clamp(0., 1.)
    } else {
        1.
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use zgui::scene::{Effects, Layout, NodeKind, Style, Transform};
    #[test]
    fn panel_background_border_and_children_have_correct_paint_order() {
        use zgui::scene::{Insets, QuadStyle};
        let mut scene = Scene::new(40., 40.);
        let panel = scene.append(
            scene.root(),
            NodeKind::Panel {
                layout: Layout::Row,
                quad: QuadStyle {
                    fill: Color(20, 40, 60, 255),
                    radius: 4.,
                    border_color: Color(200, 100, 0, 255),
                    border_width: 2.,
                    ..Default::default()
                },
            },
            Style {
                width: Some(40.),
                height: Some(40.),
                padding_edges: Some(Insets {
                    left: 10.,
                    top: 12.,
                    right: 3.,
                    bottom: 5.,
                }),
                ..Default::default()
            },
        );
        scene.append(
            panel,
            NodeKind::Rect(Color(255, 0, 0, 255)),
            Style {
                width: Some(8.),
                height: Some(8.),
                ..Default::default()
            },
        );
        let mut raster = Raster::new(40, 40);
        let damage = scene.flush().damage;
        raster.render(&scene, &damage);
        assert_eq!(raster.pixels[6 * 40 + 6], 0x14283c);
        assert_eq!(raster.pixels[14 * 40 + 12], 0xff0000);
        assert_eq!(raster.pixels[40 + 20], 0xc86400);
    }
    fn scene() -> Scene {
        let mut s = Scene::new(100., 80.);
        s.set_kind(s.root(), NodeKind::Container(Layout::Overlay));
        s
    }
    fn rectangle(s: &mut Scene, x: f32, color: Color) -> zgui::scene::NodeId {
        let id = s.append(
            s.root(),
            NodeKind::Rect(color),
            Style {
                width: Some(30.),
                height: Some(30.),
                ..Default::default()
            },
        );
        s.set_transform(id, Transform { x, y: 10. });
        id
    }
    #[test]
    fn incremental_matches_full_after_move_opacity_and_removal() {
        let mut s = scene();
        rectangle(&mut s, 5., Color(80, 20, 20, 255));
        let top = rectangle(&mut s, 20., Color(0, 200, 255, 150));
        let mut partial = Raster::new(100, 80);
        let mut full = Raster::new(100, 80);
        let damage = s.flush().damage;
        partial.render(&s, &damage);
        for step in 0..4 {
            match step {
                0 => s.set_transform(top, Transform { x: 40., y: 20. }),
                1 => s.set_effects(
                    top,
                    Effects {
                        opacity: 0.4,
                        ..Default::default()
                    },
                ),
                2 => s.remove(top),
                _ => {}
            }
            let damage = s.flush().damage;
            partial.render(&s, &damage);
            full.render(&s, &[Rect::new(0., 0., 100., 80.)]);
            assert!(
                partial.pixels == full.pixels,
                "incremental image differs from full repaint at step {step}"
            );
        }
    }
    #[test]
    fn blur_and_edge_fade_change_pixels_and_stay_stable() {
        let mut s = scene();
        rectangle(&mut s, 10., Color(255, 255, 255, 255));
        let glass = rectangle(&mut s, 25., Color(50, 80, 160, 100));
        s.set_effects(
            glass,
            Effects {
                opacity: 0.8,
                blur_radius: 4.,
                edge_fade: 8.,
            },
        );
        let mut r = Raster::new(100, 80);
        let damage = s.flush().damage;
        r.render(&s, &damage);
        let expected = r.pixels.clone();
        r.render(&s, &[Rect::new(0., 0., 100., 80.)]);
        assert_eq!(expected, r.pixels);
        s.set_effects(glass, Effects::default());
        let damage = s.flush().damage;
        r.render(&s, &damage);
        assert_ne!(expected, r.pixels);
    }
}

fn rounded_distance(x: f32, y: f32, bounds: Rect, radius: f32) -> f32 {
    let r = radius.max(0.).min(bounds.width.min(bounds.height) * 0.5);
    let qx = (x - bounds.x - bounds.width * 0.5).abs() - bounds.width * 0.5 + r;
    let qy = (y - bounds.y - bounds.height * 0.5).abs() - bounds.height * 0.5 + r;
    qx.max(0.).hypot(qy.max(0.)) + qx.max(qy).min(0.) - r
}

#[cfg(test)]
mod extended_tests {
    use super::*;
    use zgui::scene::{BoxShadow, Layout, QuadStyle, Style, Transform};
    #[test]
    fn shadow_damage_and_clipped_images_match_full_repaint() {
        let mut raster = Raster::new(80, 60);
        let mut scene = Scene::new(80., 60.);
        scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
        let quad = scene.append(
            scene.root(),
            NodeKind::Quad(QuadStyle {
                fill: Color(230, 30, 40, 255),
                radius: 8.,
                border_color: Color(0, 255, 0, 255),
                border_width: 2.,
                shadow: Some(BoxShadow {
                    color: Color(0, 0, 0, 160),
                    offset: Transform { x: -8., y: 3. },
                    blur_radius: 3.,
                    spread: 2.,
                }),
            }),
            Style {
                width: Some(24.),
                height: Some(24.),
                ..Default::default()
            },
        );
        scene.set_transform(quad, Transform { x: 20., y: 10. });
        let d = scene.flush().damage;
        raster.render(&scene, &d);
        scene.set_transform(quad, Transform { x: 45., y: 25. });
        let d = scene.flush().damage;
        raster.render(&scene, &d);
        let partial = raster.pixels.clone();
        raster.render(&scene, &[Rect::new(0., 0., 80., 60.)]);
        assert_eq!(partial, raster.pixels);
        let image =
            std::sync::Arc::new(zgui::image::ImageData::new(1, 1, vec![255, 0, 255, 255]).unwrap());
        scene.append(
            scene.root(),
            NodeKind::Image(image),
            Style {
                width: Some(10.),
                height: Some(10.),
                ..Default::default()
            },
        );
        let d = scene.flush().damage;
        raster.render(&scene, &d);
        assert_eq!(raster.pixels[0], 0xff00ff);
    }
}

#[cfg(test)]
mod isolation_tests {
    use super::*;
    use zgui::scene::{Layout, Style, Transform};
    #[test]
    fn opacity_is_applied_once_to_overlapping_children() {
        let mut scene = Scene::new(40., 30.);
        let group = scene.append(
            scene.root(),
            NodeKind::Container(Layout::Overlay),
            Style {
                width: Some(20.),
                height: Some(20.),
                ..Default::default()
            },
        );
        scene.set_isolated(group, true);
        scene.set_effects(
            group,
            Effects {
                opacity: 0.5,
                ..Default::default()
            },
        );
        scene.append(
            group,
            NodeKind::Rect(Color(255, 0, 0, 255)),
            Style {
                width: Some(20.),
                height: Some(20.),
                ..Default::default()
            },
        );
        let blue = scene.append(
            group,
            NodeKind::Rect(Color(0, 0, 255, 255)),
            Style {
                width: Some(12.),
                height: Some(20.),
                ..Default::default()
            },
        );
        scene.set_transform(blue, Transform { x: 8., y: 0. });
        let mut raster = Raster::new(40, 30);
        let d = scene.flush().damage;
        raster.render(&scene, &d);
        let p = raster.pixels[10 * 40 + 12];
        assert!(
            ((p >> 16) & 255) < 20,
            "red backdrop must not leak through the isolated blue child"
        );
        assert!((p & 255) > 130);
        scene.set_transform(group, Transform { x: 10., y: 5. });
        let d = scene.flush().damage;
        raster.render(&scene, &d);
        let partial = raster.pixels.clone();
        raster.render(&scene, &[Rect::new(0., 0., 40., 30.)]);
        assert_eq!(partial, raster.pixels);
    }
}

#[cfg(test)]
mod line_height_tests {
    use super::*;
    use zgui::{
        scene::Style,
        text_layout::{FontStyle, LineHeight},
    };

    #[test]
    fn changing_line_pitch_repairs_old_pixels_and_keys_software_shapes() {
        let mut scene = Scene::new(120., 100.);
        let node = scene.append(
            scene.root(),
            NodeKind::Text {
                text: "M\nM".into(),
                color: Color(255, 255, 255, 255),
                font_size: 18.,
            },
            Style {
                width: Some(80.),
                height: Some(90.),
                ..Default::default()
            },
        );
        let mut incremental = Raster::new(120, 100);
        for pitch in [40., 8., 24., 40.] {
            scene.set_font(
                node,
                FontStyle {
                    line_height: LineHeight::px(pitch),
                    ..Default::default()
                },
            );
            let damage = scene.flush().damage;
            assert!(!damage.is_empty());
            incremental.render(&scene, &damage);
            let mut fresh = Raster::new(120, 100);
            fresh.render(&scene, &[Rect::new(0., 0., 120., 100.)]);
            assert_eq!(incremental.pixels, fresh.pixels, "pitch {pitch}");
            assert!(
                incremental
                    .styled_glyphs
                    .keys()
                    .any(|key| key.4.line_height == LineHeight::px(pitch))
            );
            let cache_size = incremental.styled_glyphs.len();
            scene.set_font(
                node,
                FontStyle {
                    line_height: LineHeight::px(pitch),
                    ..Default::default()
                },
            );
            let idle = scene.flush().damage;
            assert!(idle.is_empty());
            incremental.render(&scene, &idle);
            assert_eq!(incremental.styled_glyphs.len(), cache_size);
        }
    }
}
