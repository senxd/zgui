//! Reusable shaped text geometry for editor hit testing, carets and bidi selections.
pub use cosmic_text::Affinity;
use cosmic_text::{Attrs, Buffer, Family, FontSystem, Metrics, Shaping};
use std::{ops::Range, sync::Arc};
use unicode_segmentation::UnicodeSegmentation;
use zgui::scene::Rect;
pub(crate) fn attrs(font: &zgui::text_layout::FontStyle) -> Attrs<'_> {
    use zgui::text_layout::FontFamily;
    let family = match &font.family {
        FontFamily::SansSerif => Family::SansSerif,
        FontFamily::Serif => Family::Serif,
        FontFamily::Monospace => Family::Monospace,
        FontFamily::Named(name) => Family::Name(name),
    };
    Attrs::new()
        .family(family)
        .weight(cosmic_text::Weight(font.weight.clamp(1, 1000)))
        .style(if font.italic {
            cosmic_text::Style::Italic
        } else {
            cosmic_text::Style::Normal
        })
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TextCursor {
    pub byte_index: usize,
    pub affinity: Affinity,
}
/// Owns a shaped text buffer. Reuse it until text/font/width changes.
/// Coordinates are logical pixels relative to the text node origin.
/// Ligature interiors divide the advance among graphemes, matching cosmic-text's
/// editor convention. This does not read font-specific GDEF ligature caret tables.
pub struct ShapedText {
    buffer: Buffer,
    text: Arc<str>,
    line_offsets: Vec<usize>,
    line_height: f32,
}
impl ShapedText {
    pub fn new(
        fonts: &mut FontSystem,
        text: impl Into<Arc<str>>,
        font_size: f32,
        width: Option<f32>,
    ) -> Self {
        Self::with_font(fonts, text, font_size, width, &Default::default())
    }
    pub fn with_font(
        fonts: &mut FontSystem,
        text: impl Into<Arc<str>>,
        font_size: f32,
        width: Option<f32>,
        font: &zgui::text_layout::FontStyle,
    ) -> Self {
        let text = text.into();
        let size = font_size.max(1.);
        let line_height = font.line_height.resolve(size);
        let mut buffer = Buffer::new(fonts, Metrics::new(size, line_height));
        buffer.set_size(fonts, width, None);
        buffer.set_text(fonts, &text, &attrs(font), Shaping::Advanced);
        // cosmic-text's line iterator omits a trailing empty line. Editors
        // still need a visual row for the caret after a final line ending.
        if text.ends_with(['\r', '\n']) {
            buffer.lines.push(cosmic_text::BufferLine::new(
                "",
                cosmic_text::LineEnding::None,
                cosmic_text::AttrsList::new(&attrs(font)),
                Shaping::Advanced,
            ));
        }
        buffer.shape_until_scroll(fonts, false);
        let mut offset = 0;
        let line_offsets = buffer
            .lines
            .iter()
            .map(|line| {
                let start = offset;
                offset += line.text().len() + line.ending().as_str().len();
                start
            })
            .collect();
        Self {
            buffer,
            text,
            line_offsets,
            line_height,
        }
    }
    pub fn text(&self) -> &str {
        &self.text
    }
    pub fn size(&self) -> (f32, f32) {
        self.buffer
            .layout_runs()
            .fold((0_f32, 0_f32), |(w, h), run| {
                (w.max(run.line_w), h.max(run.line_top + run.line_height))
            })
    }
    pub fn hit_test(&self, x: f32, y: f32) -> Option<TextCursor> {
        let cursor = self.buffer.hit(x, y)?;
        Some(TextCursor {
            byte_index: self.line_offsets.get(cursor.line)? + cursor.index,
            affinity: cursor.affinity,
        })
    }
    pub fn caret(&self, cursor: TextCursor) -> Option<Rect> {
        if cursor.byte_index > self.text.len() || !self.text.is_char_boundary(cursor.byte_index) {
            return None;
        }
        let mut fallback = None;
        for run in self.buffer.layout_runs() {
            let offset = self.line_offsets[run.line_i];
            if run.glyphs.is_empty() && cursor.byte_index == offset {
                return Some(Rect::new(0., run.line_top, 1., run.line_height));
            }
            for glyph in run.glyphs {
                let start = offset + glyph.start;
                let end = offset + glyph.end;
                if cursor.byte_index < start || cursor.byte_index > end {
                    continue;
                }
                let cluster = &self.text[start..end];
                let count = cluster.graphemes(true).count().max(1);
                let before = cluster
                    .grapheme_indices(true)
                    .filter(|(i, _)| start + i < cursor.byte_index)
                    .count();
                let fraction = before as f32 / count as f32;
                let x = if glyph.level.is_rtl() {
                    glyph.x + glyph.w * (1. - fraction)
                } else {
                    glyph.x + glyph.w * fraction
                };
                let rect = Rect::new(x, run.line_top, 1., run.line_height);
                if (cursor.byte_index == start && cursor.affinity == Affinity::After)
                    || (cursor.byte_index == end && cursor.affinity == Affinity::Before)
                    || (cursor.byte_index > start && cursor.byte_index < end)
                {
                    return Some(rect);
                }
                fallback = Some(rect);
            }
        }
        fallback
    }
    /// Returns visual rectangles, including disjoint spans for mixed-direction text.
    pub fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        let start = range.start.min(range.end);
        let end = range.start.max(range.end).min(self.text.len());
        if start >= end {
            return Vec::new();
        }
        let mut rectangles: Vec<Rect> = Vec::new();
        for run in self.buffer.layout_runs() {
            let offset = self.line_offsets[run.line_i];
            let mut spans = Vec::new();
            for glyph in run.glyphs {
                let cluster_start = offset + glyph.start;
                let cluster_end = offset + glyph.end;
                if cluster_start >= end || cluster_end <= start {
                    continue;
                }
                let cluster = &self.text[cluster_start..cluster_end];
                let count = cluster.graphemes(true).count().max(1);
                for (index, (local, grapheme)) in cluster.grapheme_indices(true).enumerate() {
                    if cluster_start + local >= end
                        || cluster_start + local + grapheme.len() <= start
                    {
                        continue;
                    }
                    let width = glyph.w / count as f32;
                    let x = if glyph.level.is_rtl() {
                        glyph.x + glyph.w - (index + 1) as f32 * width
                    } else {
                        glyph.x + index as f32 * width
                    };
                    spans.push(Rect::new(x, run.line_top, width, run.line_height));
                }
            }
            spans.sort_by(|a, b| a.x.total_cmp(&b.x));
            for span in spans {
                if let Some(last) = rectangles.last_mut()
                    && last.y == span.y
                    && last.x + last.width >= span.x - 0.01
                {
                    *last = last.union(span);
                    continue;
                }
                rectangles.push(span);
            }
        }
        rectangles
    }
    pub fn line_height(&self) -> f32 {
        self.line_height
    }
}

impl zgui::text_layout::TextLayout for ShapedText {
    fn cache_weight(&self) -> Option<usize> {
        // Charge capacities of all publicly inspectable owned shape/layout
        // vectors, including spare capacity. cosmic-text hides String capacity
        // and attribute allocation details, so private strings receive twice
        // their length plus a per-line allowance. This deliberately conservative
        // accounting estimate is not an allocator/RSS upper bound. FontSystem
        // and its shared font/shape scratch caches are not owned by this layout.
        fn vector_bytes<T>(values: &Vec<T>) -> usize {
            values.capacity().saturating_mul(std::mem::size_of::<T>())
        }
        let mut bytes = std::mem::size_of::<Self>()
            .saturating_add(self.text.len())
            .saturating_add(2 * std::mem::size_of::<usize>())
            .saturating_add(vector_bytes(&self.line_offsets))
            .saturating_add(vector_bytes(&self.buffer.lines));
        for line in &self.buffer.lines {
            let family_bytes = match line.attrs_list().defaults().family {
                Family::Name(name) => name.len(),
                _ => 0,
            };
            bytes = bytes.saturating_add(
                line.text()
                    .len()
                    .saturating_add(family_bytes)
                    .saturating_mul(2)
                    .saturating_add(128),
            );
            if let Some(shape) = line.shape_opt() {
                bytes = bytes.saturating_add(vector_bytes(&shape.spans));
                for span in &shape.spans {
                    bytes = bytes.saturating_add(vector_bytes(&span.words));
                    for word in &span.words {
                        bytes = bytes.saturating_add(vector_bytes(&word.glyphs));
                    }
                }
            }
            if let Some(layout) = line.layout_opt() {
                bytes = bytes.saturating_add(vector_bytes(layout));
                for row in layout {
                    bytes = bytes.saturating_add(vector_bytes(&row.glyphs));
                }
            }
        }
        Some(bytes)
    }
    fn size(&self) -> (f32, f32) {
        ShapedText::size(self)
    }
    fn hit_test(&self, x: f32, y: f32) -> usize {
        ShapedText::hit_test(self, x, y).map_or(0, |cursor| cursor.byte_index)
    }
    fn hit_position(&self, x: f32, y: f32) -> zgui::text_layout::TextPosition {
        use zgui::text_layout::{TextAffinity, TextPosition};
        ShapedText::hit_test(self, x, y).map_or_else(TextPosition::default, |cursor| TextPosition {
            byte_offset: cursor.byte_index,
            affinity: match cursor.affinity {
                Affinity::Before => TextAffinity::Before,
                Affinity::After => TextAffinity::After,
            },
        })
    }
    fn caret(&self, byte_offset: usize) -> Rect {
        self.caret_position(zgui::text_layout::TextPosition {
            byte_offset,
            affinity: zgui::text_layout::TextAffinity::After,
        })
    }
    fn caret_position(&self, position: zgui::text_layout::TextPosition) -> Rect {
        use zgui::text_layout::TextAffinity;
        let offset = if position.byte_offset >= self.text.len() {
            self.text.len()
        } else {
            self.text
                .grapheme_indices(true)
                .map(|(i, _)| i)
                .take_while(|&i| i <= position.byte_offset)
                .last()
                .unwrap_or(0)
        };
        let affinity = match position.affinity {
            TextAffinity::Before => Affinity::Before,
            TextAffinity::After => Affinity::After,
        };
        ShapedText::caret(
            self,
            TextCursor {
                byte_index: offset,
                affinity,
            },
        )
        .or_else(|| {
            ShapedText::caret(
                self,
                TextCursor {
                    byte_index: offset,
                    affinity: match affinity {
                        Affinity::Before => Affinity::After,
                        Affinity::After => Affinity::Before,
                    },
                },
            )
        })
        .unwrap_or(Rect::new(0., 0., 1., self.line_height))
    }
    fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        ShapedText::selection(self, range)
    }
}

/// Lazy software shaping/rasterization for the reference backend's styled fonts.
/// Glyph images are not retained in Swash's unbounded internal image map.
pub struct CpuTextRaster {
    fonts: FontSystem,
    swash: cosmic_text::SwashCache,
}
impl Default for CpuTextRaster {
    fn default() -> Self {
        Self {
            fonts: FontSystem::new(),
            swash: cosmic_text::SwashCache::new(),
        }
    }
}
impl CpuTextRaster {
    pub fn rasterize(
        &mut self,
        text: &str,
        size: f32,
        width: f32,
        height: f32,
        font: &zgui::text_layout::FontStyle,
    ) -> Vec<(i32, i32, cosmic_text::SwashImage)> {
        let size = size.max(1.);
        let mut buffer = Buffer::new(
            &mut self.fonts,
            Metrics::new(size, font.line_height.resolve(size)),
        );
        buffer.set_size(&mut self.fonts, Some(width), Some(height));
        buffer.set_text(&mut self.fonts, text, &attrs(font), Shaping::Advanced);
        buffer.shape_until_scroll(&mut self.fonts, false);
        let mut images = Vec::new();
        for run in buffer.layout_runs() {
            for glyph in run.glyphs {
                let physical = glyph.physical((0., 0.), 1.);
                if let Some(image) = self
                    .swash
                    .get_image_uncached(&mut self.fonts, physical.cache_key)
                {
                    images.push((physical.x, physical.y + run.line_y as i32, image));
                }
            }
        }
        images
    }
}

#[cfg(test)]
mod visual_line_tests {
    use super::*;
    use zgui::text_layout::{TextAffinity, TextLayout, TextPosition};

    #[test]
    fn wrapped_unicode_hit_caret_and_selection_share_visual_lines() {
        let mut fonts = FontSystem::new();
        let content = "aébcdefghijklmnop";
        let layout = ShapedText::new(&mut fonts, content, 18., Some(48.));
        let end = layout.visual_line_edge(TextPosition::default(), true);
        assert!(end.byte_offset > 0 && end.byte_offset < content.len());
        assert_eq!(end.affinity, TextAffinity::Before);
        let upstream = layout.caret_position(end);
        let next = TextPosition {
            affinity: TextAffinity::After,
            ..end
        };
        let downstream = layout.caret_position(next);
        assert_eq!(upstream.y, 0.);
        assert!(downstream.y > upstream.y);
        assert_eq!(
            layout.visual_line_edge(next, false).byte_offset,
            end.byte_offset
        );
        assert_eq!(layout.hit_position(f32::MAX, upstream.y + 1.), end);
        assert_eq!(layout.hit_position(-1., downstream.y + 1.), next);
        let selection = TextLayout::selection(&layout, 0..content.len());
        assert!(selection.len() > 1);
        assert!(selection.iter().all(|r| r.width > 0. && r.height > 0.));
        for rect in &selection {
            for x in [rect.x, rect.x + rect.width * 0.5, rect.x + rect.width] {
                let position = layout.hit_position(x, rect.y + 1.);
                assert!(
                    content
                        .grapheme_indices(true)
                        .any(|(i, _)| i == position.byte_offset)
                        || position.byte_offset == content.len()
                );
                assert!((layout.caret_position(position).y - rect.y).abs() < 0.1);
            }
        }
    }

    #[test]
    fn combining_interior_snaps_to_grapheme_and_crlf_edges_stay_on_line() {
        let mut fonts = FontSystem::new();
        let layout = ShapedText::new(&mut fonts, "e\u{301}x\r\n\n", 18., Some(200.));
        assert_eq!(TextLayout::caret(&layout, 1), TextLayout::caret(&layout, 0));
        assert_eq!(TextLayout::caret(&layout, 2), TextLayout::caret(&layout, 0));
        let end = layout.visual_line_edge(TextPosition::default(), true);
        assert_eq!(end.byte_offset, 4);
        assert_eq!(layout.caret_position(end).y, 0.);
        let final_line = TextPosition {
            byte_offset: 7,
            affinity: TextAffinity::After,
        };
        assert!(layout.caret_position(final_line).y > layout.line_height());
        assert_eq!(layout.visual_line_edge(final_line, false).byte_offset, 7);
    }

    #[test]
    fn bidi_visual_edges_stay_on_the_selected_wrapped_row() {
        let mut fonts = FontSystem::new();
        for content in ["אבגדהוזחטיכלמנסעפצקרשת", "abc אבג xyz אבג def"]
        {
            let layout = ShapedText::new(&mut fonts, content, 18., Some(70.));
            assert!(layout.size().1 > layout.line_height());
            for run in layout.buffer.layout_runs() {
                let position = layout.hit_position(run.line_w * 0.5, run.line_top + 1.);
                let start = layout.visual_line_edge(position, false);
                let end = layout.visual_line_edge(position, true);
                let left = layout.caret_position(start);
                let right = layout.caret_position(end);
                assert_eq!(left.y, run.line_top, "{content:?} {start:?}");
                assert_eq!(right.y, run.line_top, "{content:?} {end:?}");
                assert!(left.x <= right.x, "{content:?}: {left:?} {right:?}");
                assert!(content.is_char_boundary(start.byte_offset));
                assert!(content.is_char_boundary(end.byte_offset));
            }
        }
    }
}

#[cfg(test)]
mod line_height_tests {
    use super::*;
    use zgui::text_layout::{FontStyle, LineHeight, TextLayout, TextPosition};

    #[test]
    fn explicit_pitch_matches_carets_hit_selection_and_trailing_empty_line() {
        let mut fonts = FontSystem::new();
        for pitch in [8., 24., 40.] {
            let font = FontStyle {
                line_height: LineHeight::px(pitch),
                ..Default::default()
            };
            let layout = ShapedText::with_font(&mut fonts, "abc\ndef\n", 18., None, &font);
            assert_eq!(layout.line_height(), pitch);
            assert_eq!(layout.size().1, pitch * 3.);
            for (offset, row) in [(0, 0.), (4, 1.), (8, 2.)] {
                let caret = TextLayout::caret(&layout, offset);
                assert_eq!(caret.y, row * pitch);
                assert_eq!(caret.height, pitch);
                let hit = layout.hit_position(0., row * pitch + pitch * 0.5);
                assert_eq!(hit.byte_offset, offset);
                assert_eq!(layout.visual_line_edge(hit, false).byte_offset, offset);
            }
            let selection = layout.selection(0..7);
            assert_eq!(selection.len(), 2);
            assert_eq!(selection[0].height, pitch);
            assert_eq!(selection[1].y, pitch);
            assert_eq!(selection[1].height, pitch);
        }
    }

    #[test]
    fn custom_pitch_preserves_wrapping_and_visual_edges() {
        let mut fonts = FontSystem::new();
        let content = "alpha beta gamma delta";
        let normal = ShapedText::new(&mut fonts, content, 18., Some(60.));
        let font = FontStyle {
            line_height: LineHeight::px(37.),
            ..Default::default()
        };
        let spaced = ShapedText::with_font(&mut fonts, content, 18., Some(60.), &font);
        let normal_rows: Vec<_> = normal.buffer.layout_runs().collect();
        let spaced_rows: Vec<_> = spaced.buffer.layout_runs().collect();
        assert!(normal_rows.len() > 1);
        assert_eq!(normal_rows.len(), spaced_rows.len());
        assert_eq!(spaced.size().1, 37. * spaced_rows.len() as f32);
        for (index, (a, b)) in normal_rows.iter().zip(&spaced_rows).enumerate() {
            assert_eq!(a.line_w, b.line_w);
            assert_eq!(b.line_top, 37. * index as f32);
            let hit = spaced.hit_position(0., b.line_top + 1.);
            assert_eq!(spaced.caret_position(hit).y, b.line_top);
            let end = spaced.visual_line_edge(hit, true);
            assert_eq!(spaced.caret_position(end).y, b.line_top);
        }
        assert_eq!(
            normal
                .visual_line_edge(TextPosition::default(), true)
                .byte_offset,
            spaced
                .visual_line_edge(TextPosition::default(), true)
                .byte_offset
        );
    }

    #[test]
    fn software_shaping_uses_the_same_explicit_pitch() {
        let mut raster = CpuTextRaster::default();
        for pitch in [8., 40.] {
            let font = FontStyle {
                line_height: LineHeight::px(pitch),
                ..Default::default()
            };
            let images = raster.rasterize("M\nM", 18., 100., 100., &font);
            assert_eq!(images.len(), 2);
            assert_eq!(images[1].1 - images[0].1, pitch as i32);
            assert_eq!(images[0].2.data, images[1].2.data);
        }
    }

    #[test]
    fn default_measurement_includes_the_same_trailing_caret_row() {
        let mut fonts = FontSystem::new();
        let layout = ShapedText::new(&mut fonts, "text\n", 18., None);
        assert_eq!(
            super::super::measure_text(&mut fonts, "text\n", 18., None),
            layout.size()
        );
        assert_eq!(layout.size().1, layout.line_height() * 2.);
    }
}

#[cfg(test)]
mod cache_weight_tests {
    use super::*;
    use zgui::text_layout::TextLayout;

    #[test]
    fn native_accounting_includes_shape_and_layout_capacities() {
        let mut fonts = FontSystem::new();
        let mut layout = ShapedText::new(&mut fonts, "alpha beta\ngamma\n", 18., Some(45.));
        let weight = layout.cache_weight().unwrap();
        let rows: Vec<_> = layout.buffer.layout_runs().collect();
        let visible_glyph_bytes: usize = rows
            .iter()
            .map(|run| std::mem::size_of_val(run.glyphs))
            .sum();
        assert!(
            weight > std::mem::size_of::<ShapedText>() + layout.text.len() + visible_glyph_bytes
        );
        let prior_capacity = layout.line_offsets.capacity();
        layout.line_offsets.reserve(2048);
        assert_eq!(
            layout.cache_weight().unwrap() - weight,
            (layout.line_offsets.capacity() - prior_capacity) * std::mem::size_of::<usize>()
        );
        let longer = ShapedText::new(&mut fonts, "alpha beta gamma\n".repeat(100), 18., Some(45.));
        assert!(longer.cache_weight().unwrap() > weight * 10);
    }
}
