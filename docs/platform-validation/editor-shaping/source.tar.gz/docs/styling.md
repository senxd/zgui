# Styling retained views

zgui's Rust API combines GPUI/QuickGUI-style fluent methods with owned component children. Import `Styled` to use the methods on a `View` or reusable `Styles` patch. Values are logical pixels; spacing methods take pixel values directly, not a numbered spacing scale.

```rust
use zgui::compose::{button, column, text};
use zgui::style::{rgb, Styled, Styles};

let card = column()
    .w(320.)
    .p(16.)
    .gap(12.)
    .bg(rgb(0x202838))
    .rounded(10.)
    .border_1()
    .border_color(rgb(0x465268))
    .text_color(rgb(0xf0f4ff))
    .text_size(16.)
    .child(text("Connection settings").text_size(22.))
    .child(button()
        .px(14.).py(8.)
        .bg(rgb(0x2854a0))
        .hover(|s| s.bg(rgb(0x3266bd)))
        .active(|s| s.bg(rgb(0x1d407e)))
        .focus(|s| s.border_1().border_color(rgb(0x9abfff)))
        .disabled_style(|s| s.opacity(0.45))
        .child(text("Connect"))
        .on_click(|| println!("connect")));
```

Mount with `Ui::mount(card)` or use the native window's view rendering entry point. A background, rounded border, or shadow decorates the container itself; it does not add a layout child. Children remain retained when a visual style changes.

## Properties and patches

| Area | Methods |
| --- | --- |
| Dimensions | `w`, `h`, `size`, `min_w`, `max_w`, `min_h`, `max_h` |
| Padding | `p`, `px`, `py`, `pt`, `pr`, `pb`, `pl` |
| Margins | `m`, `mx`, `my`, `mt`, `mr`, `mb`, `ml` |
| Layout | `flex_row`, `flex_col`, `gap`, `flex_grow`, `flex_shrink`, `grow`, `shrink_0` |
| Alignment | `items_start`, `items_center`, `items_end`, `items_stretch`, `justify_start`, `justify_center`, `justify_end`, `justify_between`, `justify_around` |
| Surface | `bg`, `rounded`, `border`, `border_1`, `border_color`, `shadow`, `shadow_none` |
| Text | `text_color`, `text_size`, `line_height`, `line_height_normal`, `text_wrap`, `font_family`, `font_weight`, `font_bold`, `italic` |
| Effects | `opacity`, `blur`, `edge_fade`, `translate`, `isolated` |
| Clipping | `overflow_hidden`, `overflow_visible` |

`Styles::new()` is an empty patch. `.style(patch)` changes only fields supplied by that patch. Later writes win, including individual edges: `.p(8.).px(12.).pt(3.)` produces top 3, right 12, bottom 8, left 12. A later `.pl(20.)` preserves the other three edges. Per-edge padding participates in intrinsic sizing, flex allocation, and resizing.

```rust
use zgui::style::{rgb, Styled, Styles};
let surface = Styles::new().p(12.).bg(rgb(0x202838)).rounded(8.);
let compact = surface.clone().py(6.); // retains horizontal padding and surface
```

Use `.apply(...)` for reusable style functions, `.when(...)` for a conditional transformation, and `.when_some(...)` for an optional value. These helpers work on both views and sparse `Styles` patches; skipped closures are never called.

```rust
use zgui::compose::{column, text};
use zgui::style::{rgb, Styled, Styles};

fn card_surface<S: Styled>(style: S) -> S {
    style.p(16.).bg(rgb(0x202838)).rounded(10.)
}

let compact = true;
let width = Some(320.);
let card = column()
    .apply(card_surface)
    .when(compact, |view| view.py(8.))
    .when_some(width, |view, width| view.w(width))
    .child(text("Connection settings"));
let reusable_patch = Styles::new().apply(card_surface);
```

These decisions run once when constructing the description. They do not subscribe to signals or reapply after mounting. For styles that change with state, return a patch from `reactive_style`; the same helpers can be used inside that tracked callback.

Text color, size, wrapping, font selection and line height inherit through children and components. A child can override each field independently. Updating an inherited value updates the affected text properties; it does not rerun component construction. Explicit overrides shield descendants from unchanged effective typography. Other style properties are local rather than inherited. Padded or decorated text mounts a retained box around its text node; plain text stays a single node. Static and reactive wrapping propagate through boxed text and reflow its retained text node when the available width changes.

## Line height

`.line_height(24.)` sets the distance between visual text rows to 24 logical pixels.
It inherits through ordinary children, components and providers, including boxed
labels and editors. Font size still controls glyph size. `.line_height_normal()`
explicitly resets an inherited pixel value to normal spacing for the child's own
font size. Omitting the field from a `Styles` patch preserves inheritance; removing
a dynamic override restores the underlying base or inherited value.

```rust
use zgui::compose::prelude::*;
let content = column().text_size(16.).line_height(24.)
    .child(text("First line\nSecond line"))
    .child(text("Compact caption").text_size(12.).line_height_normal());
```

Positive finite values are used exactly, including values smaller than the font
size. Tight spacing can overlap adjacent glyph rows; glyph ink outside the text
node's allocated rectangle is clipped, consistent with other text rendering.
Zero, negative and non-finite values resolve to normal spacing. The normalized
metric supports stable equality and hashing, so repeated equivalent styles do
not invalidate layout or paint.

Reactive line-height changes update retained text geometry and editor caret,
selection, hit testing and IME placement together. They do not reconstruct the
component or modify its text model. Single-line inputs still use the selected
line height for their caret and metrics while remaining unwrapped.

## Interaction and reactive styles

Styles resolve in this order: base fluent properties, `reactive_style`, hover, active, focus, disabled. Later patches take precedence only for fields they specify. While disabled, hover, active, and focus patches are excluded. Removing a state or a dynamic property restores the underlying style; it does not leave stale values behind.

`.disabled(true)` and `.disabled_when(|| signal.get())` disable interaction and update accessibility. `.disabled_style(...)` controls appearance; supplying that patch alone does not disable a view. Focus is cleared when a focused subtree becomes disabled. Buttons support pointer and keyboard activation.

```rust
use zgui::{compose::column, style::{rgb, Styled, Styles}, widgets::Ui};
let mut ui = Ui::new(640., 480.);
let highlighted = ui.signal(false);
let read = highlighted.clone();
let view = column().p(12.).reactive_style(move || {
    Styles::new().bg(if read.get() { rgb(0x345888) } else { rgb(0x202838) })
});
let mounted = ui.mount(view);
highlighted.set(true);
```

Signal reads inside `reactive_style` are tracked. A background or text-color change damages paint without invalidating layout. Size, spacing, wrapping, or font-size changes invalidate dependent layout. Translations and opacity use compositor invalidation. Equal resolved properties produce no new scene mutation. The mounted children and component-local state are preserved in each case.

## Transparency and effects

`rgb(0xRRGGBB)` creates an opaque color; `rgba(0xRRGGBBAA)` includes alpha. `.opacity(value)` multiplies opacity. Without isolation, opacity applies through individual subtree primitives: overlapping translucent children can accumulate alpha. Use `.isolated(true).opacity(0.5)` when the subtree should first render as a group and then composite once. GPU isolated layers retain their pixels across eligible transform/opacity-only updates, subject to cache limits.

`.blur(radius)` is backdrop blur, not a generic image or text blur. It samples content painted behind the view. Backdrop updates currently reconstruct the full target conservatively; blur is not a promise of damage-only work. The GPU blur implementation caps sigma at 64 physical pixels. `.edge_fade(length)` fades the top and bottom edges. `.overflow_hidden()` clips to the rectangular layout box; a rounded background does not imply rounded clipping of all descendants.

`.shadow(BoxShadow { ... })` adds an outer shadow without changing layout dimensions. Shadow extents participate in damage tracking. `.shadow_none()` explicitly clears an inherited patch's shadow setting (shadows do not inherit down the view tree).

The native GPU renderer shapes text and provides fallback fonts. Font family, weight and italic inherit through components and slots alongside color, size and wrapping. Use `.font_family("DejaVu Serif").font_weight(700).italic(true)`, or the portable `FontFamily::{SansSerif, Serif, Monospace}` choices. Weight is clamped to 1–1000; named families and unavailable faces use platform fallback. Native measurement, caret shaping and GPU glyph selection share font attributes; changing them invalidates layout and retained glyph geometry. The software reference backend also renders styled fonts, using a lazy platform font database. Letter spacing remains unimplemented; custom line height uses the shared inherited metrics described above. It does not yet expose the full CSS layout or styling surface of the inspiration projects. GPU cache and effect limits are documented in [the renderer notes](../crates/zgui-gpu/README.md).

The software styled-font cache retains at most 128 entries and 8 MiB of text keys/glyph images; oversized runs render without being retained. Its platform font database is created on first styled text and shared with software layer renderers. Headless core-only scenes use approximate metrics until a `Scene::set_font_text_shaper` backend is installed.

Editable views use the same fluent styles. For example, `text_input("Search", query).w(320.).px(12.).font_family(FontFamily::Monospace).focus(|s| s.border(2.).border_color(rgb(0x5ea5ff)))` styles the actual focusable editor root. Its text and caret inherit color, size, family, weight, and italic; root padding and allocated dimensions determine the clipped editing viewport. Typography and dimension changes preserve selection and the bound model. Use `.text_wrap(true)` on `text_area` to wrap at its allocated content width, including inherited or reactive wrapping styles. Rendering, pointer hit testing, selection, caret movement and IME geometry share the same wrapped layout. Resizing reflows visual lines without adding newlines to the model or losing selection. Wrapping defaults to false, preserving horizontal scrolling for long lines; `text_input` always remains a single unwrapped line. Home/End follow visual lines while wrapping; repeated Up/Down retain the preferred horizontal caret position across shorter lines. Edits, pointer placement, Home/End, and changes to wrapping, font metrics or allocated width reset that preferred position.

Multiline editors accept wheel scrolling without moving the selection; scrolling clamps to the text extent and bubbles to ancestors at an exhausted edge. Single-line editors leave vertical wheel events to their parent. Font/color changes preserve component ownership; color-only changes repaint without relayout, while font changes also update selection, hit testing and caret metrics.

`.absolute()` removes a child from normal layout flow. It starts at its parent's
content origin (inside padding), with `.ml(...)` and `.mt(...)` setting offsets.
It does not consume flex space, add a gap, or enlarge the parent's intrinsic size.
Its wrapping constraints follow the parent's allocated content dimensions.
`.relative()` restores ordinary row, column, or overlay participation, including
when applied by a reactive style patch. Absolute positioning is relative to the
immediate parent; it does not implicitly create a window-level portal or change
paint order. Use `.translate(...)` for a compositor-only positional change when
layout participation should stay the same.


Focused editors reuse bounded shaped geometry for unchanged displayed text and
metrics. Selection, scrolling and navigation do not reshape that text; font,
line-height and wrapped-width changes invalidate the reuse entry. See
[editor layout reuse](performance/editor-shaping/README.md) for admission limits
and measured call counts. This does not change component ownership or the style
inheritance rules above.
