#!/bin/bash
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update > /evidence/apt-update.log 2>&1
apt-get install -y --no-install-recommends python3 xvfb x11-utils openbox sway dbus-x11 > /evidence/apt-install.log 2>&1
useradd --create-home probe
chmod a+rwx /evidence
dpkg-query -W > /evidence/packages.tsv
uname -a > /evidence/uname.txt
exec runuser -u probe -- python3 /evidence/probe.py
