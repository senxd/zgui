import os,pathlib,sys,subprocess,tempfile,time,json,select
sys.path.insert(0,"/repo/scripts")
from sway_host import wait_for_openbox, wait_for_sway_host
out=pathlib.Path('/evidence'); results=[]
for trial in range(5):
    dst=out/f'trial-{trial+1}';dst.mkdir(exist_ok=True)
    children=[]
    with tempfile.TemporaryDirectory(prefix='zgui-sway-') as private:
        env=dict(os.environ,XDG_RUNTIME_DIR=private,XDG_CONFIG_HOME=private+'/config',XDG_DATA_HOME=private+'/data',XDG_CACHE_HOME=private+'/cache')
        for key in ('DISPLAY','WAYLAND_DISPLAY','SWAYSOCK','DBUS_SESSION_BUS_ADDRESS','AT_SPI_BUS_ADDRESS'):env.pop(key,None)
        def launch(name,cmd,**kw):
            log=(dst/(name+'.log')).open('w')
            proc=subprocess.Popen(cmd,env=env,stderr=log,stdout=kw.pop('stdout',log),**kw)
            log.close();children.append(proc);return proc
        start=time.monotonic()
        try:
            xvfb=launch('xvfb',['Xvfb','-displayfd','1','-screen','0','1400x1000x24','-ac'],stdout=subprocess.PIPE,text=True)
            assert select.select([xvfb.stdout],[],[],10)[0]
            env['DISPLAY']=':'+xvfb.stdout.readline().strip()
            wm=launch('openbox',['openbox']);wait_for_openbox(env,dst,wm)
            wm_ready=time.monotonic()-start
            env.update(WLR_BACKENDS='x11',WLR_X11_OUTPUTS='1',WLR_RENDERER='pixman')
            config=pathlib.Path(private,'sway.conf');config.write_text('xwayland disable\nseat seat0 fallback true\noutput * mode 1200x800\ndefault_border none\n')
            sway=launch('sway',['sway','--unsupported-gpu','--config',str(config)])
            host=wait_for_sway_host(env,dst,sway)
            sockets=list(pathlib.Path(private).glob('sway-ipc*.sock'))
            assert sockets
            env['SWAYSOCK']=str(sockets[0])
            outputs=subprocess.run(['swaymsg','-t','get_outputs','-r'],env=env,text=True,capture_output=True,timeout=5)
            (dst/'outputs.json').write_text(outputs.stdout)
            assert outputs.returncode==0,outputs.stderr
            assert any(x['name']=='X11-1' and x['active'] for x in json.loads(outputs.stdout))
            result=dict(trial=trial+1,result='pass',openbox_ready_seconds=wm_ready,host_ready_seconds=time.monotonic()-start,host=host)
        except Exception as e:
            result=dict(trial=trial+1,result='fail',error=repr(e))
        finally:
            for child in reversed(children):
                if child.poll() is None:
                    child.terminate()
                    try:child.wait(timeout=3)
                    except subprocess.TimeoutExpired:child.kill();child.wait()
        results.append(result);print(json.dumps(result),flush=True)
        (out/'results.json').write_text(json.dumps(dict(scope='Linux ARM64 compositor readiness only; no Rust applications',trials=results),indent=2)+'\n')
if not all(r['result']=='pass' for r in results):sys.exit(1)
