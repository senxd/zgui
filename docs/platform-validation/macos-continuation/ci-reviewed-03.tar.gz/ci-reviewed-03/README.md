# CI follow-up: 3a0ce13

Run 35808887834 finished with both core platforms and macOS GPU successful. Linux Vulkan and all example linking passed; native input/window lifecycle and rich/actions/layout/drag passed. The nested Wayland menu setup then failed at a single immediate host-window regex lookup after socket creation (`None.group`). Full raw log retained.

The retained Sway log contains X11 BadAtom op18/value0. This alone does not establish a fatal compositor bug or identify the missing property. The original probe did not preserve its X11 tree. Follow-up readiness code therefore waits for actual Openbox EWMH identity/UTF8 name before starting Sway, then waits for the actual nested X11 host window. It preserves query/tree logs and fails on process exit or deadline; actual Ubuntu validation is required.

Local mocked helper checks exercised delayed host appearance, bounded timeout with last-tree preservation, early compositor exit, delayed Openbox EWMH readiness, absent WM deadline, and xprop launch/timeout error preservation. These are helper failure-path checks, not native Linux evidence.
