# Readiness-corrected CI

Run 35810106069 (a89d8d0) passed both core jobs and macOS GPU. Linux passed Vulkan, examples, native input/window lifecycle, rich/actions/layout/drag, native menus/dialogs/external file drops, variable-height virtual rows, and measured rows. The next Wayland input probe failed its initial protocol regex despite recorded xdg_toplevel@23.configure(900, 650) and wl_surface@21.attach(wl_buffer@97). It accepted only the Rust debug # ID delimiter; libwayland used @. Follow-up regex permits both delimiters while preserving all protocol-event, dimension and model assertions. Actual downstream Wayland input actions and remaining Linux steps still require rerun.

The Sway/Openbox readiness correction passed the actual Linux native menu/drop paths. Artifact quota still prevents downloadable artifacts; raw textual logs remain retained here.
