# Final UI evidence packet

Logs, chronological observations, test data and executable identity metadata are preserved. All `.app` directory trees and executable binaries are excluded from the archive. Copied applications are test fixtures, not deliverable artifacts.

Identity manifests are capture-time observations, not retroactive proof of earlier launch bytes. `bundle-identities-final-capture.json` explicitly identifies the native_platform wrapper as the discarded synchronous drag experiment; its patch is retained in the separate metal-fixes-final packet. No custom-titlebar drag pass or confirmed framework defect is claimed.

The native app-focus observer recorded active=true/key=true throughout the attempted Finder workflow. It did not establish deactivation; earlier same-editor accented input is therefore inconclusive, not a confirmed product failure. Logical editor-transfer reset remains observed.
