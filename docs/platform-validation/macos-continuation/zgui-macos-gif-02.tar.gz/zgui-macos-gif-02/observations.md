# Native decoded GIF validation

Actual `animated_image three-frames.gif` on Apple M5 Max/macOS 26.4. Current source was built with Cargo immediately before copying the executable into the test wrapper. Source identity/archive and executable SHA are retained. The first replacement-inode launch exited 137 without output; a fresh executable inode launched normally with identical bytes. No root cause inferred.

CUA clicked Pause/resume in the actual AX tree. Native screenshots show the decoded green frame paused and the same preview pixels after 16.347 seconds (more than the full 3.9-second GIF cycle). Clicking again resumed playback; red and blue frames were then observed and saved. AX close did not terminate the process. Subsequent coordinate close reported procNotFound, suggesting a stale automation connection. Therefore these observations are not qualified as current-binary UI proof; repeat with a distinct wrapper path. The exact task process was terminated after this failure.

The GIF is three opaque full-canvas 120×80 frames at nominal 1300 ms, infinite repeat and Background disposal. This verifies real file decode, retained native presentation and pause/resume integration. It does not measure presentation cadence or prove partial-frame disposal, loop-limit behavior, invisibility submission pause or resource cancellation; their separate decoder/lifecycle tests remain distinct evidence. Screenshot colors are color-managed captures, not source-byte equality assertions.

The earlier `zgui-macos-gif-01` packet retains the same experiment with the pre-existing wrapper binary. Its checksum matches the earlier UI capture identity, but its checkout_head records capture time, not a claim it was built from that HEAD. Packet02 is the final-source repeat.

Follow-up: first current-build process subsequently exited normally, status 0; targeted TERM reported No such process (nothing terminated). For additional certainty a distinct `gif_current.app` wrapper with the same executable bytes was launched and freshly bound in CUA. Its native menu identified GIF current validation. Blue preview stayed byte-identical in the saved image crop for 46.082 seconds, then resumed red and green. Distinct-wrapper screenshots are the decisive current-source UI evidence. No new build or production change between wrappers.

Distinct-wrapper close completed with process exit status 0.
