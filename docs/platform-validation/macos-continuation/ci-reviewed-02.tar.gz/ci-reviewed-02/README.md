# Reviewed CI follow-up

Run 35808416547 tests commit 05c0ceaab5885995f0b1dda30bd5861fdafd3f22. macOS GPU job passed its automated bundle and independent component lifecycle check. Artifact quota remains exhausted; warning-only upload does not mean downloadable evidence is preserved. Core macOS tests and doctests passed; Rust 1.98 strict clippy then exposed chunks_exact_to_as_chunks in the renderer after the earlier MSRV lint was resolved. Logs preserve the new failure.

The follow-up change uses stable as_chunks::<4>().0 and as_chunks_mut::<4>().0 for complete RGBA groups, preserving omission of incomplete tails. Tests now explicitly dereference array references for identical pixel comparisons. Full local native Metal tests and strict workspace clippy passed (chunks-*-after.log). Initial local compile errors due to changed reference types are also preserved.

Run 35807926924 Linux job passed Vulkan, all desktop example linking, and native input/window lifecycle; it then failed because xmodmap was absent. Adding x11-xserver-utils supplies that required executable. This resolves an identified missing dependency; a subsequent full Linux run is still required. Its full raw log is in ../ci-reviewed/.
