# Physical display transition

Actual native macOS example on two attached 5120×2880 displays, both scale2.0. Native WindowInfo refresh reads winit current_monitor, outer_position and inner_size; checks are not requested placement state. The window began on display0 at(2080,590), moved to display1 at(-4920,200), then returned to display0 at the exact original bounds, keeping960×640physical client size. Each successful snapshot matched for ten100ms observation cycles. Process exited0. Strict example Clippy passed.

This closes the same-scale physical display movement/return gate. Both displays have the same reported name but distinct indices and positions. No mixed-scale transition, display hotplug, sleep/wake, driver loss, pointer dragging, pixel restoration or native cursor appearance is inferred. System display settings were untouched. Sourceexample and identities retained; native.log is runtime evidence.
