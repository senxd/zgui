# Linux XIM lifecycle diagnosis and supported asynchronous mode

Production baseline: cca2ead80d4dd4839d8ace9553263a4bb634ec5d, unchanged native_ime and external_ime release executables, exact hashes retained. Official Ubuntu 24.04 ARM64 task container, native Xvfb/Openbox/XIM and software Vulkan. Package inventory: IBus 1.5.29-2 (ibus version reports 1.5.29-rc2), libpinyin 1.15.7-1build2, libX11 1.8.7-1build1. This is separate from the matched benchmark; no sampling ran during these probes.

## Chronology

- Initial setup attempt failed before launch because gsettings was missing; installing libglib2.0-bin in the task container resolved that dependency. All install logs remain.
- baseline01: original default synchronous IBus session reproduces CI Stage 3: model/display retain 你好 when the native candidate window is present for 中. The original eight-stage assertion fails.
- raw01: private copied zgui source logs WindowEvent::Ime before host filtering. After the first commit, no subsequent raw preedit arrives until editor transfer; host focus/target/barrier remain valid. The same stage fails.
- winit-trace01: private copied winit 0.30.13 logs its incoming XIM events. After commit, its composing flag is false; Update 中/我 arrives without another Start or End and is filtered before the host callback. This identifies the delivery boundary, not a safe production remedy.
- candidate01: privately removing commit-time composing reset restores Stage 3, but Stage 4 Escape fails with stale 中. The candidate is rejected.
- xim-draw-trace01: additional private callback tracing observes no draw/End/empty Update at Escape. Observed draws all have non-null text/string; a null-deletion fix is not supported by this trace. No private patch is delivered in production or the Cargo registry.
- baseline-async01: original unpatched executable with task-process IBUS_ENABLE_SYNC_MODE=0 passes the unchanged eight stages: Unicode composition/commit, Escape, editor transfer, independent models and candidate placement, exactly two commits.
- external-async01 and readonly-async01: original external_ime passes model replacement/read-only cancellation, no stale Return commit, Backspace/digit recovery without engine switch, and fresh Unicode composition.
- ordinary-async01: original native_ime commits 你好, switches the task-owned engine off, replaces with Control-A plus aB7, then Backspace and 9 produce exact aB9; only the initial Unicode IME commit occurs.

## Attribution and limits

Official IBus fix [719792d300579c1bfdf43251a83c6ed4e5594c07](https://github.com/ibus/ibus/commit/719792d300579c1bfdf43251a83c6ed4e5594c07) adds missing show/hide preedit signals to PostProcessKeyEvent handling. Its retained commit metadata and patch support the observed synchronous lifecycle omission. The source [XIM bridge](https://github.com/ibus/ibus/blob/1.5.29/client/x11/main.c) selects asynchronous mode with IBUS_ENABLE_SYNC_MODE=0. The working asynchronous session is a supported configuration, not a fix or pass for the affected default synchronous bridge.

Delivered script 4e95c8e selects asynchronous mode only for owned test processes, retains every original assertion and records IBus version/mode/limitation. The actual successful baseline runs selected the same mode via process environment before that metadata-only script change. baseline-source.tar.gz identifies the unpatched source. diagnostic-sources and separate patches identify abandoned instrumented experiments; hashes identify each built executable, but binaries are excluded.

All owned IBus/Xvfb/Openbox/D-Bus/application processes were stopped before releasing the container for later benchmark work. No user input source or macOS setting changed. This evidence does not close macOS Pinyin or general IBus default-mode compatibility.
