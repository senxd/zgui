//! Retained menu keyboard navigation and trigger metadata.
use crate::{
    input::{EventPhase, InputEvent, Key},
    reactive::Signal,
    scene::NodeId,
    semantics::{PopupKind, Role},
    widgets::Ui,
};
use std::{
    cell::RefCell,
    rc::Rc,
    time::{Duration, Instant},
};
pub(crate) struct MenuContext {
    pub open: Signal<bool>,
    pub parent: Option<Rc<MenuContext>>,
}
impl MenuContext {
    pub(crate) fn close_chain(&self) {
        self.open.set(false);
        if let Some(parent) = &self.parent {
            parent.close_chain();
        }
    }
}
#[derive(Default)]
struct Search {
    prefix: String,
    last: Option<Instant>,
}
pub(crate) fn mount(
    ui: &mut Ui,
    panel: NodeId,
    menu: Rc<MenuContext>,
    anchor: NodeId,
    overlay: NodeId,
) {
    let search = Rc::new(RefCell::new(Search::default()));
    let reset = search.clone();
    let open = menu.open.clone();
    let semantics = ui.semantics.clone();
    ui.bind(panel, move || {
        let expanded = open.get();
        *reset.borrow_mut() = Search::default();
        semantics.borrow_mut().update(anchor, |node| {
            node.has_popup = Some(PopupKind::Menu);
            node.expanded = Some(expanded);
        });
    });
    let weak = ui.downgrade();
    ui.on_event(overlay, false, move |cx| {
        if cx.phase == EventPhase::Capture {
            return;
        }
        let InputEvent::KeyDown { key, modifiers, .. } = &cx.event else {
            return;
        };
        if *key == Key::Tab {
            menu.close_chain();
            cx.stop_propagation();
            return;
        }
        let Some(ui) = weak.upgrade() else {
            return;
        };
        if cx.target != panel
            && cx.target != overlay
            && !ui
                .semantics
                .borrow()
                .get(cx.target)
                .is_some_and(|node| node.role == Role::MenuItem)
        {
            return;
        }
        let items = {
            let scene = ui.scene.borrow();
            let semantics = ui.semantics.borrow();
            let mut pending = scene
                .children(panel)
                .iter()
                .rev()
                .copied()
                .collect::<Vec<_>>();
            let mut items = Vec::new();
            while let Some(node) = pending.pop() {
                if semantics
                    .get(node)
                    .is_some_and(|node| node.role == Role::MenuItem)
                    && ui.input.is_enabled(&scene, node)
                {
                    items.push(node);
                }
                pending.extend(scene.children(node).iter().rev().copied());
            }
            items
        };
        if items.is_empty() {
            return;
        }
        let current = items
            .iter()
            .position(|node| Some(*node) == ui.input.focused());
        let target = match key {
            Key::ArrowDown => Some(items[current.map_or(0, |index| (index + 1) % items.len())]),
            Key::ArrowUp => Some(
                items[current.map_or(items.len() - 1, |index| {
                    (index + items.len() - 1) % items.len()
                })],
            ),
            Key::Home => Some(items[0]),
            Key::End => items.last().copied(),
            Key::Character(text) if !modifiers.control && !modifiers.alt && !modifiers.meta => {
                let Some(text) = bounded_prefix(text) else {
                    return;
                };
                let mut search = search.borrow_mut();
                let now = Instant::now();
                if search
                    .last
                    .is_none_or(|last| now.duration_since(last) > Duration::from_millis(750))
                {
                    search.prefix.clear();
                }
                search.last = Some(now);
                if search.prefix.len() + text.len() > 256 {
                    search.prefix.clear();
                }
                // Repeating the same prefix cycles matching items, including
                // labels such as "Aaron" that also match a doubled letter.
                if search.prefix != text {
                    search.prefix.push_str(&text);
                }
                let find = |prefix: &str| {
                    (1..=items.len())
                        .map(|step| {
                            items[current.map_or(step - 1, |index| (index + step) % items.len())]
                        })
                        .find(|node| {
                            ui.semantics
                                .borrow()
                                .get(*node)
                                .is_some_and(|node| matches_prefix(&node.label, prefix))
                        })
                };
                let target = find(&search.prefix);
                if target.is_none() {
                    search.prefix = text;
                    find(&search.prefix)
                } else {
                    target
                }
            }
            _ => return,
        };
        if let Some(target) = target {
            ui.input.focus(&ui.scene, Some(target));
        }
        cx.prevent_default();
        cx.stop_propagation();
    });
}

fn bounded_prefix(text: &str) -> Option<String> {
    let mut result = String::new();
    for character in text.chars().flat_map(char::to_lowercase) {
        if character.is_control() {
            return None;
        }
        if result.len() + character.len_utf8() > 256 {
            break;
        }
        result.push(character);
    }
    (!result.is_empty()).then_some(result)
}
fn matches_prefix(label: &str, prefix: &str) -> bool {
    let mut label = label.chars().flat_map(char::to_lowercase);
    prefix
        .chars()
        .all(|character| label.next() == Some(character))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn typeahead_storage_is_bounded_with_unicode_case_expansion() {
        let prefix = bounded_prefix(&"İ".repeat(10000)).unwrap();
        assert!(prefix.len() <= 256);
        assert!(prefix.starts_with("i\u{307}"));
        assert!(matches_prefix(&"İ".repeat(10000), &prefix));
        assert!(bounded_prefix("\n").is_none());
    }
}
