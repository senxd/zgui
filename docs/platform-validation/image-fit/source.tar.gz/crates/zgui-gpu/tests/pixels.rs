use zgui::scene::*;
use zgui_gpu::GpuRenderer;
// These tests create independent devices on the same adapter. Keep their resource
// lifetimes separate rather than multiplying driver threads/caches by the test
// runner's CPU count. Tests that exercise shared devices still create multiple
// renderers within one fixture.
fn gpu_fixture() -> std::sync::MutexGuard<'static, ()> {
    static DEVICE_TEST: std::sync::Mutex<()> = std::sync::Mutex::new(());
    DEVICE_TEST
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}
fn fixed(w: f32, h: f32) -> Style {
    Style {
        width: Some(w),
        height: Some(h),
        ..Default::default()
    }
}
#[test]
fn retained_damage_alpha_text_and_scale() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(128, 64).expect("a Vulkan/Metal adapter is required");
    let mut s = Scene::new(128., 64.);
    s.set_kind(s.root(), NodeKind::Container(Layout::Overlay));
    let bg = s.append(
        s.root(),
        NodeKind::Rect(Color(20, 40, 60, 255)),
        fixed(128., 64.),
    );
    let front = s.append(
        s.root(),
        NodeKind::Rect(Color(200, 0, 0, 128)),
        fixed(20., 20.),
    );
    let damage = s.flush().damage;
    let stats = gpu.render(&s, &damage).unwrap();
    assert!(stats.draw_calls > 0);
    let pixels = gpu.readback().unwrap();
    assert_eq!(
        gpu.present_with_status().unwrap(),
        zgui_gpu::PresentationStatus::Offscreen
    );
    gpu.present().unwrap();
    assert_eq!(pixels, gpu.readback().unwrap());
    assert_eq!(
        &pixels[(30 * 128 + 30) * 4..(30 * 128 + 30) * 4 + 4],
        &[20, 40, 60, 255]
    );
    assert!((pixels[0] as i32 - 110).abs() <= 1);
    assert_eq!(gpu.render(&s, &[]).unwrap().draw_calls, 0);
    s.set_transform(front, Transform { x: 30., y: 0. });
    {
        let d = s.flush().damage;
        gpu.render(&s, &d).unwrap()
    };
    let partial = gpu.readback().unwrap();
    gpu.render(&s, &[Rect::new(0., 0., 128., 64.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    assert_eq!(&partial[..4], &[20, 40, 60, 255]);
    let text = s.append(
        s.root(),
        NodeKind::Text {
            text: "Hello العربية".into(),
            color: Color(255, 255, 255, 255),
            font_size: 16.,
        },
        fixed(128., 32.),
    );
    s.set_transform(text, Transform { x: 0., y: 25. });
    let d = s.flush().damage;
    let stats = gpu.render(&s, &d).unwrap();
    assert_eq!(stats.shaped_nodes, 1);
    assert!(stats.glyph_uploads > 0);
    let pixels = gpu.readback().unwrap();
    assert!(pixels.chunks_exact(4).any(|p| p[0] > 200 && p[1] > 200));
    assert_eq!(gpu.render(&s, &d).unwrap().shaped_nodes, 0);
    s.set_effects(
        front,
        Effects {
            edge_fade: 10.,
            ..Default::default()
        },
    );
    let d = s.flush().damage;
    gpu.render(&s, &d).unwrap();
    let partial = gpu.readback().unwrap();
    gpu.render(&s, &[Rect::new(0., 0., 128., 64.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    s.remove(text);
    s.remove(front);
    s.set_kind(bg, NodeKind::Rect(Color(1, 2, 3, 255)));
    s.resize(64., 32.);
    s.set_style(bg, fixed(64., 32.));
    gpu.set_scale_factor(2.);
    {
        let d = s.flush().damage;
        gpu.render(&s, &d).unwrap()
    };
    assert_eq!(&gpu.readback().unwrap()[..4], &[1, 2, 3, 255]);
}

#[test]
fn backdrop_blur_reconstructs_without_feedback() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(64, 32).unwrap();
    let mut s = Scene::new(64., 32.);
    s.set_kind(s.root(), NodeKind::Container(Layout::Overlay));
    s.append(
        s.root(),
        NodeKind::Rect(Color(0, 0, 0, 255)),
        fixed(64., 32.),
    );
    let white = s.append(
        s.root(),
        NodeKind::Rect(Color(255, 255, 255, 255)),
        fixed(32., 32.),
    );
    let glass = s.append(
        s.root(),
        NodeKind::Rect(Color(255, 0, 0, 40)),
        fixed(64., 32.),
    );
    s.set_effects(
        glass,
        Effects {
            blur_radius: 4.,
            ..Default::default()
        },
    );
    let d = s.flush().damage;
    gpu.render(&s, &d).unwrap();
    let first = gpu.readback().unwrap();
    let index = (16 * 64 + 32) * 4;
    assert!(
        first[index + 1] > 20 && first[index + 1] < 200,
        "blur crosses the white/black boundary"
    );
    gpu.render(&s, &d).unwrap();
    assert_eq!(first, gpu.readback().unwrap(), "no repeated-blur feedback");
    s.set_kind(white, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = s.flush().damage;
    gpu.render(&s, &d).unwrap();
    let partial = gpu.readback().unwrap();
    gpu.render(&s, &[Rect::new(0., 0., 64., 32.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
}

#[test]
fn rounded_border_shadow_images_and_background_damage() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(80, 60).unwrap();
    gpu.set_background(Color(0, 0, 0, 0));
    let mut scene = Scene::new(80., 60.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let id = scene.append(
        scene.root(),
        NodeKind::Quad(QuadStyle {
            fill: Color(255, 0, 0, 255),
            radius: 8.,
            border_color: Color(0, 255, 0, 255),
            border_width: 3.,
            shadow: Some(BoxShadow {
                color: Color(0, 0, 255, 128),
                offset: Transform { x: -6., y: 2. },
                blur_radius: 3.,
                spread: 1.,
            }),
        }),
        fixed(24., 24.),
    );
    scene.set_transform(id, Transform { x: 20., y: 10. });
    let d = scene.flush().damage;
    assert!(d.iter().any(|r| r.x <= 4.));
    gpu.render(&scene, &d).unwrap();
    let pixels = gpu.readback().unwrap();
    let pixel = |x: usize, y: usize| &pixels[(y * 80 + x) * 4..(y * 80 + x) * 4 + 4];
    assert_eq!(pixel(32, 22), &[255, 0, 0, 255]);
    assert!(pixel(32, 10)[1] > 200);
    assert!(pixel(20, 10)[0] < 20);
    assert!(pixel(13, 22)[2] > 0);
    scene.set_transform(id, Transform { x: 40., y: 20. });
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let partial = gpu.readback().unwrap();
    gpu.render(&scene, &[Rect::new(0., 0., 80., 60.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    let image = std::sync::Arc::new(
        zgui::image::ImageData::new(
            2,
            2,
            vec![
                255, 255, 0, 255, 255, 255, 0, 255, 255, 255, 0, 255, 255, 255, 0, 255,
            ],
        )
        .unwrap(),
    );
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        Style {
            clip: true,
            ..fixed(6., 6.)
        },
    );
    scene.append(group, NodeKind::Image(image), fixed(16., 16.));
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let pixels = gpu.readback().unwrap();
    assert_eq!(&pixels[..4], &[255, 255, 0, 255]);
    assert_eq!(&pixels[7 * 4..8 * 4], &[0, 0, 0, 0]);
    scene.remove(group);
    scene.remove(id);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert!(gpu.readback().unwrap().iter().all(|b| *b == 0));
    gpu.set_background(Color(10, 20, 30, 128));
    gpu.render(&scene, &[]).unwrap();
    let p = gpu.readback().unwrap();
    assert_eq!(&p[..4], &[5, 10, 15, 128]);
}

#[test]
fn image_and_svg_decoding_are_bounded_and_alpha_correct() {
    let _gpu_fixture = gpu_fixture();
    let svg=br#"<svg xmlns="http://www.w3.org/2000/svg" width="2" height="2"><rect width="2" height="2" fill="red" fill-opacity="0.5"/></svg>"#;
    let image = zgui_gpu::assets::decode_svg(svg, 2, 2).unwrap();
    assert_eq!(&image.pixels()[..4], &[255, 0, 0, 128]);
    assert!(zgui_gpu::assets::decode_svg(svg, 0, 2).is_err());
    assert!(zgui_gpu::assets::decode_image(b"invalid").is_err());
    let mut png = std::io::Cursor::new(Vec::new());
    image::DynamicImage::ImageRgba8(image::RgbaImage::from_pixel(
        2,
        2,
        image::Rgba([12, 34, 56, 128]),
    ))
    .write_to(&mut png, image::ImageFormat::Png)
    .unwrap();
    let decoded = zgui_gpu::assets::decode_image(png.get_ref()).unwrap();
    assert_eq!(&decoded.pixels()[..4], &[12, 34, 56, 128]);
}

#[test]
fn text_metrics_match_editor_line_pitch() {
    let _gpu_fixture = gpu_fixture();
    let mut fonts = cosmic_text::FontSystem::new();
    assert_eq!(zgui_gpu::measure_text(&mut fonts, "", 14., None).1, 20.);
    assert_eq!(zgui_gpu::measure_text(&mut fonts, "a\nb", 14., None).1, 40.);
}

#[test]
fn thousand_streaming_frames_keep_caches_bounded_and_reuse_vertices() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(160, 80).unwrap();
    let mut scene = Scene::new(160., 80.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let stable = scene.append(
        scene.root(),
        NodeKind::Text {
            text: "Retained العربية".into(),
            font_size: 14.,
            color: Color(255, 255, 255, 255),
        },
        fixed(160., 24.),
    );
    let mut changing = scene.append(
        scene.root(),
        NodeKind::Text {
            text: "frame 0".into(),
            font_size: 14.,
            color: Color(255, 0, 0, 255),
        },
        fixed(160., 24.),
    );
    scene.set_transform(changing, Transform { x: 0., y: 30. });
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let initial = gpu.debug_cache_stats().vertex_buffer_bytes;
    scene.set_transform(stable, Transform { x: 1., y: 0. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.geometry_rebuilds, 0);
    assert_eq!(stats.glyph_uploads, 0);
    assert_eq!(stats.vertex_buffer_allocations, 0);
    for frame in 0..1000 {
        if frame % 20 == 0 {
            scene.remove(changing);
            changing = scene.append(
                scene.root(),
                NodeKind::Text {
                    text: "reused".into(),
                    font_size: 14.,
                    color: Color(255, 0, 0, 255),
                },
                fixed(160., 24.),
            );
            scene.set_transform(changing, Transform { x: 0., y: 30. });
        }
        scene.set_kind(
            changing,
            NodeKind::Text {
                text: format!(
                    "frame {frame} {}",
                    char::from_u32(0x400 + (frame % 80)).unwrap()
                )
                .into(),
                font_size: 12. + (frame % 20) as f32 * 0.25,
                color: Color(255, 0, 0, 255),
            },
        );
        let d = scene.flush().damage;
        gpu.render(&scene, &d).unwrap();
        let c = gpu.debug_cache_stats();
        assert!(c.shaped_nodes <= 2);
        assert!(c.shaped_bytes <= 8 * 1024 * 1024);
        assert_eq!(c.swash_images, 0);
        assert_eq!(c.swash_outlines, 0);
        assert!(c.vertex_buffer_bytes <= initial.max(8192));
        assert!(c.atlas_entries < 5000);
    }
    gpu.readback().unwrap();
    scene.remove(changing);
    scene.remove(stable);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().shaped_nodes, 0);
}

#[test]
fn shaped_hit_caret_and_disjoint_bidi_selection_use_visual_clusters() {
    let _gpu_fixture = gpu_fixture();
    use zgui_gpu::text::{Affinity, ShapedText, TextCursor};
    let mut fonts = cosmic_text::FontSystem::new();
    let rtl = ShapedText::new(&mut fonts, "אבג", 18., None);
    let begin = rtl
        .caret(TextCursor {
            byte_index: 0,
            affinity: Affinity::After,
        })
        .unwrap();
    let end = rtl
        .caret(TextCursor {
            byte_index: 6,
            affinity: Affinity::Before,
        })
        .unwrap();
    assert!(begin.x > end.x);
    assert_eq!(rtl.hit_test(end.x + 0.1, 10.).unwrap().byte_index, 6);
    assert_eq!(rtl.hit_test(begin.x - 0.1, 10.).unwrap().byte_index, 0);
    let mixed = ShapedText::new(&mut fonts, "abc אבג xyz", 18., None);
    let spans = mixed.selection(2..6);
    assert_eq!(spans.len(), 2);
    assert!(spans[0].x + spans[0].width < spans[1].x);
    let ligature = ShapedText::new(&mut fonts, "office", 18., None);
    let positions: Vec<_> = (1..5)
        .map(|byte_index| {
            ligature
                .caret(TextCursor {
                    byte_index,
                    affinity: Affinity::After,
                })
                .unwrap()
                .x
        })
        .collect();
    assert!(positions.windows(2).all(|w| w[0] < w[1]));
    let combining = ShapedText::new(&mut fonts, "e\u{301}x", 18., None);
    for x in 0..40 {
        let cursor = combining.hit_test(x as f32, 5.).unwrap();
        assert!([0, 3, 4].contains(&cursor.byte_index));
    }
    let lines = ShapedText::new(&mut fonts, "a\r\nb", 14., None);
    assert_eq!(lines.hit_test(0., 25.).unwrap().byte_index, 3);
    assert_eq!(
        lines
            .caret(TextCursor {
                byte_index: 3,
                affinity: Affinity::After
            })
            .unwrap()
            .y,
        20.
    );
}

#[test]
fn scene_installs_native_text_geometry() {
    let _gpu_fixture = gpu_fixture();
    let fonts = std::rc::Rc::new(std::cell::RefCell::new(cosmic_text::FontSystem::new()));
    let mut scene = Scene::new(100., 100.);
    scene.set_text_shaper(
        move |text: &str,
              size: f32,
              width: Option<f32>|
              -> Box<dyn zgui::text_layout::TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::new(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
            ))
        },
    );
    let layout = scene.shape_text("אבג", 14., None);
    assert!(layout.caret(0).x > layout.caret(6).x);
    assert_eq!(scene.measure_text("a\nb", 14., None).1, 40.);
}

#[test]
fn image_cache_reclaims_removed_nodes_and_rejects_oversized_allocations() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(8, 8).unwrap();
    let mut scene = Scene::new(8., 8.);
    let image = std::sync::Arc::new(zgui::image::ImageData::new(2, 2, vec![255; 16]).unwrap());
    let node = scene.append(scene.root(), NodeKind::Image(image.clone()), fixed(8., 8.));
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().image_textures, 1);
    assert_eq!(gpu.debug_cache_stats().image_bytes, 16);
    scene.remove(node);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().image_textures, 0);
    let huge = std::sync::Arc::new(
        zgui::image::ImageData::new(4096, 4097, vec![0; 4096 * 4097 * 4]).unwrap(),
    );
    scene.append(scene.root(), NodeKind::Image(huge), fixed(8., 8.));
    let d = scene.flush().damage;
    let error = gpu.render(&scene, &d).unwrap_err();
    assert!(error.0.contains("64 MiB"));
    assert_eq!(gpu.debug_cache_stats().image_bytes, 0);
}

#[test]
fn isolated_opacity_composites_once_and_retains_transformed_subtrees() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(80, 40).unwrap();
    let mut scene = Scene::new(80., 40.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(24., 24.),
    );
    scene.set_isolated(group, true);
    scene.set_effects(
        group,
        Effects {
            opacity: 0.5,
            ..Default::default()
        },
    );
    scene.append(
        group,
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(24., 24.),
    );
    let top = scene.append(
        group,
        NodeKind::Rect(Color(0, 0, 255, 255)),
        fixed(16., 24.),
    );
    scene.set_transform(top, Transform { x: 8., y: 0. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 1);
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(10 * 80 + 12) * 4..(10 * 80 + 12) * 4 + 4],
        &[0, 0, 128, 128]
    );
    assert_eq!(
        &p[(10 * 80 + 2) * 4..(10 * 80 + 2) * 4 + 4],
        &[128, 0, 0, 128]
    );
    scene.set_transform(group, Transform { x: 30., y: 5. });
    scene.set_effects(
        group,
        Effects {
            opacity: 0.25,
            ..Default::default()
        },
    );
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 0);
    assert_eq!(stats.layer_cache_hits, 1);
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(10 * 80 + 42) * 4..(10 * 80 + 42) * 4 + 4],
        &[0, 0, 64, 64]
    );
    assert_eq!(&p[..4], &[0, 0, 0, 0]);
    scene.set_kind(top, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 1);
    let partial = gpu.readback().unwrap();
    gpu.render(&scene, &[Rect::new(0., 0., 80., 40.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    scene.remove(group);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().layer_textures, 0);
    assert!(gpu.readback().unwrap().iter().all(|b| *b == 0));
}

#[test]
fn nested_layers_apply_opacity_at_each_boundary_and_invalidate_ancestors() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(64, 40).unwrap();
    let mut scene = Scene::new(64., 40.);
    let outer = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(30., 30.),
    );
    scene.set_isolated(outer, true);
    scene.set_effects(
        outer,
        Effects {
            opacity: 0.5,
            ..Default::default()
        },
    );
    let inner = scene.append(outer, NodeKind::Container(Layout::Overlay), fixed(20., 20.));
    scene.set_isolated(inner, true);
    scene.set_effects(
        inner,
        Effects {
            opacity: 0.5,
            ..Default::default()
        },
    );
    let red = scene.append(
        inner,
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(20., 20.),
    );
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 2);
    assert_eq!(&gpu.readback().unwrap()[..4], &[64, 0, 0, 64]);
    scene.set_transform(inner, Transform { x: 5., y: 5. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 1);
    assert_eq!(stats.layer_cache_hits, 1);
    scene.set_kind(red, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 2);
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(10 * 64 + 10) * 4..(10 * 64 + 10) * 4 + 4],
        &[0, 64, 0, 64]
    );
}

#[test]
fn isolated_overflow_and_fractional_translation_reuse_content() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(64, 40).unwrap();
    let mut scene = Scene::new(64., 40.);
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(10., 10.),
    );
    scene.set_isolated(group, true);
    let child = scene.append(
        group,
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(20., 12.),
    );
    scene.set_transform(child, Transform { x: -5., y: 0. });
    scene.set_transform(group, Transform { x: 15., y: 5. });
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(8 * 64 + 11) * 4..(8 * 64 + 11) * 4 + 4],
        &[255, 0, 0, 255]
    );
    scene.set_transform(group, Transform { x: 15.5, y: 5. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 0);
    let half = gpu.readback().unwrap();
    assert_ne!(p, half);
    scene.set_transform(group, Transform { x: 15.75, y: 5. });
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 0);
    assert_ne!(half, gpu.readback().unwrap());
    scene.set_isolated(group, false);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().layer_textures, 0);
}

#[test]
fn layer_texture_budget_fails_before_allocation_and_recovers_after_removal() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(8, 8).unwrap();
    let mut scene = Scene::new(8., 8.);
    let huge = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(4096., 4096.),
    );
    scene.set_isolated(huge, true);
    let d = scene.flush().damage;
    assert!(gpu.render(&scene, &d).unwrap_err().0.contains("64 MiB"));
    assert_eq!(gpu.debug_cache_stats().layer_bytes, 0);
    scene.remove(huge);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert!(gpu.readback().unwrap().iter().all(|p| *p == 0));
}

#[test]
fn blur_inside_isolated_layer_rebuilds_on_backdrop_mutation() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(48, 32).unwrap();
    let mut scene = Scene::new(48., 32.);
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(48., 32.),
    );
    scene.set_isolated(group, true);
    scene.append(group, NodeKind::Rect(Color(0, 0, 0, 255)), fixed(48., 32.));
    let behind = scene.append(
        group,
        NodeKind::Rect(Color(255, 255, 255, 255)),
        fixed(24., 32.),
    );
    let blur = scene.append(group, NodeKind::Rect(Color(255, 0, 0, 24)), fixed(48., 32.));
    scene.set_effects(
        blur,
        Effects {
            blur_radius: 3.,
            ..Default::default()
        },
    );
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let before = gpu.readback().unwrap();
    scene.set_kind(behind, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 1);
    assert_eq!(stats.layer_texture_allocations, 0);
    let after = gpu.readback().unwrap();
    assert!(before != after);
    gpu.render(&scene, &[Rect::new(0., 0., 48., 32.)]).unwrap();
    assert!(after == gpu.readback().unwrap());
}

#[test]
fn shared_device_and_fonts_outlive_individual_renderers_with_lazy_atlases() {
    let _gpu_fixture = gpu_fixture();
    use zgui_gpu::GpuContext;
    let context = GpuContext::new().unwrap();
    let fonts = std::rc::Rc::downgrade(&context.text_system());
    let mut first = GpuRenderer::new_with_context(32, 32, &context).unwrap();
    let mut second = GpuRenderer::new_with_context(32, 32, &context).unwrap();
    assert!(first.context().shares_device(&second.context()));
    assert!(std::rc::Rc::ptr_eq(
        &first.text_system(),
        &second.text_system()
    ));
    assert_eq!(first.debug_cache_stats().atlas_bytes, 4);
    assert_eq!(second.debug_cache_stats().atlas_bytes, 4);
    let mut scene = Scene::new(32., 32.);
    scene.append(
        scene.root(),
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(32., 32.),
    );
    let d = scene.flush().damage;
    first.render(&scene, &d).unwrap();
    assert_eq!(first.debug_cache_stats().atlas_bytes, 4);
    assert_eq!(&first.readback().unwrap()[..4], &[255, 0, 0, 255]);
    drop(first);
    drop(context);
    assert!(fonts.upgrade().is_some());
    scene.set_kind(
        scene.root(),
        NodeKind::Text {
            text: "A".into(),
            font_size: 14.,
            color: Color(255, 255, 255, 255),
        },
    );
    let d = scene.flush().damage;
    second.render(&scene, &d).unwrap();
    assert_eq!(second.debug_cache_stats().atlas_bytes, 512 * 512 * 4);
    second.readback().unwrap();
    drop(second);
    assert!(fonts.upgrade().is_none());
}

#[test]
fn glyph_atlas_grows_only_when_a_frame_needs_more_capacity() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(800, 800).unwrap();
    let mut scene = Scene::new(800., 800.);
    scene.append(
        scene.root(),
        NodeKind::Text {
            text: "W".into(),
            font_size: 700.,
            color: Color(255, 255, 255, 255),
        },
        fixed(800., 800.),
    );
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let cache = gpu.debug_cache_stats();
    assert!(cache.atlas_bytes >= 1024 * 1024 * 4);
    assert!(cache.atlas_bytes <= 2048 * 2048 * 4);
    assert!(gpu.readback().unwrap().iter().any(|p| *p > 0));
    let stats = gpu
        .render(&scene, &[Rect::new(0., 0., 800., 800.)])
        .unwrap();
    assert_eq!(stats.glyph_uploads, 0);
    assert_eq!(stats.geometry_rebuilds, 0);
}

#[test]
fn decorated_container_paints_background_before_children() {
    let _gpu_fixture = gpu_fixture();
    let mut gpu = GpuRenderer::new(64, 64).unwrap();
    let mut scene = Scene::new(64., 64.);
    let panel = scene.append(
        scene.root(),
        NodeKind::Panel {
            layout: Layout::Row,
            quad: QuadStyle {
                fill: Color(20, 40, 60, 255),
                radius: 4.,
                border_color: Color(200, 100, 0, 255),
                border_width: 2.,
                ..Default::default()
            },
        },
        Style {
            padding_edges: Some(Insets {
                left: 10.,
                top: 12.,
                right: 3.,
                bottom: 5.,
            }),
            ..fixed(40., 40.)
        },
    );
    scene.append(panel, NodeKind::Rect(Color(255, 0, 0, 255)), fixed(8., 8.));
    let damage = scene.flush().damage;
    gpu.render(&scene, &damage).unwrap();
    let pixels = gpu.readback().unwrap();
    let at = |x: usize, y: usize| &pixels[(y * 64 + x) * 4..(y * 64 + x) * 4 + 4];
    assert_eq!(at(6, 6), &[20, 40, 60, 255]);
    assert_eq!(at(12, 14), &[255, 0, 0, 255]);
    assert_eq!(at(20, 1), &[200, 100, 0, 255]);
}

#[test]
fn composed_fluent_styles_render_and_repaint_without_relayout() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::{column, text},
        style::{Styled, Styles, rgb},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(128, 64).unwrap();
    let mut ui = Ui::new(128., 64.);
    let color = ui.signal(rgb(0x204060));
    let read = color.clone();
    let view = ui.mount(
        column()
            .size(128., 64.)
            .p(8.)
            .text_color(rgb(0xffffff))
            .text_size(20.)
            .reactive_style(move || Styles::new().bg(read.get()))
            .child(text("Hello").id("label")),
    );
    let label = view.find("label").unwrap();
    let initial_bounds;
    {
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        initial_bounds = scene.bounds(label);
        gpu.render(&scene, &damage).unwrap();
    }
    let first = gpu.readback().unwrap();
    assert_eq!(
        &first[(60 * 128 + 120) * 4..(60 * 128 + 120) * 4 + 4],
        &[32, 64, 96, 255]
    );
    assert!(
        first
            .chunks_exact(4)
            .any(|p| p[0] > 220 && p[1] > 220 && p[2] > 220),
        "composed text must render over the panel"
    );
    color.set(rgb(0x603020));
    {
        let mut scene = ui.scene.borrow_mut();
        let report = scene.flush();
        assert_eq!(report.layout_nodes, 0);
        assert_eq!(scene.bounds(label), initial_bounds);
        gpu.render(&scene, &report.damage).unwrap();
    }
    let second = gpu.readback().unwrap();
    assert_eq!(
        &second[(60 * 128 + 120) * 4..(60 * 128 + 120) * 4 + 4],
        &[96, 48, 32, 255]
    );
    gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 64.)])
        .unwrap();
    assert_eq!(
        second,
        gpu.readback().unwrap(),
        "damage repaint matches full composition"
    );
}

#[test]
fn fluent_text_padding_and_background_render_as_one_box() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::text,
        style::{Styled, rgb},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(96, 48).unwrap();
    let mut ui = Ui::new(96., 48.);
    let mounted = ui.mount(
        text("A")
            .p(8.)
            .bg(rgb(0x206040))
            .text_color(rgb(0xffffff))
            .text_size(20.),
    );
    let mut scene = ui.scene.borrow_mut();
    let report = scene.flush();
    let outer = scene.bounds(mounted.node());
    let children = scene.children(mounted.node());
    assert_eq!(children.len(), 1);
    let inner = scene.bounds(children[0]);
    assert_eq!(inner.x, outer.x + 8.);
    assert_eq!(inner.y, outer.y + 8.);
    assert_eq!(outer.width, inner.width + 16.);
    assert_eq!(outer.height, inner.height + 16.);
    gpu.render(&scene, &report.damage).unwrap();
    let pixels = gpu.readback().unwrap();
    assert_eq!(
        &pixels[(2 * 96 + 2) * 4..(2 * 96 + 2) * 4 + 4],
        &[32, 96, 64, 255]
    );
    assert!(
        pixels
            .chunks_exact(4)
            .any(|p| p[0] > 220 && p[1] > 220 && p[2] > 220)
    );
}

#[test]
fn font_selection_changes_pixels_and_measurement_without_stale_cached_glyphs() {
    let _gpu_fixture = gpu_fixture();
    use zgui::text_layout::{FontFamily, FontStyle, TextLayout};
    let mut gpu = GpuRenderer::new(360, 80).unwrap();
    let mut scene = Scene::new(360., 80.);
    let fonts = gpu.text_system();
    let shared = fonts.clone();
    scene.set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut shared.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let id = scene.append(
        scene.root(),
        NodeKind::Text {
            text: "Hamburgefonts ffi".into(),
            color: Color(255, 255, 255, 255),
            font_size: 24.,
        },
        Style::default(),
    );
    let default_damage = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &default_damage).unwrap().shaped_nodes, 1);
    let regular = gpu.readback().unwrap();
    let mut previous = regular.clone();
    for font in [
        FontStyle {
            weight: 700,
            ..Default::default()
        },
        FontStyle {
            italic: true,
            ..Default::default()
        },
        FontStyle {
            family: FontFamily::Monospace,
            ..Default::default()
        },
        FontStyle {
            family: FontFamily::Serif,
            weight: 700,
            italic: true,
            ..Default::default()
        },
    ] {
        scene.set_font(id, font.clone());
        let report = scene.flush();
        assert!(report.layout_nodes > 0);
        let measured = scene.measure_text_with_font("Hamburgefonts ffi", 24., None, &font);
        assert_eq!(scene.bounds(id).width, measured.0);
        assert_eq!(gpu.render(&scene, &report.damage).unwrap().shaped_nodes, 1);
        let pixels = gpu.readback().unwrap();
        assert_ne!(
            pixels, previous,
            "font change must affect rasterized pixels"
        );
        assert_eq!(
            gpu.render(&scene, &[Rect::new(0., 0., 360., 80.)])
                .unwrap()
                .shaped_nodes,
            0
        );
        assert_eq!(gpu.readback().unwrap(), pixels);
        scene.set_font(id, font);
        assert!(scene.flush().is_idle());
        previous = pixels;
    }
    scene.set_font(id, FontStyle::default());
    let damage = scene.flush().damage;
    gpu.render(&scene, &damage).unwrap();
    assert_eq!(gpu.readback().unwrap(), regular);
}

#[test]
fn declarative_editors_keep_styled_text_caret_and_selection_correct_when_resized() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::{column, text_area, text_input},
        input::{InputEvent, Key, Modifiers},
        style::{Styled, Styles, rgb},
        text_layout::{FontFamily, FontStyle, TextLayout},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(320, 200).unwrap();
    let mut ui = Ui::new(320., 200.);
    let fonts = gpu.text_system();
    ui.scene.borrow_mut().set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let value = ui.signal("MMMM WWWW iii 0123".to_owned());
    let multiline = ui.signal("First line\nSecond line\nThird line".to_owned());
    let weight = ui.signal(700);
    let inherited_weight = weight.clone();
    let width = ui.signal(280.);
    let height = ui.signal(108.);
    let input_width = width.clone();
    let area_width = width.clone();
    let area_height = height.clone();
    let mounted = ui.mount(
        column()
            .size(320., 200.)
            .gap(8.)
            .bg(rgb(0x101820))
            .text_color(rgb(0xff4020))
            .text_size(22.)
            .font_family(FontFamily::Monospace)
            .reactive_style(move || Styles::new().font_weight(inherited_weight.get()))
            .child(
                text_input("Name", value.clone())
                    .id("input")
                    .h(44.)
                    .p(6.)
                    .bg(rgb(0x203040))
                    .rounded(0.)
                    .reactive_style(move || Styles::new().w(input_width.get())),
            )
            .child(
                text_area("Details", multiline.clone())
                    .id("area")
                    .p(6.)
                    .bg(rgb(0x203040))
                    .rounded(0.)
                    .reactive_style(move || Styles::new().w(area_width.get()).h(area_height.get())),
            ),
    );
    let render = |ui: &Ui, gpu: &mut GpuRenderer| {
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        gpu.render(&scene, &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&scene, &[Rect::new(0., 0., 320., 200.)])
            .unwrap();
        assert!(
            partial == gpu.readback().unwrap(),
            "incremental editor damage must reconstruct the full frame"
        );
        partial
    };
    let initial = render(&ui, &mut gpu);
    assert!(
        initial
            .chunks_exact(4)
            .filter(|p| p[0] > 200 && p[1] < 100 && p[2] < 80)
            .count()
            > 100,
        "inherited foreground must color actual glyph pixels"
    );
    weight.set(400);
    let regular = render(&ui, &mut gpu);
    assert!(
        regular != initial,
        "changing inherited font weight must change actual editor glyphs"
    );
    weight.set(700);
    assert!(
        render(&ui, &mut gpu) == initial,
        "restoring inherited typography restores both editors"
    );
    for id in ["input", "area"] {
        ui.input.focus(&ui.scene, Some(mounted.find(id).unwrap()));
        ui.dispatch(InputEvent::KeyDown {
            key: Key::End,
            modifiers: Modifiers::default(),
            repeat: false,
        });
        let pixels = render(&ui, &mut gpu);
        let editor = ui.focused_editor().unwrap();
        let caret = ui.scene.borrow().bounds(editor.caret);
        let x = caret.x.round() as usize;
        let y = (caret.y + caret.height / 2.).floor() as usize;
        let at = (y * 320 + x) * 4;
        assert!(
            pixels[at] > 200 && pixels[at + 1] < 100,
            "caret must inherit the red foreground: {:?}",
            &pixels[at..at + 4]
        );
        for _ in 0..4 {
            ui.dispatch(InputEvent::KeyDown {
                key: Key::ArrowLeft,
                modifiers: Modifiers {
                    shift: true,
                    ..Default::default()
                },
                repeat: false,
            });
        }
        let selected = render(&ui, &mut gpu);
        assert_ne!(
            selected, pixels,
            "keyboard selection must change rendered pixels"
        );
        assert!(!editor.copy().is_empty());
        assert!(
            selected.chunks_exact(4).any(|p| p[0].abs_diff(48) <= 1
                && p[1].abs_diff(81) <= 1
                && p[2].abs_diff(127) <= 1),
            "selection background must alpha-composite over the styled editor surface"
        );
        // Only allocation changes: neither text nor selection is reassigned.
        for (w, h) in [(110., 48.), (280., 108.), (150., 64.), (280., 108.)] {
            width.set(w);
            height.set(h);
            let resized = render(&ui, &mut gpu);
            if w == 280. {
                assert!(
                    resized == selected,
                    "growing the {id} editor restores its exact selection and text pixels"
                );
            }
        }
        ui.dispatch(InputEvent::Text("X".into()));
        assert_ne!(
            render(&ui, &mut gpu),
            selected,
            "editing selected text must repaint"
        );
    }
}

#[test]
fn declarative_virtual_rows_clip_padding_and_repair_scroll_damage() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let offset = ui.signal(0.);
    let height = ui.signal(80.);
    let read_height = height.clone();
    ui.mount(
        virtual_list(
            offset.clone(),
            20.,
            2,
            || 100_000,
            |i| i,
            |_, key, _| {
                div().size(112., 20.).bg(if key.is_multiple_of(2) {
                    rgb(0xee3322)
                } else {
                    rgb(0x2244ee)
                })
            },
        )
        .w(128.)
        .p(8.)
        .bg(rgb(0x102030))
        .reactive_style(move || Styles::new().h(read_height.get())),
    );
    for (scroll, viewport_height) in [
        (0., 80.),
        (13., 80.),
        (56013., 80.),
        (56013., 60.),
        (1999900., 80.),
        (0., 80.),
    ] {
        height.set(viewport_height);
        offset.set(scroll);
        ui.prepare_frame();
        let damage = ui.scene.borrow_mut().flush().damage;
        gpu.render(&ui.scene.borrow(), &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "scroll {scroll} height {viewport_height}"
        );
        let pixel = |x: usize, y: usize| &partial[(y * 128 + x) * 4..(y * 128 + x) * 4 + 4];
        assert_eq!(
            pixel(64, 4),
            &[16, 32, 48, 255],
            "rows must not paint top padding"
        );
        assert_eq!(
            pixel(64, viewport_height as usize - 4),
            &[16, 32, 48, 255],
            "rows must not paint bottom padding"
        );
        let key = ((offset.get() + 2.) / 20.).floor() as usize;
        assert_eq!(
            pixel(64, 10),
            if key.is_multiple_of(2) {
                &[238, 51, 34, 255]
            } else {
                &[34, 68, 238, 255]
            }
        );
        assert!(ui.scene.borrow().paint_items().count() < 100);
    }
}

#[test]
fn declarative_slider_damage_clears_old_thumb_and_resized_surface() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(420, 80).unwrap();
    let mut ui = Ui::new(420., 80.);
    let value = ui.signal(0.);
    let width = ui.signal(320.);
    let color = ui.signal(rgb(0x22dd77));
    let read_width = width.clone();
    let read_color = color.clone();
    let mounted = ui.mount(
        slider("Level", value.clone(), 0.0..=100.)
            .h(60.)
            .px(16.)
            .py(10.)
            .bg(rgb(0x102030))
            .reactive_style(move || {
                Styles::new()
                    .w(read_width.get())
                    .text_color(read_color.get())
            }),
    );
    for (amount, allocation, tint) in [
        (0., 320., rgb(0x22dd77)),
        (75., 320., rgb(0x22dd77)),
        (75., 120., rgb(0xcc4466)),
        (100., 400., rgb(0xcc4466)),
        (50., 320., rgb(0x22dd77)),
    ] {
        value.set(amount);
        width.set(allocation);
        color.set(tint);
        ui.prepare_frame();
        let damage = ui.scene.borrow_mut().flush().damage;
        gpu.render(&ui.scene.borrow(), &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 420., 80.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "value={amount}, width={allocation}"
        );
        let scene = ui.scene.borrow();
        let thumb = scene.bounds(scene.children(mounted.node())[2]);
        let x = (thumb.x + thumb.width / 2.) as usize;
        let y = (thumb.y + thumb.height / 2.) as usize;
        assert_eq!(
            &partial[(y * 420 + x) * 4..(y * 420 + x) * 4 + 4],
            &[tint.0, tint.1, tint.2, tint.3]
        );
        assert!(thumb.x >= 16. && thumb.x + thumb.width <= allocation - 16.);
    }
}

#[test]
fn declarative_progress_composites_fill_without_layout_or_padding_bleed() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(420, 80).unwrap();
    let mut ui = Ui::new(420., 80.);
    let value = ui.signal(0.);
    let width = ui.signal(208.);
    let read_width = width.clone();
    ui.mount(
        progress("Download", value.clone())
            .h(24.)
            .p(4.)
            .bg(rgb(0x102030))
            .text_color(rgb(0x22dd77))
            .reactive_style(move || Styles::new().w(read_width.get())),
    );
    let mut previous_width = 0.;
    for (amount, allocation) in [
        (0., 208.),
        (0.25, 208.),
        (0.75, 208.),
        (1., 208.),
        (0.5, 408.),
        (0., 408.),
        (1., 108.),
    ] {
        value.set(amount);
        width.set(allocation);
        ui.prepare_frame();
        let frame = ui.scene.borrow_mut().flush();
        if allocation == previous_width {
            assert_eq!(frame.layout_nodes, 0);
        }
        previous_width = allocation;
        gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 420., 80.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "progress={amount} width={allocation}"
        );
        let filled = partial
            .chunks_exact(4)
            .filter(|p| *p == [34, 221, 119, 255])
            .count();
        assert_eq!(filled, ((allocation - 8.) * amount) as usize * 16);
        for (x, y) in [(2, 12), (4, 2), (4, 22), (allocation as usize - 2, 12)] {
            assert_eq!(
                &partial[(y * 420 + x) * 4..(y * 420 + x) * 4 + 4],
                &[16, 32, 48, 255],
                "padding must stay track-colored"
            );
        }
    }
}

#[test]
fn declarative_images_repaint_source_and_allocated_content_without_padding_bleed() {
    let _gpu_fixture = gpu_fixture();
    use std::sync::Arc;
    use zgui::{compose::prelude::*, image::ImageData, widgets::Ui};
    let bitmap = |width, color: [u8; 4]| {
        Arc::new(ImageData::new(width, 4, color.repeat(width as usize * 4)).unwrap())
    };
    let red = bitmap(4, [220, 30, 40, 255]);
    let blue = bitmap(4, [30, 80, 220, 255]);
    let green = bitmap(8, [30, 220, 80, 255]);
    let mut gpu = GpuRenderer::new(160, 80).unwrap();
    let mut ui = Ui::new(160., 80.);
    let source = ui.signal(red.clone());
    let width = ui.signal(100.);
    let read_source = source.clone();
    let read_width = width.clone();
    ui.mount(
        image_signal("Preview", move || read_source.get())
            .h(60.)
            .p(4.)
            .bg(rgb(0x102030))
            .reactive_style(move || Styles::new().w(read_width.get())),
    );
    for (index, (bitmap, allocation, expected)) in [
        (red.clone(), 100., [220, 30, 40, 255]),
        (blue, 100., [30, 80, 220, 255]),
        (green, 140., [30, 220, 80, 255]),
        (red, 60., [220, 30, 40, 255]),
    ]
    .into_iter()
    .enumerate()
    {
        source.set(bitmap);
        width.set(allocation);
        ui.prepare_frame();
        let frame = ui.scene.borrow_mut().flush();
        if index == 1 {
            assert_eq!(frame.layout_nodes, 0);
        }
        gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 160., 80.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "source transition {index}"
        );
        assert_eq!(
            partial.chunks_exact(4).filter(|p| *p == expected).count(),
            (allocation as usize - 8) * 52
        );
        for (x, y) in [(2, 30), (10, 2), (10, 58), (allocation as usize - 2, 30)] {
            assert_eq!(
                &partial[(y * 160 + x) * 4..(y * 160 + x) * 4 + 4],
                &[16, 32, 48, 255]
            );
        }
    }
}

#[test]
fn declarative_scroll_clips_children_and_repairs_damage_without_relayout() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let offset = ui.signal(0.);
    let height = ui.signal(80.);
    let read_height = height.clone();
    ui.mount(
        scroll(offset.clone())
            .w(128.)
            .p(8.)
            .bg(rgb(0x102030))
            .reactive_style(move || Styles::new().h(read_height.get()))
            .children((0..8).map(|i| {
                div().size(112., 20.).shrink_0().bg(if i % 2 == 0 {
                    rgb(0xee3322)
                } else {
                    rgb(0x2244ee)
                })
            })),
    );
    let mut previous_height = 0.;
    for (position, allocation) in [
        (0., 80.),
        (13., 80.),
        (55., 80.),
        (55., 60.),
        (1000., 80.),
        (0., 80.),
    ] {
        height.set(allocation);
        offset.set(position);
        ui.prepare_frame();
        let frame = ui.scene.borrow_mut().flush();
        if allocation == previous_height {
            assert_eq!(frame.layout_nodes, 0);
        }
        previous_height = allocation;
        gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "scroll={position}, height={allocation}"
        );
        let pixel = |x: usize, y: usize| &partial[(y * 128 + x) * 4..(y * 128 + x) * 4 + 4];
        assert_eq!(pixel(64, 4), &[16, 32, 48, 255]);
        assert_eq!(pixel(64, allocation as usize - 4), &[16, 32, 48, 255]);
        let row = ((offset.get() + 2.) / 20.).floor() as usize;
        assert_eq!(
            pixel(64, 10),
            if row.is_multiple_of(2) {
                &[238, 51, 34, 255]
            } else {
                &[34, 68, 238, 255]
            }
        );
        assert!(offset.get() <= (160. - (allocation - 16.)).max(0.));
    }
}

#[test]
fn focused_scroll_descendant_is_revealed_with_correct_damage() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let offset = ui.signal(0.);
    let mounted = ui.mount(
        scroll(offset.clone())
            .size(128., 80.)
            .p(8.)
            .bg(rgb(0x102030))
            .child(
                button()
                    .id("first")
                    .size(80., 32.)
                    .bg(rgb(0xee3322))
                    .focus(|s| s),
            )
            .child(div().h(100.))
            .child(
                button()
                    .id("last")
                    .size(80., 32.)
                    .bg(rgb(0x2244ee))
                    .focus(|s| s),
            ),
    );
    ui.prepare_frame();
    let damage = ui.scene.borrow_mut().flush().damage;
    gpu.render(&ui.scene.borrow(), &damage).unwrap();
    for (id, expected_offset, expected_pixel) in [
        ("last", 100., [34, 68, 238, 255]),
        ("first", 0., [238, 51, 34, 255]),
    ] {
        let target = mounted.find(id).unwrap();
        assert!(ui.input.focus(&ui.scene, Some(target)));
        ui.prepare_frame();
        assert_eq!(offset.get(), expected_offset);
        let bounds = ui.scene.borrow().bounds(target);
        assert!(bounds.y >= 8. && bounds.y + bounds.height <= 72.);
        let frame = ui.scene.borrow_mut().flush();
        assert_eq!(frame.layout_nodes, 0);
        gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        let y = (bounds.y + 10.) as usize;
        assert_eq!(
            &partial[(y * 128 + 20) * 4..(y * 128 + 20) * 4 + 4],
            &expected_pixel
        );
    }
}

#[test]
fn horizontal_scroll_clips_padding_and_repairs_compositor_damage() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(176, 96).unwrap();
    let mut ui = Ui::new(176., 96.);
    let offset = ui.signal(0.);
    let width = ui.signal(128.);
    let read_width = width.clone();
    ui.mount(
        scroll_x(offset.clone())
            .h(80.)
            .p(8.)
            .bg(rgb(0x102030))
            .reactive_style(move || Styles::new().w(read_width.get()))
            .children((0..8).map(|i| {
                div().size(40., 64.).shrink_0().bg(if i % 2 == 0 {
                    rgb(0xee3322)
                } else {
                    rgb(0x2244ee)
                })
            })),
    );
    let mut previous_width = 0.;
    for (position, allocation) in [
        (0., 128.),
        (13., 128.),
        (55., 128.),
        (1000., 128.),
        (1000., 160.),
        (0., 128.),
    ] {
        width.set(allocation);
        offset.set(position);
        ui.prepare_frame();
        let frame = ui.scene.borrow_mut().flush();
        if allocation == previous_width {
            assert_eq!(frame.layout_nodes, 0);
        }
        previous_width = allocation;
        gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 176., 96.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "offset={position} width={allocation}"
        );
        let pixel = |x: usize, y: usize| &partial[(y * 176 + x) * 4..(y * 176 + x) * 4 + 4];
        assert_eq!(pixel(4, 40), &[16, 32, 48, 255]);
        assert_eq!(pixel(allocation as usize - 4, 40), &[16, 32, 48, 255]);
        assert_eq!(pixel(12, 4), &[16, 32, 48, 255]);
        let cell = ((offset.get() + 2.) / 40.).floor() as usize;
        assert_eq!(
            pixel(10, 40),
            if cell.is_multiple_of(2) {
                &[238, 51, 34, 255]
            } else {
                &[34, 68, 238, 255]
            }
        );
        assert!(offset.get() <= 320. - (allocation - 16.));
    }
}

#[test]
fn overlay_scrollbar_thumb_translates_and_clears_when_content_shrinks() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let offset = ui.signal(0.);
    let extent = ui.signal(400.);
    let read_extent = extent.clone();
    ui.mount(
        scroll(offset.clone())
            .size(128., 80.)
            .p(8.)
            .bg(rgb(0x102030))
            .scrollbar(true)
            .child(
                div()
                    .bg(rgb(0x442211))
                    .reactive_style(move || Styles::new().w(112.).h(read_extent.get())),
            ),
    );
    let mut previous_extent = 0.;
    for (position, height, thumb_y) in [
        (0., 400., Some(8)),
        (168., 400., Some(28)),
        (336., 400., Some(48)),
        (0., 40., None),
        (0., 400., Some(8)),
    ] {
        extent.set(height);
        offset.set(position);
        ui.prepare_frame();
        let frame = ui.scene.borrow_mut().flush();
        if height == previous_extent {
            assert_eq!(frame.layout_nodes, 0);
        }
        previous_extent = height;
        gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        let accent = [94, 165, 255, 255];
        let visible: Vec<_> = partial
            .chunks_exact(4)
            .enumerate()
            .filter(|(_, p)| *p == accent)
            .map(|(i, _)| (i % 128, i / 128))
            .collect();
        match thumb_y {
            Some(y) => {
                assert_eq!(visible.len(), 8 * 24);
                assert!(
                    visible
                        .iter()
                        .all(|(x, row)| *x >= 112 && *x < 120 && *row >= y && *row < y + 24)
                );
            }
            None => assert!(visible.is_empty()),
        }
    }
}

#[test]
fn virtual_keyboard_end_home_repaint_only_retained_visible_rows() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let mounted = ui.mount(
        virtual_list(
            ui.signal(0.),
            20.,
            1,
            || 1_000_000,
            |i| i,
            |_, i, _| {
                div().size(112., 20.).bg(if i.is_multiple_of(2) {
                    rgb(0xee3322)
                } else {
                    rgb(0x2244ee)
                })
            },
        )
        .size(128., 96.)
        .p(8.)
        .bg(rgb(0x102030))
        .keyboard_navigation(true),
    );
    ui.prepare_frame();
    let damage = ui.scene.borrow_mut().flush().damage;
    gpu.render(&ui.scene.borrow(), &damage).unwrap();
    assert!(ui.input.focus(&ui.scene, Some(mounted.node())));
    for (key, position, color) in [
        (Key::End, 1_000_000, [34, 68, 238, 255]),
        (Key::Home, 1, [238, 51, 34, 255]),
    ] {
        ui.dispatch(InputEvent::KeyDown {
            key,
            modifiers: Modifiers::default(),
            repeat: false,
        });
        ui.prepare_frame();
        let focused = ui.input.focused().unwrap();
        assert_eq!(
            ui.semantics.borrow().get(focused).unwrap().position_in_set,
            Some(position)
        );
        let bounds = ui.scene.borrow().bounds(focused);
        assert!(bounds.y >= 8. && bounds.y + bounds.height <= 88.);
        let damage = ui.scene.borrow_mut().flush().damage;
        gpu.render(&ui.scene.borrow(), &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        let y = (bounds.y + 10.) as usize;
        assert_eq!(&partial[(y * 128 + 64) * 4..(y * 128 + 64) * 4 + 4], &color);
        assert!(ui.scene.borrow().paint_items().count() < 100);
    }
}

#[test]
fn independent_devices_render_concurrently_with_bounded_workers() {
    let _gpu_fixture = gpu_fixture();
    exercise_independent_devices(4, 1);
}

/// Explicit diagnostic load, excluded from ordinary CI and workspace runs.
#[test]
#[ignore = "opt-in independent-device lifecycle stress; may consume substantial driver resources"]
fn independent_device_lifecycle_stress() {
    let _gpu_fixture = gpu_fixture();
    let setting = |name: &str, default: usize, limit: usize| {
        let value = std::env::var(name)
            .map(|v| v.parse::<usize>().expect("positive integer setting"))
            .unwrap_or(default);
        assert!(
            (1..=limit).contains(&value),
            "{name} must be between 1 and {limit}"
        );
        value
    };
    let workers = setting("ZGUI_GPU_STRESS_WORKERS", 24, 64);
    let iterations = setting("ZGUI_GPU_STRESS_ITERATIONS", 10, 100);
    eprintln!("independent device stress: {workers} workers, {iterations} iterations each");
    exercise_independent_devices(workers, iterations);
}

fn exercise_independent_devices(worker_count: usize, iterations: usize) {
    let start = std::sync::Arc::new(std::sync::Barrier::new(worker_count));
    let workers: Vec<_> = (0..worker_count)
        .map(|index| {
            let start = start.clone();
            std::thread::spawn(move || {
                start.wait();
                for _ in 0..iterations {
                    let mut gpu = GpuRenderer::new(32, 32).unwrap();
                    let mut scene = Scene::new(32., 32.);
                    let color = Color(40 + (index % 4) as u8 * 40, 60, 80, 255);
                    scene.append(scene.root(), NodeKind::Rect(color), fixed(32., 32.));
                    let damage = scene.flush().damage;
                    gpu.render(&scene, &damage).unwrap();
                    let pixels = gpu.readback().unwrap();
                    assert!(
                        pixels
                            .chunks_exact(4)
                            .all(|pixel| pixel == [color.0, color.1, color.2, color.3])
                    );
                }
            })
        })
        .collect();
    for worker in workers {
        worker.join().unwrap();
    }
}

#[test]
fn declarative_portals_restore_pixels_and_track_clipped_anchors_without_layout() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let open = ui.signal(false);
    let mounted = ui.mount(
        column().size(128., 96.).bg(rgb(0x285078)).child(
            modal("Dialog", open.clone())
                .size(64., 40.)
                .p(0.)
                .rounded(0.)
                .bg(rgb(0xee3322)),
        ),
    );
    let mut render = |ui: &Ui| {
        ui.prepare_frame();
        let report = ui.scene.borrow_mut().flush();
        gpu.render(&ui.scene.borrow(), &report.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        (partial, report.layout_nodes)
    };
    let (closed, _) = render(&ui);
    assert!(
        closed
            .chunks_exact(4)
            .all(|pixel| pixel == [40, 80, 120, 255])
    );
    open.set(true);
    let (shown, _) = render(&ui);
    let pixel = |pixels: &[u8], x: usize, y: usize| {
        pixels[(y * 128 + x) * 4..(y * 128 + x) * 4 + 4].to_vec()
    };
    assert_eq!(pixel(&shown, 64, 48), [238, 51, 34, 255]);
    assert!(pixel(&shown, 4, 4)[0] < 40); // modal backdrop dims the page
    open.set(false);
    assert_eq!(render(&ui).0, closed);
    mounted.unmount();

    let open = ui.signal(true);
    let movement = ui.signal((0., 0.));
    let read = movement.clone();
    let mounted = ui.mount(
        column().size(128., 96.).bg(rgb(0x285078)).child(
            column().size(128., 32.).p(8.).overflow_hidden().child(
                popover(
                    "Details",
                    open.clone(),
                    div().size(16., 16.).reactive_style(move || {
                        let (x, y) = read.get();
                        Styles::new().translate(x, y)
                    }),
                )
                .size(48., 24.)
                .p(0.)
                .rounded(0.)
                .bg(rgb(0xee3322)),
            ),
        ),
    );
    let (initial, _) = render(&ui);
    assert_eq!(pixel(&initial, 16, 44), [238, 51, 34, 255]); // escapes anchor clip
    movement.set((40., 16.));
    let (moved, layout_nodes) = render(&ui);
    assert_eq!(layout_nodes, 0);
    assert_eq!(pixel(&moved, 16, 44), [40, 80, 120, 255]);
    assert_eq!(pixel(&moved, 64, 60), [238, 51, 34, 255]);
    open.set(false);
    assert_eq!(render(&ui).0, closed);
    mounted.unmount();
}

#[test]
fn declarative_menu_focus_and_dismissal_match_full_repaint() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(128, 128).unwrap();
    let mut ui = Ui::new(128., 128.);
    let open = ui.signal(false);
    let item = |label: &str| {
        menu_item(label)
            .size(88., 20.)
            .p(0.)
            .rounded(0.)
            .bg(rgb(0x224466))
            .focus(|s| s.bg(rgb(0xeeaa22)))
    };
    let view = ui.mount(
        column().size(128., 128.).p(8.).bg(rgb(0x142030)).child(
            menu(
                "Actions",
                open.clone(),
                button()
                    .id("anchor")
                    .size(32., 20.)
                    .p(0.)
                    .child(text("Menu")),
            )
            .size(96., 68.)
            .p(4.)
            .rounded(0.)
            .bg(rgb(0x303840))
            .child(item("One").id("one"))
            .child(item("Two").disabled(true))
            .child(item("Three").id("three")),
        ),
    );
    let mut render = |ui: &Ui| {
        ui.prepare_frame();
        let report = ui.scene.borrow_mut().flush();
        gpu.render(&ui.scene.borrow(), &report.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 128.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        (partial, report.layout_nodes)
    };
    ui.prepare_frame();
    ui.input.focus(&ui.scene, view.find("anchor"));
    let closed = render(&ui).0;
    open.set(true);
    let (first, _) = render(&ui);
    let focused = view.find("one").unwrap();
    assert_eq!(ui.input.focused(), Some(focused));
    let sample = |ui: &Ui, pixels: &[u8], node| {
        let bounds = ui.scene.borrow().bounds(node);
        let index = ((bounds.y as usize + 10) * 128 + bounds.x as usize + 80) * 4;
        pixels[index..index + 4].to_vec()
    };
    assert_eq!(sample(&ui, &first, focused), [238, 170, 34, 255]);
    ui.dispatch(InputEvent::KeyDown {
        key: Key::ArrowDown,
        modifiers: Modifiers::default(),
        repeat: false,
    });
    let (next, layout_nodes) = render(&ui);
    assert_eq!(layout_nodes, 0);
    let focused = view.find("three").unwrap();
    assert_eq!(ui.input.focused(), Some(focused));
    assert_eq!(sample(&ui, &next, focused), [238, 170, 34, 255]);
    ui.dispatch(InputEvent::KeyDown {
        key: Key::Escape,
        modifiers: Modifiers::default(),
        repeat: false,
    });
    assert!(!open.get());
    assert!(
        render(&ui).0 == closed,
        "dismissal must restore the focused-trigger baseline"
    );
}

#[test]
fn overflowing_menu_keeps_keyboard_focus_pixels_inside_padded_viewport() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let view = ui.mount(
        column().size(128., 96.).bg(rgb(0x142030)).child(
            menu(
                "Long",
                ui.signal(true),
                button().size(32., 20.).p(0.).child("Menu"),
            )
            .id("panel")
            .w(96.)
            .max_h(60.)
            .p(4.)
            .rounded(0.)
            .bg(rgb(0x303840))
            .children((0..20).map(|i| {
                menu_item(format!("Row {i}"))
                    .id(format!("item{i}"))
                    .h(16.)
                    .p(0.)
                    .text_size(8.)
                    .rounded(0.)
                    .bg(rgb(0x224466))
                    .focus(|s| s.bg(rgb(0xeeaa22)))
            })),
        ),
    );
    ui.prepare_frame();
    let damage = ui.scene.borrow_mut().flush().damage;
    gpu.render(&ui.scene.borrow(), &damage).unwrap();
    for (key, id) in [(Key::End, "item19"), (Key::Home, "item0")] {
        ui.dispatch(InputEvent::KeyDown {
            key,
            modifiers: Modifiers::default(),
            repeat: false,
        });
        ui.prepare_frame();
        let report = ui.scene.borrow_mut().flush();
        assert_eq!(report.layout_nodes, 0);
        gpu.render(&ui.scene.borrow(), &report.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert!(
            partial == gpu.readback().unwrap(),
            "menu scrolling damage must match a full repaint"
        );
        let focused = view.find(id).unwrap();
        assert_eq!(ui.input.focused(), Some(focused));
        let bounds = ui.scene.borrow().bounds(focused);
        let index = ((bounds.y as usize + 8) * 128 + bounds.x as usize + 80) * 4;
        assert_eq!(&partial[index..index + 4], &[238, 170, 34, 255]);
        let panel = ui.scene.borrow().bounds(view.find("panel").unwrap());
        for y in [panel.y as usize + 2, (panel.y + panel.height) as usize - 2] {
            let index = (y * 128 + panel.x as usize + 80) * 4;
            assert_eq!(&partial[index..index + 4], &[48, 56, 64, 255]);
        }
    }
}

#[test]
fn submenu_side_flip_and_dismissal_match_full_repaint_without_layout() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(400, 240).unwrap();
    let mut ui = Ui::new(400., 240.);
    let open = ui.signal(false);
    let child_open = ui.signal(false);
    let movement = ui.signal(0.);
    let read = movement.clone();
    let view = ui.mount(
        column()
            .p(20.)
            .reactive_style(move || Styles::new().translate(read.get(), 0.))
            .child(
                menu(
                    "Actions",
                    open.clone(),
                    button().size(60., 20.).p(0.).child("Actions"),
                )
                .id("parent")
                .w(160.)
                .p(4.)
                .rounded(0.)
                .bg(rgb(0x224466))
                .child(
                    submenu("More", child_open.clone())
                        .id("child")
                        .size(100., 60.)
                        .p(4.)
                        .rounded(0.)
                        .bg(rgb(0xee3322))
                        .child(menu_item("Run").id("run").h(20.).p(0.).bg(rgb(0xee3322))),
                ),
            ),
    );
    let mut render = |ui: &Ui| {
        ui.prepare_frame();
        let report = ui.scene.borrow_mut().flush();
        gpu.render(&ui.scene.borrow(), &report.damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 400., 240.)])
            .unwrap();
        assert!(
            partial == gpu.readback().unwrap(),
            "submenu damage must match a full repaint"
        );
        (partial, report.layout_nodes)
    };
    open.set(true);
    render(&ui);
    ui.dispatch(InputEvent::KeyDown {
        key: Key::ArrowRight,
        modifiers: Modifiers::default(),
        repeat: false,
    });
    let (shown, _) = render(&ui);
    assert!(open.get() && child_open.get());
    assert_eq!(ui.input.focused(), view.find("run"));
    let child = view.find("child").unwrap();
    let parent = view.find("parent").unwrap();
    let bounds = ui.scene.borrow().bounds(child);
    let parent_bounds = ui.scene.borrow().bounds(parent);
    assert!(bounds.x >= parent_bounds.x + parent_bounds.width);
    let pixel = |pixels: &[u8], rect: Rect| {
        let i = ((rect.y as usize + 50) * 400 + rect.x as usize + 90) * 4;
        pixels[i..i + 4].to_vec()
    };
    assert_eq!(pixel(&shown, bounds), [238, 51, 34, 255]);
    movement.set(200.);
    let (flipped, layout) = render(&ui);
    assert_eq!(layout, 0);
    let bounds = ui.scene.borrow().bounds(child);
    let parent_bounds = ui.scene.borrow().bounds(parent);
    assert!(bounds.x + bounds.width <= parent_bounds.x);
    assert_eq!(pixel(&flipped, bounds), [238, 51, 34, 255]);
    ui.dispatch(InputEvent::KeyDown {
        key: Key::ArrowLeft,
        modifiers: Modifiers::default(),
        repeat: false,
    });
    render(&ui);
    assert!(open.get());
    assert!(!child_open.get());
    ui.dispatch(InputEvent::KeyDown {
        key: Key::Escape,
        modifiers: Modifiers::default(),
        repeat: false,
    });
    render(&ui);
    assert!(!open.get());
}

#[test]
fn wrapped_editor_pixels_follow_allocation_selection_and_preedit() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        text_layout::{FontFamily, FontStyle, TextLayout},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(320, 180).unwrap();
    let mut ui = Ui::new(320., 180.);
    let fonts = gpu.text_system();
    ui.scene.borrow_mut().set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let original = "Alpha bravo charlie delta echo foxtrot golf hotel india juliet kilo lima";
    let value = ui.signal(original.to_owned());
    let width = ui.signal(180.);
    let wrapped = ui.signal(true);
    let styled_width = width.clone();
    let styled_wrap = wrapped.clone();
    let mounted = ui.mount(
        column().size(320., 180.).p(8.).bg(rgb(0x101820)).child(
            text_area("Wrapped", value.clone())
                .id("editor")
                .h(140.)
                .p(8.)
                .rounded(0.)
                .bg(rgb(0x203040))
                .text_color(rgb(0xff4020))
                .text_size(18.)
                .font_family(FontFamily::Monospace)
                .reactive_style(move || {
                    Styles::new()
                        .w(styled_width.get())
                        .text_wrap(styled_wrap.get())
                }),
        ),
    );
    let render = |ui: &Ui, gpu: &mut GpuRenderer| {
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        gpu.render(&scene, &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&scene, &[Rect::new(0., 0., 320., 180.)])
            .unwrap();
        assert!(
            partial == gpu.readback().unwrap(),
            "wrapped editor damage must match full repaint"
        );
        partial
    };
    let initial = render(&ui, &mut gpu);
    let red_rows = |pixels: &[u8]| {
        (0..180)
            .filter(|y| {
                pixels[y * 320 * 4..(y + 1) * 320 * 4]
                    .chunks_exact(4)
                    .any(|p| p[0] > 200 && p[1] < 100 && p[2] < 80)
            })
            .count()
    };
    wrapped.set(false);
    let unwrapped = render(&ui, &mut gpu);
    assert!(
        red_rows(&initial) > red_rows(&unwrapped) * 2,
        "wrapping must paint multiple actual glyph lines"
    );
    wrapped.set(true);
    assert!(render(&ui, &mut gpu) == initial);
    ui.input.focus(&ui.scene, mounted.find("editor"));
    let editor = ui.focused_editor().unwrap();
    ui.dispatch(InputEvent::KeyDown {
        key: Key::End,
        modifiers: Modifiers {
            control: true,
            ..Default::default()
        },
        repeat: false,
    });
    for w in [180., 112., 280., 180.] {
        width.set(w);
        let pixels = render(&ui, &mut gpu);
        let scene = ui.scene.borrow();
        let bounds = scene.bounds(editor.node);
        let caret = scene.bounds(editor.caret);
        assert!(caret.x >= bounds.x + 8. && caret.x + caret.width <= bounds.x + bounds.width - 7.);
        assert!(
            caret.y >= bounds.y + 8. && caret.y + caret.height <= bounds.y + bounds.height - 7.
        );
        let at =
            (((caret.y + caret.height / 2.).floor() as usize) * 320 + caret.x.round() as usize) * 4;
        assert!(
            pixels[at] > 200 && pixels[at + 1] < 100,
            "visible caret must track wrapped geometry"
        );
    }
    assert_eq!(
        value.get(),
        original,
        "soft wrapping never inserts line breaks"
    );
    ui.dispatch(InputEvent::KeyDown {
        key: Key::Character("a".into()),
        modifiers: Modifiers {
            control: true,
            ..Default::default()
        },
        repeat: false,
    });
    let selected = render(&ui, &mut gpu);
    assert!(
        selected
            .chunks_exact(4)
            .any(|p| p[0].abs_diff(48) <= 1 && p[1].abs_diff(81) <= 1 && p[2].abs_diff(127) <= 1)
    );
    let preedit = "caf\u{e9} composed words across wrapped lines";
    ui.dispatch(InputEvent::ImePreedit {
        text: preedit.into(),
        cursor: Some((preedit.len(), preedit.len())),
    });
    render(&ui, &mut gpu);
    assert_eq!(value.get(), original);
    ui.dispatch(InputEvent::ImeCommit(preedit.into()));
    render(&ui, &mut gpu);
    assert_eq!(value.get(), preedit);
    value.set("trailing newline\n".into());
    ui.dispatch(InputEvent::KeyDown {
        key: Key::End,
        modifiers: Modifiers {
            control: true,
            ..Default::default()
        },
        repeat: false,
    });
    let pixels = render(&ui, &mut gpu);
    let scene = ui.scene.borrow();
    let bounds = scene.bounds(editor.node);
    let caret = scene.bounds(editor.caret);
    assert!(caret.y >= bounds.y + 8. + caret.height);
    let at =
        (((caret.y + caret.height / 2.).floor() as usize) * 320 + caret.x.round() as usize) * 4;
    assert!(
        pixels[at] > 200 && pixels[at + 1] < 100,
        "trailing empty line must retain a visible caret"
    );
}

#[test]
fn inherited_line_height_reflows_glyphs_and_editor_without_rasterizing_again() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        text_layout::{FontFamily, FontStyle, TextLayout},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(320, 300).unwrap();
    let mut ui = Ui::new(320., 300.);
    let fonts = gpu.text_system();
    ui.scene.borrow_mut().set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let pitch = ui.signal(None::<f32>);
    let read_pitch = pitch.clone();
    let value = ui.signal("Ag\nAg\nAg".to_owned());
    let mounted = ui.mount(
        column()
            .size(320., 300.)
            .p(8.)
            .gap(8.)
            .bg(rgb(0x101820))
            .text_color(rgb(0xff4020))
            .text_size(20.)
            .font_family(FontFamily::Monospace)
            .reactive_style(move || match read_pitch.get() {
                Some(height) => Styles::new().line_height(height),
                None => Styles::new().line_height_normal(),
            })
            .child(text("Ag\nAg\nAg").id("label"))
            .child(
                text_area("Editor", value.clone())
                    .id("editor")
                    .size(280., 140.)
                    .p(8.)
                    .rounded(0.)
                    .bg(rgb(0x203040)),
            ),
    );
    ui.input.focus(&ui.scene, mounted.find("editor"));
    ui.dispatch(InputEvent::KeyDown {
        key: Key::Home,
        modifiers: Modifiers {
            control: true,
            ..Default::default()
        },
        repeat: false,
    });
    ui.dispatch(InputEvent::KeyDown {
        key: Key::ArrowDown,
        modifiers: Modifiers::default(),
        repeat: false,
    });
    let editor = ui.focused_editor().unwrap();
    let selection = editor.editor.borrow().selection();
    let render = |ui: &Ui, gpu: &mut GpuRenderer| {
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        let stats = gpu.render(&scene, &damage).unwrap();
        let pixels = gpu.readback().unwrap();
        gpu.render(&scene, &[Rect::new(0., 0., 320., 300.)])
            .unwrap();
        assert!(
            pixels == gpu.readback().unwrap(),
            "line-height damage, including tight outer clipping, must match full repaint"
        );
        (pixels, stats)
    };
    let (initial, _) = render(&ui, &mut gpu);
    let mut previous = initial.clone();
    for (height, expected) in [(Some(40.), 40.), (Some(12.), 12.), (None, 28.)] {
        pitch.set(height);
        let (pixels, stats) = render(&ui, &mut gpu);
        assert!(
            pixels != previous,
            "line-height changes actual painted glyph placement"
        );
        assert_eq!(
            stats.glyph_uploads, 0,
            "line-height changes reuse existing rasterized glyphs"
        );
        let scene = ui.scene.borrow();
        assert_eq!(
            scene.bounds(mounted.find("label").unwrap()).height,
            expected * 3.
        );
        let caret = scene.bounds(editor.caret);
        let bounds = scene.bounds(editor.node);
        assert_eq!(caret.height, expected);
        assert!(
            (caret.y - bounds.y - 8. - expected).abs() < 0.01,
            "pitch={expected} caret={caret:?} root={bounds:?} selection={selection:?}"
        );
        let at =
            (((caret.y + caret.height / 2.).floor() as usize) * 320 + caret.x.round() as usize) * 4;
        assert!(pixels[at] > 200 && pixels[at + 1] < 100);
        assert_eq!(editor.editor.borrow().selection(), selection);
        assert_eq!(value.get(), "Ag\nAg\nAg");
        previous = pixels;
    }
    assert!(
        previous == initial,
        "normal reset restores exact glyph and caret pixels"
    );
}

#[test]
fn unchanged_native_editor_reuses_shaping_and_preserves_damage_pixels() {
    let _gpu_fixture = gpu_fixture();
    use std::{cell::Cell, rc::Rc};
    use zgui::{
        compose::prelude::*,
        input::{InputEvent, Key, Modifiers},
        text_layout::{FontStyle, TextLayout},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(320, 180).unwrap();
    let mut ui = Ui::new(320., 180.);
    let calls = Rc::new(Cell::new(0));
    let count = calls.clone();
    let fonts = gpu.text_system();
    ui.scene.borrow_mut().set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            count.set(count.get() + 1);
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let value = ui.signal("Alpha e\u{301} emoji 👩‍💻\nSecond line\nThird line".to_owned());
    let mounted = ui.mount(
        text_area("Editor", value.clone())
            .size(300., 160.)
            .p(8.)
            .text_size(18.)
            .text_wrap(true)
            .bg(rgb(0x203040)),
    );
    ui.prepare_frame();
    ui.input.focus(&ui.scene, Some(mounted.node()));
    ui.prepare_frame();
    let editor = ui.focused_editor().unwrap();
    editor.editor.borrow_mut().set_selection(0, 0);
    editor.refresh();
    ui.prepare_frame();
    {
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        gpu.render(&scene, &damage).unwrap();
    }
    calls.set(0);
    for key in [Key::End, Key::ArrowDown, Key::Home, Key::ArrowUp] {
        ui.dispatch(InputEvent::KeyDown {
            key,
            modifiers: Modifiers::default(),
            repeat: false,
        });
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        gpu.render(&scene, &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&scene, &[Rect::new(0., 0., 320., 180.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "cached editor damage differs from full repaint"
        );
    }
    assert_eq!(
        calls.get(),
        0,
        "navigation must reuse the native editor layout"
    );
    assert_eq!(editor.editor.borrow().selection().focus, 0);
    assert_eq!(editor.editor.borrow().text(), value.get());
}

#[test]
fn percentage_panel_resize_updates_damage_and_keeps_idle_layout_cached() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(320, 200).unwrap();
    let mut ui = Ui::new(320., 200.);
    let width = ui.signal(240.);
    let read_width = width.clone();
    let mounted = ui.mount(
        overlay().w_full().h_full().bg(rgb(0x102030)).child(
            overlay()
                .h(120.)
                .p(10.)
                .bg(rgb(0x304050))
                .reactive_style(move || Styles::new().w(read_width.get()))
                .child(
                    overlay()
                        .id("half")
                        .w_percent(50.)
                        .h_full()
                        .bg(rgb(0xff0000)),
                ),
        ),
    );
    let half = mounted.find("half").unwrap();
    for (parent_width, child_width) in [(240., 110.), (160., 70.), (280., 130.)] {
        width.set(parent_width);
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        assert_eq!(scene.bounds(half), Rect::new(10., 10., child_width, 100.));
        let damage = scene.flush().damage;
        gpu.render(&scene, &damage).unwrap();
        let partial = gpu.readback().unwrap();
        assert_eq!(
            partial
                .chunks_exact(4)
                .filter(|p| p[0] == 255 && p[1] == 0 && p[2] == 0)
                .count(),
            child_width as usize * 100
        );
        gpu.render(&scene, &[Rect::new(0., 0., 320., 200.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        assert!(scene.flush().damage.is_empty());
    }
}

#[test]
fn inherited_letter_spacing_updates_editor_and_pixels_without_new_glyph_uploads() {
    let _gpu_fixture = gpu_fixture();
    use zgui::{
        compose::prelude::*,
        text_layout::{FontFamily, FontStyle, TextLayout},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(320, 200).unwrap();
    let mut ui = Ui::new(320., 200.);
    let fonts = gpu.text_system();
    ui.scene.borrow_mut().set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let spacing = ui.signal(0.);
    let read_spacing = spacing.clone();
    let model = ui.signal("ABCDEF".to_owned());
    let mounted = ui.mount(
        column()
            .size(320., 200.)
            .p(8.)
            .gap(8.)
            .items_start()
            .bg(rgb(0x102030))
            .text_color(rgb(0xff4020))
            .text_size(20.)
            .font_family(FontFamily::Monospace)
            .reactive_style(move || Styles::new().letter_spacing(read_spacing.get()))
            .child(text("ABCDEF").id("label"))
            .child(
                text_area("Editor", model.clone())
                    .id("editor")
                    .size(280., 80.)
                    .p(8.),
            ),
    );
    ui.prepare_frame();
    ui.input.focus(&ui.scene, mounted.find("editor"));
    let editor = ui.focused_editor().unwrap();
    editor.editor.borrow_mut().set_selection(3, 3);
    editor.refresh();
    ui.prepare_frame();
    let label = mounted.find("label").unwrap();
    let baseline_width = ui.scene.borrow().bounds(label).width;
    let baseline_caret = ui.scene.borrow().bounds(editor.caret).x;
    let mut initial = Vec::new();
    for (index, value) in [0., 3., -1., 0.].into_iter().enumerate() {
        spacing.set(value);
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        assert!((scene.bounds(label).width - baseline_width - 6. * value).abs() < 0.01);
        assert!((scene.bounds(editor.caret).x - baseline_caret - 3. * value).abs() < 0.01);
        assert_eq!(editor.editor.borrow().selection().focus, 3);
        assert_eq!(editor.editor.borrow().text(), "ABCDEF");
        let damage = scene.flush().damage;
        let stats = gpu.render(&scene, &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&scene, &[Rect::new(0., 0., 320., 200.)])
            .unwrap();
        assert_eq!(partial, gpu.readback().unwrap());
        if index == 0 {
            initial = partial;
        } else {
            assert_eq!(
                stats.glyph_uploads, 0,
                "tracking changes glyph placement, not glyph bitmaps"
            );
            if value == 0. {
                assert_eq!(partial, initial);
            } else {
                assert_ne!(partial, initial);
            }
        }
    }
}

#[test]
fn object_fit_pixels_crop_center_and_reuse_uploaded_image_across_transitions() {
    let _gpu_fixture = gpu_fixture();
    use std::sync::Arc;
    use zgui::{compose::prelude::*, image::ImageData, widgets::Ui};
    let colors = [
        [220, 30, 40, 255],
        [30, 210, 60, 255],
        [30, 70, 220, 255],
        [230, 200, 20, 255],
    ];
    let pixels: Vec<u8> = (0..20)
        .flat_map(|_| (0..40).flat_map(|x| colors[x / 10]))
        .collect();
    let source = Arc::new(ImageData::new(40, 20, pixels).unwrap());
    let mut gpu = GpuRenderer::new(112, 104).unwrap();
    let mut ui = Ui::new(112., 104.);
    let fit = ui.signal(ObjectFit::Fill);
    let size = ui.signal((88., 88.));
    let bitmap = ui.signal(source);
    let read_fit = fit.clone();
    let read_size = size.clone();
    let read_bitmap = bitmap.clone();
    ui.mount(
        image_signal("Pattern", move || read_bitmap.get())
            .p(4.)
            .bg(rgb(0x102030))
            .reactive_style(move || {
                let (w, h) = read_size.get();
                Styles::new().size(w, h).object_fit(read_fit.get())
            }),
    );
    let background = [16, 32, 48, 255];
    for (index, (mode, allocation, colored_area, samples)) in [
        (
            ObjectFit::Fill,
            88.,
            6400,
            vec![(10, 10, colors[0]), (76, 10, colors[3])],
        ),
        (
            ObjectFit::Contain,
            88.,
            3200,
            vec![
                (10, 10, background),
                (10, 30, colors[0]),
                (76, 30, colors[3]),
            ],
        ),
        (
            ObjectFit::Cover,
            88.,
            6400,
            vec![(10, 10, colors[1]), (76, 10, colors[2])],
        ),
        (
            ObjectFit::None,
            88.,
            800,
            vec![
                (10, 10, background),
                (26, 36, colors[0]),
                (60, 36, colors[3]),
            ],
        ),
        (
            ObjectFit::ScaleDown,
            88.,
            800,
            vec![(10, 10, background), (26, 36, colors[0])],
        ),
        (
            ObjectFit::ScaleDown,
            28.,
            200,
            vec![(5, 5, background), (5, 12, colors[0]), (22, 12, colors[3])],
        ),
        (
            ObjectFit::Cover,
            28.,
            400,
            vec![(5, 5, colors[1]), (22, 5, colors[2])],
        ),
        (
            ObjectFit::Fill,
            88.,
            6400,
            vec![(10, 10, colors[0]), (76, 10, colors[3])],
        ),
    ]
    .into_iter()
    .enumerate()
    {
        fit.set(mode);
        size.set((allocation, allocation));
        ui.prepare_frame();
        let frame = ui.scene.borrow_mut().flush();
        let stats = gpu.render(&ui.scene.borrow(), &frame.damage).unwrap();
        assert_eq!(
            stats.image_uploads,
            usize::from(index == 0),
            "fit stage {index}"
        );
        assert_eq!(gpu.debug_cache_stats().image_textures, 1);
        let partial = gpu.readback().unwrap();
        let full = gpu
            .render(&ui.scene.borrow(), &[Rect::new(0., 0., 112., 104.)])
            .unwrap();
        assert_eq!(full.image_uploads, 0);
        assert_eq!(partial, gpu.readback().unwrap(), "damage stage {index}");
        let color_count = partial
            .chunks_exact(4)
            .filter(|pixel| pixel[3] == 255 && *pixel != background)
            .count();
        assert_eq!(
            color_count, colored_area,
            "visible image area stage {index}"
        );
        for (x, y, expected) in samples {
            assert_eq!(
                &partial[(y * 112 + x) * 4..(y * 112 + x) * 4 + 4],
                &expected,
                "stage {index} at{x},{y}"
            );
        }
        for (x, y) in [
            (2, 10),
            (10, 2),
            (allocation as usize - 2, 10),
            (10, allocation as usize - 2),
        ] {
            assert_eq!(
                &partial[(y * 112 + x) * 4..(y * 112 + x) * 4 + 4],
                &background,
                "padding stage {index}"
            );
        }
    }
    bitmap.set(Arc::new(
        ImageData::new(20, 40, [180, 40, 200, 255].repeat(20 * 40)).unwrap(),
    ));
    fit.set(ObjectFit::Contain);
    ui.prepare_frame();
    let frame = ui.scene.borrow_mut().flush();
    assert_eq!(
        gpu.render(&ui.scene.borrow(), &frame.damage)
            .unwrap()
            .image_uploads,
        1
    );
    let partial = gpu.readback().unwrap();
    assert_eq!(
        partial
            .chunks_exact(4)
            .filter(|p| *p == [180, 40, 200, 255])
            .count(),
        3200
    );
    assert_eq!(
        &partial[(40 * 112 + 10) * 4..(40 * 112 + 10) * 4 + 4],
        &background
    );
    gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 112., 104.)])
        .unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    assert_eq!(gpu.debug_cache_stats().image_textures, 1);
}
