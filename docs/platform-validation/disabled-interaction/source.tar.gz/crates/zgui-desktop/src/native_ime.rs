//! Route composition only to the editor owning the current native IME session.
use winit::event::Ime;
use zgui::{
    input::InputEvent,
    scene::NodeId,
    widgets::{LayoutFeedbackError, Ui},
};

/// A reset must cross both native context notifications before accepting text.
/// Winit's X11 and Wayland backends emit these when IME is toggled; macOS
/// emits Disabled on cancellation and Enabled at the next marked-text session.
/// This filters events queued before the reset boundary, not a protocol epoch:
/// winit's Wayland notifications are local and its Done handling does not expose
/// a serial. A delayed server commit arriving after Enabled cannot be identified
/// here without backend support. Do not require preedit before the next commit:
/// input methods may legitimately commit without sending marked text first.
#[derive(Default)]
pub(crate) enum RestartBarrier {
    #[default]
    Open,
    AwaitDisabled,
    AwaitEnabled,
}
impl RestartBarrier {
    pub(crate) fn cancel_if_changed(
        &mut self,
        ui: &Ui,
        previous: Option<NodeId>,
        active: &mut bool,
    ) -> bool {
        if previous.is_some() && previous != composition_target(ui) {
            *active = false;
            *self = Self::AwaitDisabled;
            true
        } else {
            false
        }
    }

    pub(crate) fn accepts(&mut self, event: &Ime) -> bool {
        match self {
            Self::Open => true,
            Self::AwaitDisabled => {
                if matches!(event, Ime::Disabled) {
                    *self = Self::AwaitEnabled;
                }
                false
            }
            Self::AwaitEnabled => {
                if matches!(event, Ime::Enabled) {
                    *self = Self::Open;
                }
                false
            }
        }
    }
}

pub(crate) fn composition_target(ui: &Ui) -> Option<NodeId> {
    ui.focused_editor().and_then(|editor| {
        editor
            .editor
            .borrow()
            .preedit()
            .is_some()
            .then_some(editor.node)
    })
}

/// Returns a new composing state only when an event belonged to this session.
/// Native focus loss keeps logical focus for restoration, so checking the
/// focused editor alone would admit late input from a deactivated native window.
pub(crate) fn dispatch(
    ui: &mut Ui,
    native_focused: bool,
    session_target: Option<NodeId>,
    event: Ime,
) -> Result<Option<bool>, LayoutFeedbackError> {
    if !native_focused
        || session_target.is_none()
        || session_target != ui.focused_editor().map(|editor| editor.node)
    {
        return Ok(None);
    }
    let event = match event {
        Ime::Enabled => return Ok(None),
        Ime::Disabled => InputEvent::ImePreedit {
            text: String::new(),
            cursor: None,
        },
        Ime::Preedit(text, cursor) => InputEvent::ImePreedit { text, cursor },
        Ime::Commit(text) => InputEvent::ImeCommit(text),
    };
    let result = ui.try_dispatch(event)?;
    // Custom handlers may reject or replace preedit. Keyboard suppression must
    // follow the editor's actual state, not the text of the incoming event.
    Ok(Some(
        !result.focus_changed && composition_target(ui) == session_target,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::focus_memory::FocusMemory;

    #[test]
    fn accessible_selection_restarts_composition_and_rejects_old_native_text() {
        let mut ui = Ui::new(400., 200.);
        let value = ui.signal(String::from("Ada"));
        let editor = ui.text_input(ui.root(), "Name", value.clone(), 200., false);
        ui.input.focus(&ui.scene, Some(editor.node));
        let mut active = dispatch(
            &mut ui,
            true,
            Some(editor.node),
            Ime::Preedit("旧".into(), None),
        )
        .unwrap()
        .unwrap();
        let mut barrier = RestartBarrier::default();
        let before = composition_target(&ui);
        assert!(ui.set_accessible_text_selection(editor.node, 0, 3));
        assert!(barrier.cancel_if_changed(&ui, before, &mut active));
        assert!(!active, "plain keyboard input must no longer be suppressed");
        for event in [
            Ime::Enabled,
            Ime::Commit("旧".into()),
            Ime::Preedit("旧".into(), None),
        ] {
            assert!(!barrier.accepts(&event));
        }
        assert!(!barrier.accepts(&Ime::Disabled));
        assert!(!barrier.accepts(&Ime::Commit("旧".into())));
        assert!(!barrier.accepts(&Ime::Enabled));
        let fresh = Ime::Preedit("新".into(), None);
        assert!(barrier.accepts(&fresh));
        assert_eq!(
            dispatch(&mut ui, true, Some(editor.node), fresh).unwrap(),
            Some(true)
        );
        // macOS may send an empty preedit immediately before a legitimate commit.
        let empty = Ime::Preedit(String::new(), None);
        assert!(barrier.accepts(&empty));
        assert_eq!(
            dispatch(&mut ui, true, Some(editor.node), empty).unwrap(),
            Some(false)
        );
        let commit = Ime::Commit("新".into());
        assert!(barrier.accepts(&commit));
        assert_eq!(
            dispatch(&mut ui, true, Some(editor.node), commit).unwrap(),
            Some(false)
        );
        assert_eq!(value.get(), "新");
    }

    #[test]
    fn accessible_value_cancellation_uses_same_reset_policy() {
        let mut ui = Ui::new(400., 200.);
        let value = ui.signal(String::from("Ada"));
        let editor = ui.text_input(ui.root(), "Name", value.clone(), 200., false);
        ui.input.focus(&ui.scene, Some(editor.node));
        dispatch(
            &mut ui,
            true,
            Some(editor.node),
            Ime::Preedit("旧".into(), None),
        )
        .unwrap();
        let before = composition_target(&ui);
        assert!(ui.set_accessible_value(editor.node, "Grace"));
        let mut barrier = RestartBarrier::default();
        let mut active = true;
        assert!(barrier.cancel_if_changed(&ui, before, &mut active));
        assert!(!active);
        assert_eq!(value.get(), "Grace");
        assert!(!barrier.accepts(&Ime::Commit("旧".into())));
        // An ordinary selection outside composition must not require a restart.
        let mut barrier = RestartBarrier::default();
        let before = composition_target(&ui);
        ui.set_accessible_text_selection(editor.node, 0, 5);
        assert!(!barrier.cancel_if_changed(&ui, before, &mut active));
        assert!(barrier.accepts(&Ime::Commit("new".into())));
    }

    #[test]
    fn prevented_accessible_selection_does_not_restart_composition() {
        let mut ui = Ui::new(400., 200.);
        let value = ui.signal(String::from("Ada"));
        let editor = ui.text_input(ui.root(), "Name", value, 200., false);
        ui.input.focus(&ui.scene, Some(editor.node));
        dispatch(
            &mut ui,
            true,
            Some(editor.node),
            Ime::Preedit("中".into(), None),
        )
        .unwrap();
        let _listener = ui.input.listen_first(editor.node, |cx| {
            if matches!(cx.event, InputEvent::SetTextSelection { .. }) {
                cx.prevent_default();
            }
        });
        let before = composition_target(&ui);
        // This bool alone cannot distinguish the editor from a cancelling listener.
        assert!(ui.set_accessible_text_selection(editor.node, 0, 3));
        let mut barrier = RestartBarrier::default();
        let mut active = true;
        assert!(!barrier.cancel_if_changed(&ui, before, &mut active));
        assert!(active);
        assert!(barrier.accepts(&Ime::Commit("中".into())));
        assert!(editor.editor.borrow().preedit().is_some());
    }

    #[test]
    fn prevented_preedit_tracks_actual_editor_state() {
        let mut ui = Ui::new(400., 200.);
        let value = ui.signal(String::new());
        let editor = ui.text_input(ui.root(), "Name", value, 200., false);
        ui.input.focus(&ui.scene, Some(editor.node));
        let listener = ui.input.listen_first(editor.node, |cx| {
            if matches!(cx.event, InputEvent::ImePreedit { .. }) {
                cx.prevent_default();
            }
        });
        assert_eq!(
            dispatch(
                &mut ui,
                true,
                Some(editor.node),
                Ime::Preedit("中".into(), None)
            )
            .unwrap(),
            Some(false)
        );
        drop(listener);
        assert_eq!(
            dispatch(
                &mut ui,
                true,
                Some(editor.node),
                Ime::Preedit("中".into(), None)
            )
            .unwrap(),
            Some(true)
        );
        let _listener = ui.input.listen_first(editor.node, |cx| {
            if matches!(cx.event, InputEvent::ImePreedit { .. }) {
                cx.prevent_default();
            }
        });
        assert_eq!(
            dispatch(
                &mut ui,
                true,
                Some(editor.node),
                Ime::Preedit(String::new(), None)
            )
            .unwrap(),
            Some(true)
        );
    }

    #[test]
    fn late_composition_after_native_blur_cannot_edit_remembered_focus() {
        let mut ui = Ui::new(400., 200.);
        let value = ui.signal(String::new());
        let editor = ui.text_input(ui.root(), "First", value.clone(), 200., false);
        ui.input.focus(&ui.scene, Some(editor.node));
        assert_eq!(
            dispatch(
                &mut ui,
                true,
                Some(editor.node),
                Ime::Preedit("中".into(), Some((3, 3)))
            )
            .unwrap(),
            Some(true)
        );
        assert!(editor.editor.borrow().preedit().is_some());
        let mut focus = FocusMemory::default();
        focus.deactivate(&ui);
        assert_eq!(ui.input.focused(), Some(editor.node));
        assert!(editor.editor.borrow().preedit().is_none());
        for event in [
            Ime::Preedit("文".into(), Some((3, 3))),
            Ime::Commit("文".into()),
        ] {
            assert_eq!(
                dispatch(&mut ui, false, Some(editor.node), event).unwrap(),
                None
            );
        }
        assert_eq!(value.get(), "");
        assert!(editor.editor.borrow().preedit().is_none());
        focus.activate(&ui);
        dispatch(&mut ui, true, Some(editor.node), Ime::Commit("新".into())).unwrap();
        assert_eq!(value.get(), "新");
    }

    #[test]
    fn stale_session_cannot_deliver_to_a_different_or_removed_editor() {
        let mut ui = Ui::new(400., 200.);
        let first_value = ui.signal(String::new());
        let second_value = ui.signal(String::new());
        let first = ui.text_input(ui.root(), "First", first_value.clone(), 200., false);
        let second = ui.text_input(ui.root(), "Second", second_value.clone(), 200., false);
        ui.input.focus(&ui.scene, Some(first.node));
        dispatch(
            &mut ui,
            true,
            Some(first.node),
            Ime::Preedit("中".into(), None),
        )
        .unwrap();
        ui.input.focus(&ui.scene, Some(second.node));
        for event in [
            Ime::Preedit("旧".into(), None),
            Ime::Commit("旧".into()),
            Ime::Disabled,
        ] {
            assert_eq!(
                dispatch(&mut ui, true, Some(first.node), event).unwrap(),
                None
            );
        }
        assert_eq!(first_value.get(), "");
        assert_eq!(second_value.get(), "");
        assert!(second.editor.borrow().preedit().is_none());
        dispatch(&mut ui, true, Some(second.node), Ime::Commit("新".into())).unwrap();
        assert_eq!(second_value.get(), "新");
        ui.remove(second.node);
        assert_eq!(
            dispatch(&mut ui, true, Some(second.node), Ime::Commit("旧".into())).unwrap(),
            None
        );
        assert_eq!(second_value.get(), "新");
    }
}
