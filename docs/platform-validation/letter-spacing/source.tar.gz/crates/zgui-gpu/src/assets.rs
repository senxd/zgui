//! Bounded image decoding and SVG rasterization, independent of a GPU device.
use crate::GpuError;
use std::{io::Cursor, sync::Arc};
use zgui::image::ImageData;
const MAX_BYTES: usize = 64 * 1024 * 1024;
/// Decode PNG/JPEG into immutable, straight-alpha RGBA8. No filesystem/network access.
pub fn decode_image(bytes: &[u8]) -> Result<Arc<ImageData>, GpuError> {
    if bytes.len() > MAX_BYTES {
        return Err(GpuError("encoded image exceeds 64 MiB".into()));
    }
    let mut reader = image::ImageReader::new(Cursor::new(bytes))
        .with_guessed_format()
        .map_err(|e| GpuError(e.to_string()))?;
    let mut limits = image::Limits::default();
    limits.max_image_width = Some(8192);
    limits.max_image_height = Some(8192);
    limits.max_alloc = Some(MAX_BYTES as u64);
    reader.limits(limits);
    let decoded = reader
        .decode()
        .map_err(|e| GpuError(e.to_string()))?
        .into_rgba8();
    if decoded.as_raw().len() > MAX_BYTES {
        return Err(GpuError("decoded image exceeds 64 MiB".into()));
    }
    ImageData::new(decoded.width(), decoded.height(), decoded.into_raw())
        .map(Arc::new)
        .map_err(|e| GpuError(e.into()))
}
/// Rasterize an SVG at the requested physical size. External resources are disabled.
/// SVG text needs conversion to outlines; the lightweight SVG dependency disables fonts.
pub fn decode_svg(bytes: &[u8], width: u32, height: u32) -> Result<Arc<ImageData>, GpuError> {
    if bytes.len() > 4 * 1024 * 1024
        || width == 0
        || height == 0
        || u64::from(width) * u64::from(height) * 4 > MAX_BYTES as u64
    {
        return Err(GpuError("SVG input or output exceeds bounds".into()));
    }
    let mut options = resvg::usvg::Options::default();
    options.image_href_resolver.resolve_string = Box::new(|_, _| None);
    let tree =
        resvg::usvg::Tree::from_data(bytes, &options).map_err(|e| GpuError(e.to_string()))?;
    let mut pixmap = resvg::tiny_skia::Pixmap::new(width, height)
        .ok_or_else(|| GpuError("SVG image allocation failed".into()))?;
    let transform = resvg::tiny_skia::Transform::from_scale(
        width as f32 / tree.size().width(),
        height as f32 / tree.size().height(),
    );
    resvg::render(&tree, transform, &mut pixmap.as_mut());
    let mut pixels = pixmap.take();
    for p in pixels.chunks_exact_mut(4) {
        let alpha = p[3] as u32;
        if alpha > 0 {
            for c in &mut p[..3] {
                *c = (u32::from(*c) * 255 + alpha / 2)
                    .checked_div(alpha)
                    .unwrap_or(0)
                    .min(255) as u8;
            }
        }
    }
    ImageData::new(width, height, pixels)
        .map(Arc::new)
        .map_err(|e| GpuError(e.into()))
}
