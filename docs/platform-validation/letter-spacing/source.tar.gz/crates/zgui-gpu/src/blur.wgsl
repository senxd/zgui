struct Params { direction:vec4<f32>, bounds:vec4<f32>, effect:vec4<f32> }
@group(0) @binding(0) var source:texture_2d<f32>;
@group(0) @binding(1) var original:texture_2d<f32>;
@group(0) @binding(2) var<uniform> params:Params;
@vertex fn vs(@builtin(vertex_index) i:u32)->@builtin(position) vec4<f32>{let p=array<vec2<f32>,3>(vec2(-1.,-1.),vec2(3.,-1.),vec2(-1.,3.));return vec4(p[i],0.,1.);}
@fragment fn fs(@builtin(position) p:vec4<f32>)->@location(0) vec4<f32>{
 let size=vec2<i32>(textureDimensions(source));let pixel=vec2<i32>(p.xy);let sigma=max(params.direction.z,0.1);let radius=i32(ceil(sigma*3.));var sum=vec4(0.);var weight=0.;
 for(var i=-radius;i<=radius;i++){let w=exp(-f32(i*i)/(2.*sigma*sigma));let coord=clamp(pixel+vec2<i32>(params.direction.xy)*i,vec2(0),size-vec2(1));sum+=textureLoad(source,coord,0)*w;weight+=w;}
 let blurred=sum/weight;if params.direction.w<0.5{return blurred;}
 var amount=params.effect.x;if params.effect.y>0.{let d=min(p.xy-params.bounds.xy,params.bounds.xy+params.bounds.zw-p.xy);amount*=clamp(min(d.x,d.y)/params.effect.y,0.,1.);}
 return mix(textureLoad(original,pixel,0),blurred,amount);
}
