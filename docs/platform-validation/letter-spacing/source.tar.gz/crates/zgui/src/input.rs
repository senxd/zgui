//! Retained event routing. Bindings disconnect when dropped; callbacks run without a scene borrow.
use crate::{
    reactive::{Runtime, Signal},
    scene::{NodeId, Scene},
};
use std::{
    cell::RefCell,
    collections::HashMap,
    rc::{Rc, Weak},
};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Modifiers {
    pub shift: bool,
    pub control: bool,
    pub alt: bool,
    pub meta: bool,
}
impl Modifiers {
    /// Command on macOS, Control on Linux and other desktop platforms.
    pub fn primary_shortcut(self) -> bool {
        if cfg!(target_os = "macos") {
            self.meta
        } else {
            self.control
        }
    }
    /// Option moves by words on macOS; Control does so on Linux.
    pub fn word_navigation(self) -> bool {
        if cfg!(target_os = "macos") {
            self.alt
        } else {
            self.control
        }
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Key {
    Tab,
    Enter,
    Space,
    Escape,
    Backspace,
    Delete,
    ArrowLeft,
    ArrowRight,
    ArrowUp,
    ArrowDown,
    Home,
    End,
    PageUp,
    PageDown,
    Character(String),
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PointerButton {
    Primary,
    Secondary,
    Middle,
    Other(u16),
}
#[derive(Clone, Debug, PartialEq)]
pub enum InputEvent {
    PointerDown {
        x: f32,
        y: f32,
        button: PointerButton,
    },
    PointerUp {
        x: f32,
        y: f32,
        button: PointerButton,
    },
    PointerMove {
        x: f32,
        y: f32,
    },
    PointerLeave,
    PointerCancel,
    PointerEnter,
    Scroll {
        x: f32,
        y: f32,
        delta_x: f32,
        delta_y: f32,
    },
    KeyDown {
        key: Key,
        modifiers: Modifiers,
        repeat: bool,
    },
    KeyUp {
        key: Key,
        modifiers: Modifiers,
    },
    Text(String),
    ImePreedit {
        text: String,
        cursor: Option<(usize, usize)>,
    },
    ImeCommit(String),
    Focus,
    FocusScopeClosed,
    Blur,
    Activate,
    SetValue(String),
    SetNumericValue(f64),
    Increment,
    Decrement,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EventPhase {
    Capture,
    Target,
    Bubble,
}
pub struct EventContext {
    pub event: InputEvent,
    pub target: NodeId,
    pub current_target: NodeId,
    pub phase: EventPhase,
    stopped: bool,
    immediate: bool,
    prevented: bool,
    focus: Option<NodeId>,
    capture: Option<Option<NodeId>>,
}
impl EventContext {
    pub fn stop_propagation(&mut self) {
        self.stopped = true;
    }
    /// Stop remaining listeners on this node as well as propagation to ancestors.
    pub fn stop_immediate_propagation(&mut self) {
        self.stopped = true;
        self.immediate = true;
    }
    pub fn prevent_default(&mut self) {
        self.prevented = true;
    }
    pub fn focus(&mut self) {
        self.focus = Some(self.current_target);
    }
    pub fn capture_pointer(&mut self) {
        self.capture = Some(Some(self.current_target));
    }
    pub fn release_pointer(&mut self) {
        self.capture = Some(None);
    }
    pub fn default_prevented(&self) -> bool {
        self.prevented
    }
}
#[derive(Clone, Copy, Debug, Default)]
pub struct NodeInput {
    pub focusable: bool,
    pub disabled: bool,
    pub tab_index: i32,
}
type Callback = Rc<RefCell<dyn FnMut(&mut EventContext)>>;
struct Entry {
    token: u64,
    callback: Callback,
}
struct FocusScope {
    root: NodeId,
    previous: Option<NodeId>,
}
#[derive(Default)]
struct State {
    entries: HashMap<NodeId, Vec<Entry>>,
    options: HashMap<NodeId, NodeInput>,
    disabled_observers: HashMap<NodeId, Signal<bool>>,
    next: u64,
    focused: Option<NodeId>,
    captured: Option<NodeId>,
    hovered: Option<NodeId>,
    pressed: Option<NodeId>,
    key_pressed: Option<(NodeId, Key)>,
    scopes: Vec<FocusScope>,
}
#[derive(Clone, Default)]
pub struct InputDispatcher {
    state: Rc<RefCell<State>>,
}
#[must_use = "Keep the binding alive while the node handles input"]
pub struct InputBinding {
    state: Weak<RefCell<State>>,
    node: NodeId,
    token: u64,
}
impl Drop for InputBinding {
    fn drop(&mut self) {
        if let Some(state) = self.state.upgrade() {
            let mut s = state.borrow_mut();
            let removed = s.entries.get_mut(&self.node).and_then(|listeners| {
                let index = listeners
                    .iter()
                    .position(|entry| entry.token == self.token)?;
                Some(listeners.remove(index))
            });
            let mut disabled_observer = None;
            if s.entries.get(&self.node).is_some_and(Vec::is_empty) {
                s.entries.remove(&self.node);
                s.options.remove(&self.node);
                disabled_observer = s.disabled_observers.get(&self.node).cloned();
                if s.focused == Some(self.node) {
                    s.focused = None;
                }
                if s.captured == Some(self.node) {
                    s.captured = None;
                }
                if s.hovered == Some(self.node) {
                    s.hovered = None;
                }
                if s.pressed == Some(self.node) {
                    s.pressed = None;
                }
                if s.key_pressed
                    .as_ref()
                    .is_some_and(|(id, _)| *id == self.node)
                {
                    s.key_pressed = None;
                }
            }
            // Callback captures may own bindings or other resources whose destructors
            // reenter this dispatcher. Finish detaching before running user Drop code.
            drop(s);
            if let Some(observer) = disabled_observer {
                observer.set(false);
            }
            drop(removed);
        }
    }
}
#[derive(Clone, Copy, Debug, Default)]
pub struct DispatchResult {
    pub target: Option<NodeId>,
    pub default_prevented: bool,
    pub focus_changed: bool,
}
impl InputDispatcher {
    pub fn new() -> Self {
        Self::default()
    }
    /// Replace this node's registrations. Use `listen` to extend existing behavior.
    pub fn register(
        &self,
        node: NodeId,
        options: NodeInput,
        callback: impl FnMut(&mut EventContext) + 'static,
    ) -> InputBinding {
        let mut s = self.state.borrow_mut();
        s.next = s.next.checked_add(1).expect("input binding IDs exhausted");
        let token = s.next;
        s.options.insert(node, options);
        let disabled_observer = s.disabled_observers.get(&node).cloned();
        let replaced = s.entries.insert(
            node,
            vec![Entry {
                token,
                callback: Rc::new(RefCell::new(callback)),
            }],
        );
        drop(s);
        if let Some(observer) = disabled_observer {
            observer.set(options.disabled);
        }
        drop(replaced);
        InputBinding {
            state: Rc::downgrade(&self.state),
            node,
            token,
        }
    }
    /// Append a listener without replacing existing widget behavior or node options.
    /// Listeners run in registration order within each capture/target/bubble phase.
    pub fn listen(
        &self,
        node: NodeId,
        callback: impl FnMut(&mut EventContext) + 'static,
    ) -> InputBinding {
        self.listen_ordered(node, callback, false)
    }
    /// Prepend a listener while preserving existing registrations and node options.
    /// It runs before existing listeners in each phase; repeated calls run newest
    /// first. Like `listen`, a listener added during dispatch starts next event.
    pub fn listen_first(
        &self,
        node: NodeId,
        callback: impl FnMut(&mut EventContext) + 'static,
    ) -> InputBinding {
        self.listen_ordered(node, callback, true)
    }
    fn listen_ordered(
        &self,
        node: NodeId,
        callback: impl FnMut(&mut EventContext) + 'static,
        first: bool,
    ) -> InputBinding {
        let mut state = self.state.borrow_mut();
        state.next = state
            .next
            .checked_add(1)
            .expect("input binding IDs exhausted");
        let token = state.next;
        state.options.entry(node).or_default();
        let entry = Entry {
            token,
            callback: Rc::new(RefCell::new(callback)),
        };
        let entries = state.entries.entry(node).or_default();
        if first {
            entries.insert(0, entry);
        } else {
            entries.push(entry);
        }
        InputBinding {
            state: Rc::downgrade(&self.state),
            node,
            token,
        }
    }
    pub fn has_listeners(&self, node: NodeId) -> bool {
        self.state.borrow().entries.contains_key(&node)
    }
    /// Metadata may be attached to containers without registering an event callback.
    pub fn set_options(&self, node: NodeId, options: NodeInput) {
        let observer = {
            let mut state = self.state.borrow_mut();
            state.options.insert(node, options);
            state.disabled_observers.get(&node).cloned()
        };
        if let Some(observer) = observer {
            observer.set(options.disabled);
        }
    }
    /// Lazily observe this node's local disabled flag. Ancestor inheritance is
    /// composed by callers; equal writes do not notify and unregister detaches it.
    pub(crate) fn observe_disabled(&self, node: NodeId, runtime: &Runtime) -> Signal<bool> {
        let mut state = self.state.borrow_mut();
        let disabled = state
            .options
            .get(&node)
            .is_some_and(|options| options.disabled);
        state
            .disabled_observers
            .entry(node)
            .or_insert_with(|| runtime.signal(disabled))
            .clone()
    }
    pub fn options(&self, node: NodeId) -> Option<NodeInput> {
        self.state.borrow().options.get(&node).copied()
    }
    /// Disconnect a removed node, including metadata-only container state.
    pub fn unregister(&self, node: NodeId) {
        let mut s = self.state.borrow_mut();
        let removed = s.entries.remove(&node);
        let observer = s.disabled_observers.remove(&node);
        s.options.remove(&node);
        if s.focused == Some(node) {
            s.focused = None;
        }
        if s.captured == Some(node) {
            s.captured = None;
        }
        if s.hovered == Some(node) {
            s.hovered = None;
        }
        if s.pressed == Some(node) {
            s.pressed = None;
        }
        if s.key_pressed.as_ref().is_some_and(|(id, _)| *id == node) {
            s.key_pressed = None;
        }
        drop(s);
        drop(observer);
        drop(removed);
    }
    pub fn focused(&self) -> Option<NodeId> {
        self.state.borrow().focused
    }
    pub fn hovered(&self) -> Option<NodeId> {
        self.state.borrow().hovered
    }
    pub fn is_enabled(&self, scene: &Scene, node: NodeId) -> bool {
        self.enabled(scene, node)
    }
    pub fn captured(&self) -> Option<NodeId> {
        self.state.borrow().captured
    }
    /// The active modal root, if any. Focus and pointer routing stay inside it.
    pub fn focus_scope(&self) -> Option<NodeId> {
        self.state.borrow().scopes.last().map(|s| s.root)
    }
    /// Enter a nested modal scope and save the previous focus for restoration.
    pub fn push_focus_scope(&self, scene: &Rc<RefCell<Scene>>, root: NodeId) -> bool {
        // Opening a sibling modal may supersede the current scope. Check the
        // node's actual ancestry, without applying the active scope boundary.
        if !self.enabled_without_scope(&scene.borrow(), root)
            || self
                .state
                .borrow()
                .scopes
                .iter()
                .any(|scope| scope.root == root)
        {
            return false;
        }
        self.dispatch(scene, InputEvent::PointerCancel);
        if !self.enabled_without_scope(&scene.borrow(), root) {
            return false;
        }
        let previous = self.focused();
        self.state
            .borrow_mut()
            .scopes
            .push(FocusScope { root, previous });
        let next = self.next_focus(&scene.borrow(), false);
        self.focus(scene, next);
        scene.borrow().contains(root)
            && self
                .state
                .borrow()
                .scopes
                .iter()
                .any(|scope| scope.root == root)
    }
    /// Close the innermost scope and restore the previous mounted, enabled focus.
    pub fn pop_focus_scope(&self, scene: &Rc<RefCell<Scene>>) -> bool {
        let scope = self.state.borrow_mut().scopes.pop();
        let Some(scope) = scope else {
            return false;
        };
        self.dispatch(scene, InputEvent::PointerCancel);
        if scene.borrow().contains(scope.root) {
            self.route(scene, scope.root, InputEvent::FocusScopeClosed);
        }
        let previous = scope
            .previous
            .filter(|id| self.enabled(&scene.borrow(), *id));
        let next = previous.or_else(|| self.next_focus(&scene.borrow(), false));
        self.focus(scene, next);
        true
    }
    /// Remove a modal scope and nested scopes, including one below an active
    /// sibling. Preserves the top sibling's focus and repairs restoration links.
    pub fn remove_focus_scope(&self, scene: &Rc<RefCell<Scene>>, root: NodeId) -> bool {
        let inside = |candidate: NodeId| {
            let scene = scene.borrow();
            candidate == root
                || (scene.contains(candidate)
                    && scene.ancestors(candidate).any(|ancestor| ancestor == root))
        };
        let mut removed = false;
        loop {
            let index = self
                .state
                .borrow()
                .scopes
                .iter()
                .rposition(|scope| inside(scope.root));
            let Some(index) = index else {
                break;
            };
            removed = true;
            if index + 1 == self.state.borrow().scopes.len() {
                self.pop_focus_scope(scene);
                continue;
            }
            let scope = self.state.borrow_mut().scopes.remove(index);
            {
                let scene = scene.borrow();
                let mut state = self.state.borrow_mut();
                for next in &mut state.scopes[index..] {
                    if next.previous.is_some_and(|previous| {
                        previous == scope.root
                            || (scene.contains(previous)
                                && scene
                                    .ancestors(previous)
                                    .any(|ancestor| ancestor == scope.root))
                    }) {
                        next.previous = scope.previous;
                    }
                }
            }
            if scene.borrow().contains(scope.root) {
                self.route(scene, scope.root, InputEvent::FocusScopeClosed);
            }
        }
        removed
    }
    fn enabled_without_scope(&self, scene: &Scene, mut node: NodeId) -> bool {
        if !scene.contains(node) {
            return false;
        }
        let state = self.state.borrow();
        loop {
            if state
                .options
                .get(&node)
                .is_some_and(|options| options.disabled)
                || scene.effects(node).opacity <= 0.
            {
                return false;
            }
            match scene.parent(node) {
                Some(parent) => node = parent,
                None => return true,
            }
        }
    }
    fn enabled(&self, scene: &Scene, mut node: NodeId) -> bool {
        if !scene.contains(node) {
            return false;
        }
        let s = self.state.borrow();
        if let Some(scope) = s.scopes.last() {
            let mut ancestor = Some(node);
            let mut inside = false;
            while let Some(id) = ancestor {
                if id == scope.root {
                    inside = true;
                    break;
                }
                ancestor = scene.parent(id);
            }
            if !inside {
                return false;
            }
        }
        loop {
            if s.options.get(&node).is_some_and(|o| o.disabled) {
                return false;
            }
            match scene.parent(node) {
                Some(p) => node = p,
                None => return true,
            }
        }
    }
    pub fn focus(&self, scene: &Rc<RefCell<Scene>>, target: Option<NodeId>) -> bool {
        if target.is_some_and(|id| {
            !self.enabled(&scene.borrow(), id) || !self.options(id).is_some_and(|o| o.focusable)
        }) {
            return false;
        }
        let old = self.focused();
        if old == target {
            return false;
        }
        {
            let mut state = self.state.borrow_mut();
            state.focused = target;
            state.key_pressed = None;
        }
        if let Some(id) = old.filter(|id| scene.borrow().contains(*id)) {
            self.route(scene, id, InputEvent::Blur);
        }
        // Blur handlers may remove the destination or redirect focus.
        if let Some(id) =
            target.filter(|id| self.focused() == Some(*id) && self.enabled(&scene.borrow(), *id))
        {
            self.route(scene, id, InputEvent::Focus);
        }
        true
    }
    fn route(&self, scene: &Rc<RefCell<Scene>>, target: NodeId, event: InputEvent) -> EventContext {
        let mut path = vec![target];
        {
            let scene = scene.borrow();
            let mut id = target;
            while let Some(parent) = scene.parent(id) {
                if Some(id) == self.focus_scope() {
                    break;
                }
                path.push(parent);
                id = parent;
            }
        }
        let mut ctx = EventContext {
            event,
            target,
            current_target: target,
            phase: EventPhase::Target,
            stopped: false,
            immediate: false,
            prevented: false,
            focus: None,
            capture: None,
        };
        let phases = path
            .iter()
            .skip(1)
            .rev()
            .map(|id| (*id, EventPhase::Capture))
            .chain(std::iter::once((target, EventPhase::Target)))
            .chain(path.iter().skip(1).map(|id| (*id, EventPhase::Bubble)));
        // Snapshot the entire route before invoking user code: newly attached listeners
        // participate only in later events; detached listeners are skipped immediately.
        let routes: Vec<_> = {
            let state = self.state.borrow();
            phases
                .map(|(id, phase)| {
                    let callbacks: Vec<_> = state
                        .entries
                        .get(&id)
                        .into_iter()
                        .flatten()
                        .map(|e| (e.token, e.callback.clone()))
                        .collect();
                    (id, phase, callbacks)
                })
                .collect()
        };
        for (id, phase, callbacks) in routes {
            if !scene.borrow().contains(id) {
                continue;
            }
            let disabled = self.options(id).is_some_and(|o| o.disabled);
            if disabled
                && !matches!(
                    ctx.event,
                    InputEvent::Blur
                        | InputEvent::Focus
                        | InputEvent::PointerCancel
                        | InputEvent::FocusScopeClosed
                )
            {
                continue;
            }
            ctx.current_target = id;
            ctx.phase = phase;
            for (token, callback) in callbacks {
                let attached = self
                    .state
                    .borrow()
                    .entries
                    .get(&id)
                    .is_some_and(|entries| entries.iter().any(|entry| entry.token == token));
                if !attached || !scene.borrow().contains(id) {
                    continue;
                }
                // Reentrant delivery to the same callback is skipped, never panics.
                if let Ok(mut callback) = callback.try_borrow_mut() {
                    callback(&mut ctx);
                }
                if ctx.immediate {
                    break;
                }
            }
            if ctx.stopped {
                break;
            }
        }
        ctx
    }
    fn next_focus(&self, scene: &Scene, reverse: bool) -> Option<NodeId> {
        let mut stack = vec![scene.root()];
        let mut ordered = Vec::new();
        while let Some(id) = stack.pop() {
            let options = self.options(id);
            if let Some(o) = options.filter(|o| o.focusable && o.tab_index >= 0)
                && self.enabled(scene, id)
            {
                ordered.push((id, o.tab_index));
            }
            stack.extend(scene.children(id).iter().rev().copied());
        }
        ordered.sort_by_key(|(_, i)| if *i == 0 { i32::MAX } else { *i });
        if ordered.is_empty() {
            return None;
        }
        let index = ordered
            .iter()
            .position(|(id, _)| Some(*id) == self.focused());
        let next = match (index, reverse) {
            (Some(i), false) => (i + 1) % ordered.len(),
            (Some(i), true) => (i + ordered.len() - 1) % ordered.len(),
            (None, false) => 0,
            (None, true) => ordered.len() - 1,
        };
        Some(ordered[next].0)
    }
    pub fn dispatch_to(
        &self,
        scene: &Rc<RefCell<Scene>>,
        target: NodeId,
        event: InputEvent,
    ) -> DispatchResult {
        let old = self.focused();
        if !self.enabled(&scene.borrow(), target) {
            return DispatchResult::default();
        }
        let ctx = self.route(scene, target, event);
        if let Some(focus) = ctx.focus {
            self.focus(scene, Some(focus));
        }
        if let Some(capture) = ctx.capture {
            let capture = capture.filter(|id| self.enabled(&scene.borrow(), *id));
            self.state.borrow_mut().captured = capture;
        }
        DispatchResult {
            target: Some(target),
            default_prevented: ctx.prevented,
            focus_changed: old != self.focused(),
        }
    }
    fn hit_target(&self, scene: &Scene, x: f32, y: f32) -> Option<NodeId> {
        let mut fallback = None;
        for hit in scene.hit_test_all(x, y) {
            let mut node = Some(hit);
            while let Some(id) = node {
                if self.options(id).is_some_and(|options| options.disabled) {
                    return None;
                }
                if self.has_listeners(id) {
                    // A document-level capture listener must not make an empty overlay
                    // obscure interactive siblings below it.
                    if id == scene.root() {
                        fallback = Some(id);
                        break;
                    }
                    return self.enabled(scene, id).then_some(id);
                }
                node = scene.parent(id);
            }
        }
        fallback.filter(|id| self.enabled(scene, *id))
    }
    pub fn dispatch(&self, scene: &Rc<RefCell<Scene>>, event: InputEvent) -> DispatchResult {
        loop {
            let stale = self
                .focus_scope()
                .is_some_and(|id| !scene.borrow().contains(id));
            if !stale {
                break;
            }
            self.pop_focus_scope(scene);
        }
        if matches!(event, InputEvent::Blur) {
            let mut s = self.state.borrow_mut();
            s.captured = None;
            s.pressed = None;
            s.key_pressed = None;
        }
        let old_focus = self.focused();
        if old_focus.is_some_and(|id| !self.enabled(&scene.borrow(), id)) {
            self.focus(scene, None);
        }
        let capture = self
            .captured()
            .filter(|id| self.enabled(&scene.borrow(), *id));
        self.state.borrow_mut().captured = capture;
        let hit = match &event {
            InputEvent::PointerDown { x, y, .. }
            | InputEvent::PointerUp { x, y, .. }
            | InputEvent::PointerMove { x, y }
            | InputEvent::Scroll { x, y, .. } => self.hit_target(&scene.borrow(), *x, *y),
            _ => None,
        };
        if matches!(
            event,
            InputEvent::PointerMove { .. } | InputEvent::PointerLeave
        ) {
            let old = self.state.borrow().hovered;
            if old != hit {
                self.state.borrow_mut().hovered = hit;
                if let Some(id) = old.filter(|id| scene.borrow().contains(*id)) {
                    self.route(scene, id, InputEvent::PointerLeave);
                }
                if let Some(id) = hit {
                    self.route(scene, id, InputEvent::PointerEnter);
                }
            }
        }
        let target = match &event {
            InputEvent::PointerDown { .. }
            | InputEvent::PointerUp { .. }
            | InputEvent::PointerMove { .. } => capture.or(hit),
            InputEvent::Scroll { .. } => hit,
            InputEvent::PointerCancel => capture,
            InputEvent::PointerLeave => None,
            // Empty or disabled modal contents still need dismissal keys.
            InputEvent::KeyDown { .. } | InputEvent::KeyUp { .. } => {
                self.focused().or_else(|| self.focus_scope())
            }
            _ => self.focused(),
        };
        let mut prevented = false;
        if let Some(id) = target {
            let ctx = self.route(scene, id, event.clone());
            prevented = ctx.prevented;
            if let Some(capture) = ctx.capture {
                let capture = capture.filter(|id| self.enabled(&scene.borrow(), *id));
                self.state.borrow_mut().captured = capture;
            }
            if let Some(focus) = ctx.focus {
                self.focus(scene, Some(focus));
            }
        }
        if !prevented {
            match &event {
                InputEvent::PointerDown {
                    button: PointerButton::Primary,
                    ..
                } => {
                    self.state.borrow_mut().pressed = target;
                    let mut node = target.filter(|id| self.enabled(&scene.borrow(), *id));
                    let mut focus = None;
                    while let Some(id) = node {
                        if self.options(id).is_some_and(|o| o.focusable) {
                            focus = Some(id);
                            break;
                        }
                        node = scene.borrow().parent(id);
                    }
                    if target.is_some() || self.focus_scope().is_none() {
                        self.focus(scene, focus);
                    }
                }
                InputEvent::KeyDown {
                    key: Key::Tab,
                    modifiers,
                    ..
                } => {
                    let next = self.next_focus(&scene.borrow(), modifiers.shift);
                    self.focus(scene, next);
                    prevented = true;
                }
                InputEvent::PointerUp {
                    button: PointerButton::Primary,
                    ..
                } => {
                    let pressed = self.state.borrow_mut().pressed.take();
                    if let Some(id) =
                        pressed.filter(|id| Some(*id) == hit && self.enabled(&scene.borrow(), *id))
                    {
                        self.dispatch_to(scene, id, InputEvent::Activate);
                    }
                }
                InputEvent::KeyDown {
                    key: key @ (Key::Enter | Key::Space),
                    repeat: false,
                    ..
                } => {
                    let pressed = self.focused().map(|id| (id, key.clone()));
                    self.state.borrow_mut().key_pressed = pressed;
                }
                InputEvent::KeyUp { key, .. } => {
                    let pressed = self.state.borrow_mut().key_pressed.take();
                    if let Some((id, pressed_key)) = pressed
                        && key == &pressed_key
                        && Some(id) == self.focused()
                    {
                        self.dispatch_to(scene, id, InputEvent::Activate);
                    }
                }
                _ => {}
            }
        }
        if matches!(
            event,
            InputEvent::PointerUp { .. } | InputEvent::PointerCancel
        ) {
            let mut s = self.state.borrow_mut();
            s.captured = None;
            s.pressed = None;
        }
        if matches!(event, InputEvent::KeyUp { .. }) {
            self.state.borrow_mut().key_pressed = None;
        }
        DispatchResult {
            target,
            default_prevented: prevented,
            focus_changed: old_focus != self.focused(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scene::{Color, NodeKind, Style};
    fn setup() -> (Rc<RefCell<Scene>>, NodeId, NodeId) {
        let mut s = Scene::new(200.0, 200.0);
        let root = s.root();
        let a = s.append(
            root,
            NodeKind::Rect(Color(0, 0, 0, 255)),
            Style {
                width: Some(100.0),
                height: Some(40.0),
                ..Default::default()
            },
        );
        let b = s.append(
            root,
            NodeKind::Rect(Color(0, 0, 0, 255)),
            Style {
                width: Some(100.0),
                height: Some(40.0),
                ..Default::default()
            },
        );
        s.flush();
        (Rc::new(RefCell::new(s)), a, b)
    }
    #[test]
    fn prepended_listener_preserves_options_and_restores_default_on_drop() {
        let (scene, node, _) = setup();
        let input = InputDispatcher::new();
        let log = Rc::new(RefCell::new(Vec::new()));
        let default_log = log.clone();
        let _default = input.register(
            node,
            NodeInput {
                focusable: true,
                tab_index: 7,
                ..Default::default()
            },
            move |cx| {
                if matches!(cx.event, InputEvent::Activate) {
                    default_log
                        .borrow_mut()
                        .push(("default", cx.default_prevented()));
                }
            },
        );
        let user_log = log.clone();
        let first = input.listen_first(node, move |cx| {
            if matches!(cx.event, InputEvent::Activate) {
                user_log.borrow_mut().push(("user", cx.default_prevented()));
                cx.prevent_default();
            }
        });
        assert!(input.options(node).unwrap().focusable);
        assert_eq!(input.options(node).unwrap().tab_index, 7);
        input.dispatch_to(&scene, node, InputEvent::Activate);
        assert_eq!(&*log.borrow(), &[("user", false), ("default", true)]);
        drop(first);
        log.borrow_mut().clear();
        input.dispatch_to(&scene, node, InputEvent::Activate);
        assert_eq!(&*log.borrow(), &[("default", false)]);
    }
    fn down(x: f32, y: f32) -> InputEvent {
        InputEvent::PointerDown {
            x,
            y,
            button: PointerButton::Primary,
        }
    }
    fn up(x: f32, y: f32) -> InputEvent {
        InputEvent::PointerUp {
            x,
            y,
            button: PointerButton::Primary,
        }
    }
    #[test]
    fn removal_during_dispatch_does_not_leave_stale_focus() {
        let (scene, a, _) = setup();
        let d = InputDispatcher::new();
        let s = scene.clone();
        let _binding = d.register(
            a,
            NodeInput {
                focusable: true,
                ..Default::default()
            },
            move |event| {
                if matches!(event.event, InputEvent::PointerDown { .. }) {
                    s.borrow_mut().remove(a);
                }
            },
        );
        d.dispatch(&scene, down(10.0, 10.0));
        assert_eq!(d.focused(), None);
        d.dispatch(&scene, up(10.0, 10.0));
    }
    #[test]
    fn capture_target_bubble_and_raii() {
        let (scene, a, _) = setup();
        let d = InputDispatcher::new();
        let log = Rc::new(RefCell::new(Vec::new()));
        let l = log.clone();
        let root = scene.borrow().root();
        let _r = d.register(root, NodeInput::default(), move |c| {
            l.borrow_mut().push(c.phase)
        });
        let l = log.clone();
        let binding = d.register(a, NodeInput::default(), move |c| {
            l.borrow_mut().push(c.phase)
        });
        d.dispatch(&scene, down(10.0, 10.0));
        assert_eq!(
            *log.borrow(),
            vec![EventPhase::Capture, EventPhase::Target, EventPhase::Bubble]
        );
        drop(binding);
        log.borrow_mut().clear();
        d.dispatch(&scene, down(10.0, 10.0));
        assert_eq!(*log.borrow(), vec![EventPhase::Target]);
    }
    #[test]
    fn tab_focus_disabled_and_stale_nodes() {
        let (scene, a, b) = setup();
        let d = InputDispatcher::new();
        let opts = NodeInput {
            focusable: true,
            ..Default::default()
        };
        let _a = d.register(a, opts, |_| {});
        let _b = d.register(b, opts, |_| {});
        let tab = InputEvent::KeyDown {
            key: Key::Tab,
            modifiers: Modifiers::default(),
            repeat: false,
        };
        d.dispatch(&scene, tab.clone());
        assert_eq!(d.focused(), Some(a));
        d.dispatch(&scene, tab.clone());
        assert_eq!(d.focused(), Some(b));
        d.set_options(
            a,
            NodeInput {
                disabled: true,
                ..opts
            },
        );
        d.dispatch(&scene, tab.clone());
        assert_eq!(d.focused(), Some(b));
        scene.borrow_mut().remove(b);
        d.dispatch(&scene, tab);
        assert_eq!(d.focused(), None);
    }
    #[test]
    fn capture_tracks_drag_but_does_not_activate_outside() {
        let (scene, a, _) = setup();
        let d = InputDispatcher::new();
        let clicks = Rc::new(RefCell::new(0));
        let c = clicks.clone();
        let _a = d.register(a, NodeInput::default(), move |e| {
            if matches!(e.event, InputEvent::PointerDown { .. }) {
                e.capture_pointer();
            }
            if e.event == InputEvent::Activate {
                *c.borrow_mut() += 1;
            }
        });
        d.dispatch(&scene, up(10.0, 10.0));
        assert_eq!(*clicks.borrow(), 0);
        d.dispatch(&scene, down(10.0, 10.0));
        assert_eq!(d.captured(), Some(a));
        let result = d.dispatch(&scene, InputEvent::PointerMove { x: 190.0, y: 190.0 });
        assert_eq!(result.target, Some(a));
        d.dispatch(&scene, up(190.0, 190.0));
        assert_eq!(*clicks.borrow(), 0);
        assert_eq!(d.captured(), None);
        d.dispatch(&scene, down(10.0, 10.0));
        d.dispatch(&scene, up(10.0, 10.0));
        assert_eq!(*clicks.borrow(), 1);
    }
    #[test]
    fn callbacks_may_mutate_scene_and_keyboard_requires_press() {
        let (scene, a, _) = setup();
        let d = InputDispatcher::new();
        let hits = Rc::new(RefCell::new(0));
        let h = hits.clone();
        let s = scene.clone();
        let _a = d.register(
            a,
            NodeInput {
                focusable: true,
                ..Default::default()
            },
            move |e| {
                if e.event == InputEvent::Activate {
                    *h.borrow_mut() += 1;
                    s.borrow_mut()
                        .set_kind(a, NodeKind::Rect(Color(255, 0, 0, 255)));
                }
            },
        );
        d.focus(&scene, Some(a));
        let release = InputEvent::KeyUp {
            key: Key::Enter,
            modifiers: Modifiers::default(),
        };
        d.dispatch(&scene, release.clone());
        assert_eq!(*hits.borrow(), 0);
        d.dispatch(
            &scene,
            InputEvent::KeyDown {
                key: Key::Enter,
                modifiers: Modifiers::default(),
                repeat: false,
            },
        );
        d.dispatch(&scene, release);
        assert_eq!(*hits.borrow(), 1);
    }
}

#[cfg(test)]
mod listener_tests {
    use super::*;
    use crate::scene::{Color, NodeKind, Style};
    fn scene() -> (Rc<RefCell<Scene>>, NodeId) {
        let mut s = Scene::new(100., 100.);
        let node = s.append(
            s.root(),
            NodeKind::Rect(Color(1, 2, 3, 255)),
            Style {
                width: Some(50.),
                height: Some(50.),
                ..Default::default()
            },
        );
        s.flush();
        (Rc::new(RefCell::new(s)), node)
    }
    #[test]
    fn additive_bindings_drop_only_their_own_callback() {
        let (scene, node) = scene();
        let d = InputDispatcher::new();
        let log = Rc::new(RefCell::new(Vec::new()));
        let l = log.clone();
        let primary = d.register(
            node,
            NodeInput {
                focusable: true,
                ..Default::default()
            },
            move |_| l.borrow_mut().push(1),
        );
        let l = log.clone();
        let extra = d.listen(node, move |_| l.borrow_mut().push(2));
        d.dispatch_to(&scene, node, InputEvent::Activate);
        assert_eq!(*log.borrow(), vec![1, 2]);
        drop(extra);
        log.borrow_mut().clear();
        d.dispatch_to(&scene, node, InputEvent::Activate);
        assert_eq!(*log.borrow(), vec![1]);
        assert!(d.options(node).unwrap().focusable);
        drop(primary);
        assert!(!d.has_listeners(node));
    }
    #[test]
    fn stopping_propagation_preserves_same_node_listeners_and_default_action() {
        let (scene, node) = scene();
        let root = scene.borrow().root();
        let d = InputDispatcher::new();
        let log = Rc::new(RefCell::new(Vec::new()));
        let l = log.clone();
        let _root = d.register(root, NodeInput::default(), move |e| {
            if matches!(e.event, InputEvent::PointerDown { .. }) {
                l.borrow_mut().push(e.phase);
            }
        });
        let l = log.clone();
        let _first = d.register(
            node,
            NodeInput {
                focusable: true,
                ..Default::default()
            },
            move |e| {
                if matches!(e.event, InputEvent::PointerDown { .. }) {
                    l.borrow_mut().push(e.phase);
                    e.stop_propagation();
                }
            },
        );
        let l = log.clone();
        let extra = d.listen(node, move |e| {
            if matches!(e.event, InputEvent::PointerDown { .. }) {
                l.borrow_mut().push(e.phase);
            }
        });
        let down = InputEvent::PointerDown {
            x: 10.,
            y: 10.,
            button: PointerButton::Primary,
        };
        let result = d.dispatch(&scene, down.clone());
        assert!(!result.default_prevented);
        assert_eq!(d.focused(), Some(node));
        assert_eq!(
            *log.borrow(),
            vec![EventPhase::Capture, EventPhase::Target, EventPhase::Target]
        );
        drop(extra);
        d.focus(&scene, None);
        let _prevent = d.listen(node, |e| e.prevent_default());
        let result = d.dispatch(&scene, down);
        assert!(result.default_prevented);
        assert_eq!(d.focused(), None);
    }
    #[test]
    fn listeners_added_during_capture_wait_until_next_event_and_removed_are_skipped() {
        let (scene, node) = scene();
        let root = scene.borrow().root();
        let d = InputDispatcher::new();
        let log = Rc::new(RefCell::new(Vec::new()));
        let keep = Rc::new(RefCell::new(Vec::new()));
        let remove = Rc::new(RefCell::new(None));
        let l = log.clone();
        *remove.borrow_mut() = Some(d.register(node, NodeInput::default(), move |_| {
            l.borrow_mut().push("removed")
        }));
        let bindings = keep.clone();
        let remove = remove.clone();
        let dispatch = d.clone();
        let l = log.clone();
        let mut added = false;
        let _root = d.register(root, NodeInput::default(), move |e| {
            if e.phase == EventPhase::Capture && !added {
                added = true;
                remove.borrow_mut().take();
                let l = l.clone();
                bindings
                    .borrow_mut()
                    .push(dispatch.listen(node, move |_| l.borrow_mut().push("new")));
            }
        });
        d.dispatch_to(&scene, node, InputEvent::Activate);
        assert!(log.borrow().is_empty());
        d.dispatch_to(&scene, node, InputEvent::Activate);
        assert_eq!(*log.borrow(), vec!["new"]);
    }
    #[test]
    fn immediate_stop_skips_later_listeners_but_registration_replacement_is_safe() {
        let (scene, node) = scene();
        let d = InputDispatcher::new();
        let old = d.register(node, NodeInput::default(), |_| panic!("replaced callback"));
        let current = d.register(node, NodeInput::default(), |e| {
            e.stop_immediate_propagation()
        });
        drop(old);
        let _extra = d.listen(node, |_| panic!("immediately stopped callback"));
        d.dispatch_to(&scene, node, InputEvent::Activate);
        drop(current);
    }
}

#[cfg(test)]
mod reentrant_drop_tests {
    use super::*;
    use crate::scene::Scene;
    use std::cell::Cell;

    struct OnDrop(Option<Box<dyn FnOnce()>>);
    impl Drop for OnDrop {
        fn drop(&mut self) {
            self.0.take().unwrap()();
        }
    }

    #[test]
    fn callback_capture_drop_can_reenter_after_unregister_binding_drop_or_replace() {
        for action in 0..3 {
            let scene = Scene::new(100., 100.);
            let node = scene.root();
            let dispatcher = InputDispatcher::new();
            let reentrant = dispatcher.clone();
            let calls = Rc::new(Cell::new(0));
            let called = calls.clone();
            let resource = OnDrop(Some(Box::new(move || {
                // Replacement must already be visible; removal must already finish.
                assert_eq!(reentrant.has_listeners(node), action == 2);
                reentrant.unregister(node);
                reentrant.set_options(
                    node,
                    NodeInput {
                        disabled: true,
                        ..Default::default()
                    },
                );
                called.set(called.get() + 1);
            })));
            let binding = dispatcher.register(node, NodeInput::default(), move |_| {
                let _ = &resource;
            });
            match action {
                0 => {
                    dispatcher.unregister(node);
                    drop(binding);
                }
                1 => drop(binding),
                _ => {
                    let replacement = dispatcher.register(node, NodeInput::default(), |_| {});
                    drop(binding);
                    drop(replacement);
                }
            }
            assert_eq!(calls.get(), 1);
            assert!(!dispatcher.has_listeners(node));
            assert!(dispatcher.options(node).unwrap().disabled);
        }
    }

    #[test]
    fn dropping_listener_capture_can_drop_another_binding() {
        let scene = Scene::new(100., 100.);
        let node = scene.root();
        let dispatcher = InputDispatcher::new();
        let nested = dispatcher.listen(node, |_| {});
        let outer = dispatcher.listen(node, move |_| {
            let _ = &nested;
        });
        drop(outer);
        assert!(!dispatcher.has_listeners(node));
        assert!(dispatcher.options(node).is_none());
    }
}

#[cfg(test)]
mod disabled_observer_tests {
    use super::*;
    use std::cell::Cell;

    #[test]
    fn disabled_observer_tracks_registration_metadata_and_detaches_on_removal() {
        let runtime = Runtime::new();
        let scene = Scene::new(100., 100.);
        let node = scene.root();
        let input = InputDispatcher::new();
        let disabled = input.observe_disabled(node, &runtime);
        let reads = Rc::new(Cell::new(0));
        let count = reads.clone();
        let read_disabled = disabled.clone();
        let _effect = runtime.effect(move || {
            read_disabled.get();
            count.set(count.get() + 1);
        });
        let binding = input.register(
            node,
            NodeInput {
                disabled: true,
                ..Default::default()
            },
            |_| {},
        );
        assert!(disabled.get());
        assert_eq!(reads.get(), 2);
        input.set_options(
            node,
            NodeInput {
                disabled: true,
                focusable: true,
                ..Default::default()
            },
        );
        assert_eq!(
            reads.get(),
            2,
            "unrelated/equal option updates do not notify"
        );
        drop(binding);
        assert!(!disabled.get());
        assert_eq!(reads.get(), 3);
        input.set_options(
            node,
            NodeInput {
                disabled: true,
                ..Default::default()
            },
        );
        assert!(disabled.get());
        input.unregister(node);
        assert!(!input.state.borrow().disabled_observers.contains_key(&node));
        let before = reads.get();
        input.set_options(node, NodeInput::default());
        assert_eq!(
            reads.get(),
            before,
            "removed observer cannot track reused metadata"
        );
        assert!(!input.observe_disabled(node, &runtime).get());
    }

    #[test]
    fn disabled_observer_callbacks_can_reenter_metadata_and_unregister() {
        let runtime = Runtime::new();
        let scene = Scene::new(100., 100.);
        let node = scene.root();
        let input = InputDispatcher::new();
        let disabled = input.observe_disabled(node, &runtime);
        let callback_input = input.clone();
        let _effect = runtime.effect(move || {
            if disabled.get() {
                assert!(callback_input.options(node).unwrap().disabled);
                callback_input.set_options(node, NodeInput::default());
                callback_input.unregister(node);
            }
        });
        let _binding = input.register(
            node,
            NodeInput {
                disabled: true,
                ..Default::default()
            },
            |_| {},
        );
        assert!(!input.has_listeners(node));
        assert!(input.options(node).is_none());
        assert!(input.state.borrow().disabled_observers.is_empty());
    }
}
