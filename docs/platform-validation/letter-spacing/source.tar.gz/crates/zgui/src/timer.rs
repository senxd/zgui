//! Shared deadline scheduler. Sleeping tasks do not poll or allocate a thread per timer.
use std::{
    collections::BTreeMap,
    future::Future,
    pin::Pin,
    sync::{
        Arc, Condvar, Mutex, OnceLock,
        atomic::{AtomicU64, Ordering},
    },
    task::{Context, Poll, Waker},
    time::{Duration, Instant},
};
struct Driver {
    waiters: Mutex<BTreeMap<(Instant, u64), Waker>>,
    changed: Condvar,
    next: AtomicU64,
}
fn driver() -> &'static Arc<Driver> {
    static DRIVER: OnceLock<Arc<Driver>> = OnceLock::new();
    DRIVER.get_or_init(|| {
        let driver = Arc::new(Driver {
            waiters: Mutex::new(BTreeMap::new()),
            changed: Condvar::new(),
            next: AtomicU64::new(1),
        });
        let shared = driver.clone();
        std::thread::Builder::new()
            .name("zgui-timers".into())
            .stack_size(128 * 1024)
            .spawn(move || {
                loop {
                    let mut waiters = shared.waiters.lock().unwrap();
                    loop {
                        let Some((&(deadline, _), _)) = waiters.first_key_value() else {
                            waiters = shared.changed.wait(waiters).unwrap();
                            continue;
                        };
                        let now = Instant::now();
                        if deadline > now {
                            waiters = shared
                                .changed
                                .wait_timeout(waiters, deadline - now)
                                .unwrap()
                                .0;
                            continue;
                        }
                        let mut ready = Vec::new();
                        while waiters
                            .first_key_value()
                            .is_some_and(|((deadline, _), _)| *deadline <= now)
                        {
                            ready.push(waiters.pop_first().unwrap().1);
                        }
                        drop(waiters);
                        for waker in ready {
                            waker.wake();
                        }
                        break;
                    }
                }
            })
            .expect("create timer scheduler");
        driver
    })
}
#[must_use = "Futures do nothing unless awaited or polled"]
pub struct Sleep {
    deadline: Instant,
    registration: Option<(Arc<Driver>, u64)>,
}
pub fn sleep(duration: Duration) -> Sleep {
    sleep_until(Instant::now() + duration)
}
pub fn sleep_until(deadline: Instant) -> Sleep {
    Sleep {
        deadline,
        registration: None,
    }
}
impl Future for Sleep {
    type Output = ();
    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<()> {
        if Instant::now() >= self.deadline {
            if let Some((d, id)) = self.registration.take() {
                d.waiters.lock().unwrap().remove(&(self.deadline, id));
            }
            return Poll::Ready(());
        }
        if self.registration.is_none() {
            let d = driver().clone();
            let id = d.next.fetch_add(1, Ordering::Relaxed);
            self.registration = Some((d, id));
        }
        let (d, id) = self.registration.as_ref().unwrap();
        let mut waiters = d.waiters.lock().unwrap();
        match waiters.get_mut(&(self.deadline, *id)) {
            Some(w) if w.will_wake(cx.waker()) => {}
            Some(w) => *w = cx.waker().clone(),
            None => {
                waiters.insert((self.deadline, *id), cx.waker().clone());
            }
        }
        d.changed.notify_one();
        Poll::Pending
    }
}
impl Drop for Sleep {
    fn drop(&mut self) {
        if let Some((d, id)) = self.registration.take() {
            d.waiters.lock().unwrap().remove(&(self.deadline, id));
            d.changed.notify_one();
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::AtomicUsize;
    use std::task::Wake;
    struct Count(AtomicUsize);
    impl Wake for Count {
        fn wake(self: Arc<Self>) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }
    #[test]
    fn cancellation_unregisters_and_deadline_wakes_once() {
        let c = Arc::new(Count(AtomicUsize::new(0)));
        let w = Waker::from(c.clone());
        let mut cx = Context::from_waker(&w);
        let mut cancelled = sleep(Duration::from_secs(10));
        assert!(Pin::new(&mut cancelled).poll(&mut cx).is_pending());
        let (d, id) = cancelled.registration.as_ref().unwrap();
        let d = d.clone();
        let id = *id;
        let deadline = cancelled.deadline;
        drop(cancelled);
        assert!(!d.waiters.lock().unwrap().contains_key(&(deadline, id)));
        let mut future = sleep(Duration::from_millis(10));
        assert!(Pin::new(&mut future).poll(&mut cx).is_pending());
        let end = Instant::now() + Duration::from_secs(2);
        while c.0.load(Ordering::SeqCst) == 0 && Instant::now() < end {
            std::thread::sleep(Duration::from_millis(1));
        }
        assert_eq!(c.0.load(Ordering::SeqCst), 1);
        assert!(Pin::new(&mut future).poll(&mut cx).is_ready());
    }
}
