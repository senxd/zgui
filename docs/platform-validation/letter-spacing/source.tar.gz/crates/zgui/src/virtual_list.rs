//! Constant-space range calculation for fixed-height virtualized lists.
use std::ops::Range;

#[derive(Clone, Copy, Debug)]
pub struct VirtualList {
    pub count: usize,
    pub row_height: f32,
    pub overscan: usize,
}

impl VirtualList {
    pub fn new(count: usize, row_height: f32, overscan: usize) -> Self {
        assert!(row_height.is_finite() && row_height > 0.0);
        Self {
            count,
            row_height,
            overscan,
        }
    }
    pub fn content_height(&self) -> f32 {
        self.row_offset(self.count)
    }
    pub fn visible_range(&self, offset: f32, viewport_height: f32) -> Range<usize> {
        if self.count == 0
            || !self.row_height.is_finite()
            || self.row_height <= 0.0
            || !viewport_height.is_finite()
            || viewport_height <= 0.0
        {
            return 0..0;
        }
        let offset = if offset.is_finite() {
            offset
                .max(0.0)
                .min((self.content_height() - viewport_height).max(0.0))
        } else {
            0.0
        };
        // Widen before adding pixels: finite f32 inputs can overflow their sum
        // and otherwise turn a small viewport into a range of usize::MAX rows.
        let first =
            ((f64::from(offset) / f64::from(self.row_height)).floor() as usize).min(self.count);
        let end = ((f64::from(offset) + f64::from(viewport_height)) / f64::from(self.row_height))
            .ceil() as usize;
        first.saturating_sub(self.overscan)..end.saturating_add(self.overscan).min(self.count)
    }
    pub fn row_offset(&self, index: usize) -> f32 {
        if !self.row_height.is_finite() || self.row_height <= 0.0 {
            return 0.0;
        }
        (index as f64 * f64::from(self.row_height)).min(f64::from(f32::MAX)) as f32
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn million_rows_remain_bounded() {
        let list = VirtualList::new(1_000_000, 24.0, 3);
        for offset in [0.0, 5000.0, 24_000_000.0] {
            let range = list.visible_range(offset, 480.0);
            assert!(range.len() <= 27);
            assert!(range.end <= list.count);
        }
        assert_eq!(list.visible_range(0.0, 48.0), 0..5);
    }
    #[test]
    fn handles_empty_and_invalid_viewports() {
        assert_eq!(VirtualList::new(0, 20.0, 2).visible_range(0.0, 40.0), 0..0);
        assert_eq!(
            VirtualList::new(10, 20.0, 2).visible_range(0.0, f32::NAN),
            0..0
        );
    }
    #[test]
    fn extreme_finite_pixels_do_not_expand_range_to_every_row() {
        let list = VirtualList::new(usize::MAX, f32::MAX / 4.0, 1);
        assert_eq!(list.content_height(), f32::MAX);
        assert_eq!(list.row_offset(usize::MAX), f32::MAX);
        let range = list.visible_range(f32::MAX / 2.0, f32::MAX * 0.75);
        assert!(range.len() <= 6, "{range:?}");
    }

    #[test]
    fn count_and_overscan_arithmetic_saturate() {
        let list = VirtualList::new(usize::MAX, 1.0, usize::MAX);
        assert_eq!(list.visible_range(0.0, 1.0), 0..usize::MAX);
        let list = VirtualList::new(usize::MAX, 1.0, 0);
        let range = list.visible_range(f32::MAX, 1.0);
        assert!(range.start <= range.end);
        assert!(range.end <= list.count);
    }

    #[test]
    fn mutated_invalid_row_heights_are_empty_and_finite() {
        for height in [0.0, -1.0, f32::NAN, f32::INFINITY] {
            let mut list = VirtualList::new(100, 24.0, 2);
            list.row_height = height;
            assert_eq!(list.visible_range(0.0, 480.0), 0..0);
            assert_eq!(list.content_height(), 0.0);
            assert_eq!(list.row_offset(5), 0.0);
        }
    }
}
