//! Fluent, sparse styling for retained views.
//!
//! Dimensions, spacing, text sizes, blur and translations use logical pixels,
//! except explicit percentage dimension methods.
//! Style patches only replace explicitly supplied properties; chaining follows
//! last-write precedence, including individual padding and margin sides.
use crate::scene::{Align, BoxShadow, Color, Insets, Justify, Layout, Transform};

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Styles {
    pub(crate) layout: Option<Layout>,
    pub(crate) absolute: Option<bool>,
    pub(crate) width: Option<f32>,
    pub(crate) height: Option<f32>,
    pub(crate) width_percent: Option<f32>,
    pub(crate) height_percent: Option<f32>,
    pub(crate) min_width: Option<f32>,
    pub(crate) max_width: Option<f32>,
    pub(crate) min_height: Option<f32>,
    pub(crate) max_height: Option<f32>,
    pub(crate) padding: Option<Insets>,
    pub(crate) margin: Option<Insets>,
    pub(crate) gap: Option<f32>,
    pub(crate) clip: Option<bool>,
    pub(crate) flex_grow: Option<f32>,
    pub(crate) flex_shrink: Option<f32>,
    pub(crate) align: Option<Align>,
    pub(crate) justify: Option<Justify>,
    pub(crate) text_wrap: Option<bool>,
    pub(crate) background: Option<Color>,
    pub(crate) text_color: Option<Color>,
    pub(crate) text_size: Option<f32>,
    pub(crate) line_height: Option<crate::text_layout::LineHeight>,
    pub(crate) letter_spacing: Option<crate::text_layout::LetterSpacing>,
    pub(crate) font_family: Option<crate::text_layout::FontFamily>,
    pub(crate) font_weight: Option<u16>,
    pub(crate) italic: Option<bool>,
    pub(crate) radius: Option<f32>,
    pub(crate) border_width: Option<f32>,
    pub(crate) border_color: Option<Color>,
    pub(crate) shadow: Option<Option<BoxShadow>>,
    pub(crate) opacity: Option<f32>,
    pub(crate) blur: Option<f32>,
    pub(crate) edge_fade: Option<f32>,
    pub(crate) transform: Option<Transform>,
    pub(crate) isolated: Option<bool>,
    pub(crate) padding_sides: u8,
    pub(crate) margin_sides: u8,
}
impl Styles {
    pub fn new() -> Self {
        Self::default()
    }
    /// Overlay explicitly supplied properties, preserving all others.
    pub fn merge(&mut self, other: &Self) {
        if other.absolute.is_some() {
            self.absolute = other.absolute;
        }
        if other.layout.is_some() {
            self.layout = other.layout;
        }
        if other.width.is_some() || other.width_percent.is_some() {
            self.width = other.width;
            self.width_percent = other.width_percent;
        }
        if other.height.is_some() || other.height_percent.is_some() {
            self.height = other.height;
            self.height_percent = other.height_percent;
        }
        if other.min_width.is_some() {
            self.min_width = other.min_width;
        }
        if other.max_width.is_some() {
            self.max_width = other.max_width;
        }
        if other.min_height.is_some() {
            self.min_height = other.min_height;
        }
        if other.max_height.is_some() {
            self.max_height = other.max_height;
        }
        if other.gap.is_some() {
            self.gap = other.gap;
        }
        if other.clip.is_some() {
            self.clip = other.clip;
        }
        if other.flex_grow.is_some() {
            self.flex_grow = other.flex_grow;
        }
        if other.flex_shrink.is_some() {
            self.flex_shrink = other.flex_shrink;
        }
        if other.align.is_some() {
            self.align = other.align;
        }
        if other.justify.is_some() {
            self.justify = other.justify;
        }
        if other.text_wrap.is_some() {
            self.text_wrap = other.text_wrap;
        }
        if other.background.is_some() {
            self.background = other.background;
        }
        if other.text_color.is_some() {
            self.text_color = other.text_color;
        }
        if other.font_family.is_some() {
            self.font_family = other.font_family.clone();
        }
        if other.font_weight.is_some() {
            self.font_weight = other.font_weight;
        }
        if other.italic.is_some() {
            self.italic = other.italic;
        }
        if other.text_size.is_some() {
            self.text_size = other.text_size;
        }
        if other.line_height.is_some() {
            self.line_height = other.line_height;
        }
        if other.letter_spacing.is_some() {
            self.letter_spacing = other.letter_spacing;
        }
        if other.radius.is_some() {
            self.radius = other.radius;
        }
        if other.border_width.is_some() {
            self.border_width = other.border_width;
        }
        if other.border_color.is_some() {
            self.border_color = other.border_color;
        }
        if other.shadow.is_some() {
            self.shadow = other.shadow;
        }
        if other.opacity.is_some() {
            self.opacity = other.opacity;
        }
        if other.blur.is_some() {
            self.blur = other.blur;
        }
        if other.edge_fade.is_some() {
            self.edge_fade = other.edge_fade;
        }
        if other.transform.is_some() {
            self.transform = other.transform;
        }
        if other.isolated.is_some() {
            self.isolated = other.isolated;
        }
        if let Some(value) = other.padding {
            if self.padding.is_some() && self.padding_sides == 0 {
                self.padding_sides = 15;
            }
            let mask = if other.padding_sides == 0 {
                15
            } else {
                other.padding_sides
            };
            merge_insets(
                self.padding.get_or_insert_with(Insets::default),
                value,
                mask,
            );
            self.padding_sides |= mask;
        }
        if let Some(value) = other.margin {
            if self.margin.is_some() && self.margin_sides == 0 {
                self.margin_sides = 15;
            }
            let mask = if other.margin_sides == 0 {
                15
            } else {
                other.margin_sides
            };
            merge_insets(self.margin.get_or_insert_with(Insets::default), value, mask);
            self.margin_sides |= mask;
        }
    }
}
fn merge_insets(target: &mut Insets, source: Insets, mask: u8) {
    if mask & 1 != 0 {
        target.top = source.top;
    }
    if mask & 2 != 0 {
        target.right = source.right;
    }
    if mask & 4 != 0 {
        target.bottom = source.bottom;
    }
    if mask & 8 != 0 {
        target.left = source.left;
    }
}
/// Shared fluent styling API for views and reusable style patches.
pub trait Styled: Sized {
    fn styles_mut(&mut self) -> &mut Styles;
    /// Position at the parent content origin plus margins, outside normal flow.
    /// Absolute children do not contribute to parent intrinsic size or flex space.
    fn absolute(mut self) -> Self {
        self.styles_mut().absolute = Some(true);
        self
    }
    /// Restore normal row, column, or overlay layout participation.
    fn relative(mut self) -> Self {
        self.styles_mut().absolute = Some(false);
        self
    }
    /// Apply a reusable transformation while building a view or style patch.
    fn apply(self, transform: impl FnOnce(Self) -> Self) -> Self {
        transform(self)
    }
    /// Apply a transformation only when `condition` is true.
    ///
    /// This decision is made immediately, not reactively. Use a view's
    /// `reactive_style` method for styles that follow signal changes.
    fn when(self, condition: bool, transform: impl FnOnce(Self) -> Self) -> Self {
        if condition { transform(self) } else { self }
    }
    /// Apply a transformation with the contained value, if present.
    ///
    /// Like `when`, this runs while building the description, without creating
    /// a subscription. The closure is not called for `None`.
    fn when_some<T>(self, value: Option<T>, transform: impl FnOnce(Self, T) -> Self) -> Self {
        match value {
            Some(value) => transform(self, value),
            None => self,
        }
    }
    fn style(mut self, style: Styles) -> Self {
        self.styles_mut().merge(&style);
        self
    }
    fn w(mut self, value: f32) -> Self {
        self.styles_mut().width = Some(value);
        self.styles_mut().width_percent = None;
        self
    }
    fn h(mut self, value: f32) -> Self {
        self.styles_mut().height = Some(value);
        self.styles_mut().height_percent = None;
        self
    }
    /// Width as a percentage of the parent's definite content width; 100 fills it.
    /// Indefinite parent widths use intrinsic sizing. Flex allocation and min/max
    /// constraints still apply. Negative and non-finite values normalize to zero.
    fn w_percent(mut self, percent: f32) -> Self {
        self.styles_mut().width = None;
        self.styles_mut().width_percent = Some(if percent.is_finite() {
            percent.max(0.) / 100.
        } else {
            0.
        });
        self
    }
    /// Height as a percentage of the parent's definite content height.
    /// Uses the same normalization and intrinsic fallback as `w_percent`.
    fn h_percent(mut self, percent: f32) -> Self {
        self.styles_mut().height = None;
        self.styles_mut().height_percent = Some(if percent.is_finite() {
            percent.max(0.) / 100.
        } else {
            0.
        });
        self
    }
    /// Fill the parent's definite content width, subject to flex and min/max rules.
    fn w_full(self) -> Self {
        self.w_percent(100.)
    }
    /// Fill the parent's definite content height, subject to flex and min/max rules.
    fn h_full(self) -> Self {
        self.h_percent(100.)
    }
    fn min_w(mut self, value: f32) -> Self {
        self.styles_mut().min_width = Some(value);
        self
    }
    fn max_w(mut self, value: f32) -> Self {
        self.styles_mut().max_width = Some(value);
        self
    }
    fn min_h(mut self, value: f32) -> Self {
        self.styles_mut().min_height = Some(value);
        self
    }
    fn max_h(mut self, value: f32) -> Self {
        self.styles_mut().max_height = Some(value);
        self
    }
    fn gap(mut self, value: f32) -> Self {
        self.styles_mut().gap = Some(value);
        self
    }
    fn flex_grow(mut self, value: f32) -> Self {
        self.styles_mut().flex_grow = Some(value);
        self
    }
    fn flex_shrink(mut self, value: f32) -> Self {
        self.styles_mut().flex_shrink = Some(value);
        self
    }
    fn bg(mut self, value: Color) -> Self {
        self.styles_mut().background = Some(value);
        self
    }
    fn text_color(mut self, value: Color) -> Self {
        self.styles_mut().text_color = Some(value);
        self
    }
    fn font_family(mut self, family: impl Into<crate::text_layout::FontFamily>) -> Self {
        self.styles_mut().font_family = Some(family.into());
        self
    }
    fn font_weight(mut self, weight: u16) -> Self {
        self.styles_mut().font_weight = Some(weight.clamp(1, 1000));
        self
    }
    fn font_bold(self) -> Self {
        self.font_weight(700)
    }
    fn italic(mut self, italic: bool) -> Self {
        self.styles_mut().italic = Some(italic);
        self
    }
    fn text_size(mut self, value: f32) -> Self {
        self.styles_mut().text_size = Some(value);
        self
    }
    /// Set inherited line spacing in logical pixels. Invalid/non-positive values
    /// use normal spacing; positive values smaller than the font size are allowed.
    fn line_height(mut self, pixels: f32) -> Self {
        self.styles_mut().line_height = Some(crate::text_layout::LineHeight::px(pixels));
        self
    }
    /// Reset inherited line spacing to the normal metric for each text size.
    fn line_height_normal(mut self) -> Self {
        self.styles_mut().line_height = Some(crate::text_layout::LineHeight::NORMAL);
        self
    }
    /// Inherited extra glyph advance in logical pixels. Zero resets inherited tracking.
    /// Non-finite values normalize to zero; finite values clamp to ±1,000,000 pixels.
    fn letter_spacing(mut self, pixels: f32) -> Self {
        self.styles_mut().letter_spacing = Some(crate::text_layout::LetterSpacing::px(pixels));
        self
    }

    fn rounded(mut self, value: f32) -> Self {
        self.styles_mut().radius = Some(value);
        self
    }
    fn border(mut self, value: f32) -> Self {
        self.styles_mut().border_width = Some(value);
        self
    }
    fn border_color(mut self, value: Color) -> Self {
        self.styles_mut().border_color = Some(value);
        self
    }
    fn opacity(mut self, value: f32) -> Self {
        self.styles_mut().opacity = Some(value);
        self
    }
    fn blur(mut self, value: f32) -> Self {
        self.styles_mut().blur = Some(value);
        self
    }
    fn edge_fade(mut self, value: f32) -> Self {
        self.styles_mut().edge_fade = Some(value);
        self
    }
    fn isolated(mut self, value: bool) -> Self {
        self.styles_mut().isolated = Some(value);
        self
    }
    fn text_wrap(mut self, value: bool) -> Self {
        self.styles_mut().text_wrap = Some(value);
        self
    }
    fn size(self, width: f32, height: f32) -> Self {
        self.w(width).h(height)
    }
    fn p(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            15,
        );
        style.padding_sides |= 15;
        self
    }
    fn px(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            10,
        );
        style.padding_sides |= 10;
        self
    }
    fn py(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            5,
        );
        style.padding_sides |= 5;
        self
    }
    fn pt(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            1,
        );
        style.padding_sides |= 1;
        self
    }
    fn pr(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            2,
        );
        style.padding_sides |= 2;
        self
    }
    fn pb(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            4,
        );
        style.padding_sides |= 4;
        self
    }
    fn pl(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.padding.is_some() && style.padding_sides == 0 {
            style.padding_sides = 15;
        }
        merge_insets(
            style.padding.get_or_insert_with(Insets::default),
            Insets::all(value),
            8,
        );
        style.padding_sides |= 8;
        self
    }
    fn m(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            15,
        );
        style.margin_sides |= 15;
        self
    }
    fn mx(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            10,
        );
        style.margin_sides |= 10;
        self
    }
    fn my(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            5,
        );
        style.margin_sides |= 5;
        self
    }
    fn mt(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            1,
        );
        style.margin_sides |= 1;
        self
    }
    fn mr(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            2,
        );
        style.margin_sides |= 2;
        self
    }
    fn mb(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            4,
        );
        style.margin_sides |= 4;
        self
    }
    fn ml(mut self, value: f32) -> Self {
        let style = self.styles_mut();
        if style.margin.is_some() && style.margin_sides == 0 {
            style.margin_sides = 15;
        }
        merge_insets(
            style.margin.get_or_insert_with(Insets::default),
            Insets::all(value),
            8,
        );
        style.margin_sides |= 8;
        self
    }
    fn flex_row(mut self) -> Self {
        self.styles_mut().layout = Some(Layout::Row);
        self
    }
    fn flex_col(mut self) -> Self {
        self.styles_mut().layout = Some(Layout::Column);
        self
    }
    fn overlay(mut self) -> Self {
        self.styles_mut().layout = Some(Layout::Overlay);
        self
    }
    fn items_start(mut self) -> Self {
        self.styles_mut().align = Some(Align::Start);
        self
    }
    fn items_center(mut self) -> Self {
        self.styles_mut().align = Some(Align::Center);
        self
    }
    fn items_end(mut self) -> Self {
        self.styles_mut().align = Some(Align::End);
        self
    }
    fn items_stretch(mut self) -> Self {
        self.styles_mut().align = Some(Align::Stretch);
        self
    }
    fn justify_start(mut self) -> Self {
        self.styles_mut().justify = Some(Justify::Start);
        self
    }
    fn justify_center(mut self) -> Self {
        self.styles_mut().justify = Some(Justify::Center);
        self
    }
    fn justify_end(mut self) -> Self {
        self.styles_mut().justify = Some(Justify::End);
        self
    }
    fn justify_between(mut self) -> Self {
        self.styles_mut().justify = Some(Justify::SpaceBetween);
        self
    }
    fn justify_around(mut self) -> Self {
        self.styles_mut().justify = Some(Justify::SpaceAround);
        self
    }
    fn overflow_hidden(mut self) -> Self {
        self.styles_mut().clip = Some(true);
        self
    }
    fn overflow_visible(mut self) -> Self {
        self.styles_mut().clip = Some(false);
        self
    }
    fn border_1(self) -> Self {
        self.border(1.)
    }
    fn grow(self) -> Self {
        self.flex_grow(1.)
    }
    fn shrink_0(self) -> Self {
        self.flex_shrink(0.)
    }
    fn shadow(mut self, value: BoxShadow) -> Self {
        self.styles_mut().shadow = Some(Some(value));
        self
    }
    fn shadow_none(mut self) -> Self {
        self.styles_mut().shadow = Some(None);
        self
    }
    fn translate(mut self, x: f32, y: f32) -> Self {
        self.styles_mut().transform = Some(Transform { x, y });
        self
    }
}
impl Styled for Styles {
    fn styles_mut(&mut self) -> &mut Styles {
        self
    }
}
/// Opaque color from `0xRRGGBB`.
pub const fn rgb(value: u32) -> Color {
    Color((value >> 16) as u8, (value >> 8) as u8, value as u8, 255)
}
/// Color from `0xRRGGBBAA`, with alpha in the least significant byte.
pub const fn rgba(value: u32) -> Color {
    Color(
        (value >> 24) as u8,
        (value >> 16) as u8,
        (value >> 8) as u8,
        value as u8,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn percentage_patches_normalize_invalid_values_and_replace_pixel_axes() {
        let patch = Styles::new().size(80., 30.).w_percent(50.).h_full();
        assert_eq!(patch.width, None);
        assert_eq!(patch.height, None);
        assert_eq!(patch.width_percent, Some(0.5));
        assert_eq!(patch.height_percent, Some(1.));
        let pixels = patch.style(Styles::new().w(20.));
        assert_eq!(pixels.width, Some(20.));
        assert_eq!(pixels.width_percent, None);
        assert_eq!(pixels.height_percent, Some(1.));
        for invalid in [-1., f32::NAN, f32::INFINITY, f32::NEG_INFINITY] {
            assert_eq!(
                Styles::new().w_percent(invalid),
                Styles::new().w_percent(0.)
            );
        }
        assert_eq!(Styles::new().w_percent(150.).width_percent, Some(1.5));
    }
    #[test]
    fn conditional_transformations_preserve_sparse_patch_edges() {
        fn horizontal<S: Styled>(style: S) -> S {
            style.px(12.)
        }

        let patch = Styles::new()
            .apply(horizontal)
            .when(false, |_| panic!("false branch must not run"))
            .when_some(None::<f32>, |_, _| panic!("missing value must not run"))
            .when(true, |style| style.pl(14.))
            .when_some(Some(String::from("owned")), |style, label| {
                assert_eq!(label, "owned");
                style.pr(16.)
            });
        assert_eq!(patch.padding_sides, 2 | 8);
        let result = Styles::new().p(8.).pt(3.).style(patch);
        assert_eq!(
            result.padding,
            Some(Insets {
                top: 3.,
                right: 16.,
                bottom: 8.,
                left: 14.,
            })
        );
    }
    #[test]
    fn patches_only_override_specified_properties() {
        let base = Styles::new()
            .size(120., 40.)
            .gap(8.)
            .bg(rgb(0x102030))
            .opacity(0.5);
        let result = base.clone().style(Styles::new().w(200.).border_1());
        assert_eq!(result.width, Some(200.));
        assert_eq!(result.height, base.height);
        assert_eq!(result.gap, base.gap);
        assert_eq!(result.background, base.background);
        assert_eq!(result.opacity, base.opacity);
        assert_eq!(result.border_width, Some(1.));
        assert_eq!(result.clone().style(Styles::new()), result);
    }
    #[test]
    fn side_spacing_obeys_chain_and_merge_precedence() {
        let style = Styles::new().p(8.).px(12.).pt(3.).m(4.).mb(9.);
        assert_eq!(
            style.padding,
            Some(Insets {
                top: 3.,
                right: 12.,
                bottom: 8.,
                left: 12.
            })
        );
        assert_eq!(
            style.margin,
            Some(Insets {
                top: 4.,
                right: 4.,
                bottom: 9.,
                left: 4.
            })
        );
        let merged = style.style(Styles::new().py(7.).ml(2.));
        assert_eq!(
            merged.padding,
            Some(Insets {
                top: 7.,
                right: 12.,
                bottom: 7.,
                left: 12.
            })
        );
        assert_eq!(
            merged.margin,
            Some(Insets {
                top: 4.,
                right: 4.,
                bottom: 9.,
                left: 2.
            })
        );
        assert_eq!(merged.p(1.).padding, Some(Insets::all(1.)));
    }
    #[test]
    fn effect_reset_and_color_order_are_explicit() {
        let shadow = BoxShadow {
            color: rgba(0x10203040),
            offset: Transform { x: 1., y: 2. },
            blur_radius: 4.,
            spread: 0.,
        };
        let style = Styles::new()
            .shadow(shadow)
            .overflow_hidden()
            .isolated(true)
            .style(
                Styles::new()
                    .shadow_none()
                    .overflow_visible()
                    .isolated(false),
            );
        assert_eq!(style.shadow, Some(None));
        assert_eq!(style.clip, Some(false));
        assert_eq!(style.isolated, Some(false));
        assert_eq!(rgb(0x102030), Color(16, 32, 48, 255));
        assert_eq!(rgba(0x10203040), Color(16, 32, 48, 64));
    }
}
