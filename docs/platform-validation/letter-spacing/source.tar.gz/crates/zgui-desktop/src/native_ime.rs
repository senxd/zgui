//! Route composition only to the editor owning the current native IME session.
use winit::event::Ime;
use zgui::{
    input::InputEvent,
    scene::NodeId,
    widgets::{LayoutFeedbackError, Ui},
};

/// Returns a new composing state only when an event belonged to this session.
/// Native focus loss keeps logical focus for restoration, so checking the
/// focused editor alone would admit late input from a deactivated native window.
pub(crate) fn dispatch(
    ui: &mut Ui,
    native_focused: bool,
    session_target: Option<NodeId>,
    event: Ime,
) -> Result<Option<bool>, LayoutFeedbackError> {
    if !native_focused
        || session_target.is_none()
        || session_target != ui.focused_editor().map(|editor| editor.node)
    {
        return Ok(None);
    }
    let (event, composing) = match event {
        Ime::Enabled => return Ok(None),
        Ime::Disabled => (
            InputEvent::ImePreedit {
                text: String::new(),
                cursor: None,
            },
            false,
        ),
        Ime::Preedit(text, cursor) => {
            let composing = !text.is_empty();
            (InputEvent::ImePreedit { text, cursor }, composing)
        }
        Ime::Commit(text) => (InputEvent::ImeCommit(text), false),
    };
    let result = ui.try_dispatch(event)?;
    Ok(Some(composing && !result.focus_changed))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::focus_memory::FocusMemory;

    #[test]
    fn late_composition_after_native_blur_cannot_edit_remembered_focus() {
        let mut ui = Ui::new(400., 200.);
        let value = ui.signal(String::new());
        let editor = ui.text_input(ui.root(), "First", value.clone(), 200., false);
        ui.input.focus(&ui.scene, Some(editor.node));
        assert_eq!(
            dispatch(
                &mut ui,
                true,
                Some(editor.node),
                Ime::Preedit("中".into(), Some((3, 3)))
            )
            .unwrap(),
            Some(true)
        );
        assert!(editor.editor.borrow().preedit().is_some());
        let mut focus = FocusMemory::default();
        focus.deactivate(&ui);
        assert_eq!(ui.input.focused(), Some(editor.node));
        assert!(editor.editor.borrow().preedit().is_none());
        for event in [
            Ime::Preedit("文".into(), Some((3, 3))),
            Ime::Commit("文".into()),
        ] {
            assert_eq!(
                dispatch(&mut ui, false, Some(editor.node), event).unwrap(),
                None
            );
        }
        assert_eq!(value.get(), "");
        assert!(editor.editor.borrow().preedit().is_none());
        focus.activate(&ui);
        dispatch(&mut ui, true, Some(editor.node), Ime::Commit("新".into())).unwrap();
        assert_eq!(value.get(), "新");
    }

    #[test]
    fn stale_session_cannot_deliver_to_a_different_or_removed_editor() {
        let mut ui = Ui::new(400., 200.);
        let first_value = ui.signal(String::new());
        let second_value = ui.signal(String::new());
        let first = ui.text_input(ui.root(), "First", first_value.clone(), 200., false);
        let second = ui.text_input(ui.root(), "Second", second_value.clone(), 200., false);
        ui.input.focus(&ui.scene, Some(first.node));
        dispatch(
            &mut ui,
            true,
            Some(first.node),
            Ime::Preedit("中".into(), None),
        )
        .unwrap();
        ui.input.focus(&ui.scene, Some(second.node));
        for event in [
            Ime::Preedit("旧".into(), None),
            Ime::Commit("旧".into()),
            Ime::Disabled,
        ] {
            assert_eq!(
                dispatch(&mut ui, true, Some(first.node), event).unwrap(),
                None
            );
        }
        assert_eq!(first_value.get(), "");
        assert_eq!(second_value.get(), "");
        assert!(second.editor.borrow().preedit().is_none());
        dispatch(&mut ui, true, Some(second.node), Ime::Commit("新".into())).unwrap();
        assert_eq!(second_value.get(), "新");
        ui.remove(second.node);
        assert_eq!(
            dispatch(&mut ui, true, Some(second.node), Ime::Commit("旧".into())).unwrap(),
            None
        );
        assert_eq!(second_value.get(), "新");
    }
}
