//! Transparency, backdrop blur, edge fades and cached group animation.
//! Run: cargo run --release -p zgui-desktop --example effects
use std::{
    cell::Cell,
    rc::Rc,
    time::{Duration, Instant},
};
use zgui::{
    scene::{BoxShadow, Color, Effects, Layout, NodeKind, QuadStyle, Style, Transform},
    widgets::fixed,
};
use zgui_desktop::{Application, WindowOptions};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    Application::new().window(WindowOptions {
        title: "zgui — retained composition".into(), width: 960., height: 680.,
        ..Default::default()
    }).run(|cx| {
        let ui = &mut cx.ui;
        let root = ui.root();
        ui.scene.borrow_mut().set_kind(root, NodeKind::Container(Layout::Overlay));
        for (index, color) in [Color(42,58,99,255), Color(51,86,123,255), Color(46,115,133,255), Color(74,143,153,255), Color(100,117,179,255)].into_iter().enumerate() {
            let stripe = ui.quad(root, QuadStyle { fill: color, radius: 32., ..Default::default() }, fixed(128.,400.));
            ui.scene.borrow_mut().set_transform(stripe, Transform { x: 28. + index as f32 * 104., y: 120. + (index % 2) as f32 * 42. });
        }
        let heading = ui.label(root, "Retained composition", fixed(860.,36.));
        ui.scene.borrow_mut().set_transform(heading, Transform { x:32.,y:30. });
        let description = ui.label(root, "Move and fade cached pixels. Repaint content only when it changes.", fixed(880.,28.));
        ui.scene.borrow_mut().set_transform(description, Transform { x:32.,y:70. });
        let card = ui.container(root, Layout::Overlay, fixed(340.,280.));
        let _glass = ui.quad(card, QuadStyle {
            fill: Color(24,30,49,180), radius: 20., border_color: Color(220,232,255,100), border_width: 1.,
            shadow: Some(BoxShadow { color:Color(0,0,0,130), offset:Transform{x:0.,y:12.}, blur_radius:16., spread:0. }),
        }, fixed(340.,280.));
        let content = ui.container(card, Layout::Column, Style {padding:24.,gap:16.,..fixed(340.,280.)});
        ui.label(content, "Glass and grouped opacity", fixed(292.,28.));
        ui.label(content, "Overlapping shapes blend once.", fixed(292.,24.));
        let overlap = ui.container(content, Layout::Overlay, fixed(260.,100.));
        ui.quad(overlap, QuadStyle{fill:Color(81,199,204,255),radius:14.,..Default::default()},fixed(150.,80.));
        let second = ui.quad(overlap, QuadStyle{fill:Color(131,114,239,255),radius:14.,..Default::default()},fixed(150.,80.));
        ui.scene.borrow_mut().set_transform(second,Transform{x:92.,y:18.});
        ui.label(content, "Unicode shaping · 世界 · العربية", fixed(296.,28.));
        ui.scene.borrow_mut().set_isolated(card,true);
        ui.scene.borrow_mut().set_transform(card,Transform{x:120.,y:210.});
        // The root filter samples the parent's backdrop. A filter on `glass`
        // inside this isolated group would sample only this group's contents.
        let controls=ui.container(root,Layout::Column,Style{padding:20.,gap:12.,..fixed(320.,450.)});
        ui.scene.borrow_mut().set_transform(controls,Transform{x:608.,y:130.});
        let opacity=ui.signal(0.88);
        let blur=ui.signal(10.0);
        let fade=ui.signal(0.0);
        ui.label(controls,"Group opacity",fixed(280.,26.));
        ui.slider(controls,"Group opacity",opacity.clone(),0.0..=1.0,280.);
        ui.label(controls,"Backdrop blur",fixed(280.,26.));
        ui.slider(controls,"Backdrop blur",blur.clone(),0.0..=24.0,280.);
        ui.label(controls,"Edge fade",fixed(280.,26.));
        ui.slider(controls,"Edge fade",fade.clone(),0.0..=80.0,280.);
        let animate=ui.signal(false);
        ui.checkbox(controls,"Animate translation",animate.clone(),280.);
        let scene=ui.scene.clone();
        ui.bind(card,move||{
            scene.borrow_mut().set_effects(card,Effects{opacity:opacity.get(),blur_radius:blur.get(),edge_fade:fade.get()});
        });
        let epoch=Rc::new(Cell::new(0_u64));
        let scene=ui.scene.clone();let tasks=cx.tasks.clone();
        ui.bind(card,move||{
            let active=animate.get();
            let generation=epoch.get().wrapping_add(1);epoch.set(generation);
            if !active {return;}
            let scene=scene.clone();let epoch=epoch.clone();
            tasks.spawn(async move{
                let start=Instant::now();
                while epoch.get()==generation {
                    let x=120.+(start.elapsed().as_secs_f32()*1.8).sin()*44.;
                    scene.borrow_mut().set_transform(card,Transform{x,y:210.});
                    zgui::timer::sleep(Duration::from_millis(16)).await;
                }
            });
        });
        let note=ui.label(root,"Disable blur to measure pure retained-layer movement; paused controls leave the event loop asleep.",fixed(890.,28.));
        ui.scene.borrow_mut().set_transform(note,Transform{x:32.,y:612.});
        if let Ok(seconds)=std::env::var("ZGUI_SECONDS").unwrap_or_default().parse::<f64>() && seconds>0. {
            let window=cx.window.clone();cx.tasks.spawn(async move {
                zgui::timer::sleep(Duration::from_secs_f64(seconds)).await;window.close();
            });
        }
    })
}
