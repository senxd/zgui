//! Native window controls. `--smoke-test` exercises the real window manager.
use std::time::Duration;
use zgui::{compose::prelude::*, timer::sleep};
use zgui_desktop::{Application, WindowOptions};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let smoke = std::env::args().any(|arg| arg == "--smoke-test");
    Application::new().window(WindowOptions {
        title: "zgui window controls".into(), width: 640., height: 480., ..Default::default()
    }).run(move |cx| {
        let window = cx.window.clone();
        let resize = window.clone();
        let maximize = window.clone();
        let restore = window.clone();
        cx.render(column().gap(12.).p(24.).children([
            text("Native window controls"),
            button().child(text("Resize to 800 × 600")).on_click(move || resize.set_inner_size(800., 600.)),
            button().child(text("Maximize")).on_click(move || maximize.set_maximized(true)),
            button().child(text("Restore")).on_click(move || restore.set_maximized(false)),
        ]));
        if smoke {
            let viewport = cx.viewport.clone();
            cx.tasks.spawn(async move {
                sleep(Duration::from_secs(1)).await;
                window.set_title("zgui controls resized");
                window.set_inner_size(800., 600.);
                sleep(Duration::from_secs(1)).await;
                assert_eq!(viewport.get(), (800., 600.), "native resize was not acknowledged");
                println!("CONTROLS resized 800x600");
                window.set_minimized(true);
                println!("CONTROLS minimize requested");
                sleep(Duration::from_secs(1)).await;
                window.set_minimized(false);
                window.request_focus();
                println!("CONTROLS restore requested");
                sleep(Duration::from_secs(1)).await;
                window.set_maximized(true);
                println!("CONTROLS maximize requested");
                sleep(Duration::from_secs(1)).await;
                assert!(viewport.get().0 >= 800. && viewport.get().1 >= 600.);
                window.set_maximized(false);
                sleep(Duration::from_secs(1)).await;
                window.set_visible(false);
                println!("CONTROLS hide requested");
                sleep(Duration::from_secs(1)).await;
                window.set_visible(true);
                window.request_focus();
                println!("CONTROLS show requested");
                sleep(Duration::from_secs(1)).await;
                window.set_inner_size(640., 480.);
                sleep(Duration::from_secs(1)).await;
                assert_eq!(viewport.get(), (640., 480.));
                println!("window controls smoke passed (native viewport resize; state requests issued)");
                window.close();
                // Closed handles must tolerate late work from a detached task.
                window.set_title("closed");
                window.set_visible(true);
                window.set_inner_size(1., 1.);
            });
        }
    })
}
