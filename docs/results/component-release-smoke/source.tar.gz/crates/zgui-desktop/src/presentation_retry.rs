//! Scheduling for retained frames that could not yet reach the native surface.
use std::time::{Duration, Instant};
use zgui_gpu::PresentationStatus;

#[derive(Default)]
pub(crate) struct Presentation {
    pending: bool,
    occluded: bool,
    timeouts: u8,
    retry_at: Option<Instant>,
}
impl Presentation {
    pub fn damaged(&mut self) {
        self.pending = true;
        if self.timeouts >= 4 {
            self.timeouts = 0;
        }
    }
    pub fn expose(&mut self) {
        self.occluded = false;
        self.timeouts = 0;
        self.retry_at = None;
    }
    pub fn occlude(&mut self) {
        self.occluded = true;
        self.retry_at = None;
    }
    pub fn ready(&self, now: Instant) -> bool {
        self.pending
            && !self.occluded
            && self.timeouts < 4
            && self.retry_at.is_none_or(|deadline| now >= deadline)
    }
    pub fn deadline(&self) -> Option<Instant> {
        self.retry_at
    }
    pub fn completed(&mut self, status: PresentationStatus, now: Instant) {
        self.retry_at = None;
        match status {
            PresentationStatus::Presented | PresentationStatus::Offscreen => {
                self.pending = false;
                self.timeouts = 0;
            }
            PresentationStatus::Timeout => {
                self.timeouts += 1;
                if self.timeouts < 4 {
                    self.retry_at = Some(now + Duration::from_millis(16 << (self.timeouts - 1)));
                }
            }
            PresentationStatus::Occluded => self.occlude(),
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn timeout_retries_retained_frame_without_new_damage_then_sleeps() {
        let mut p = Presentation::default();
        let mut now = Instant::now();
        p.damaged();
        for _ in 0..4 {
            assert!(p.ready(now));
            p.completed(PresentationStatus::Timeout, now);
            assert!(!p.ready(now));
            if let Some(deadline) = p.deadline() {
                assert!(deadline > now);
                now = deadline;
            }
        }
        assert_eq!(p.deadline(), None);
        p.damaged();
        assert!(p.ready(now));
        p.completed(PresentationStatus::Occluded, now);
        p.expose();
        assert!(p.ready(now));
        p.completed(PresentationStatus::Presented, now);
        assert!(!p.ready(now));
        assert_eq!(p.deadline(), None);
    }
    #[test]
    fn occlusion_preserves_new_damage_until_visibility_returns() {
        let mut p = Presentation::default();
        let now = Instant::now();
        p.damaged();
        p.completed(PresentationStatus::Occluded, now);
        p.damaged();
        assert!(!p.ready(now));
        assert_eq!(p.deadline(), None);
        p.expose();
        assert!(p.ready(now));
        p.completed(PresentationStatus::Presented, now);
        assert!(!p.ready(now));
    }
}
