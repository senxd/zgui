//! Native accessibility tree translation. Stable IDs survive incremental updates.
use accesskit::{Action, Node, NodeId as AccessibleId, Tree, TreeId, TreeUpdate};
use std::collections::{HashMap, HashSet};
use zgui::{
    scene::{NodeId, Scene},
    semantics::{Role, Semantics},
};

#[derive(Default)]
pub struct AccessibilityTree {
    ids: HashMap<NodeId, AccessibleId>,
    next: u64,
    cache: HashMap<AccessibleId, Node>,
}
impl AccessibilityTree {
    pub fn new() -> Self {
        Self::default()
    }
    /// Force a complete snapshot when a native accessibility client reconnects.
    pub fn reset(&mut self) {
        self.cache.clear();
    }
    fn id(&mut self, node: NodeId) -> AccessibleId {
        *self.ids.entry(node).or_insert_with(|| {
            self.next += 1;
            AccessibleId(self.next)
        })
    }
    pub fn scene_node(&self, id: AccessibleId) -> Option<NodeId> {
        self.ids
            .iter()
            .find_map(|(node, a)| (*a == id).then_some(*node))
    }
    pub fn update(
        &mut self,
        scene: &Scene,
        semantics: &Semantics,
        focused: Option<NodeId>,
        title: &str,
        scale: f64,
    ) -> TreeUpdate {
        let root = self.id(scene.root());
        let mut children: HashMap<NodeId, Vec<AccessibleId>> = HashMap::new();
        // Scene order, not hash-map iteration order, determines accessible traversal.
        let ordered: Vec<_> = scene
            .paint_items()
            .filter(|p| p.effects.opacity > 0.0)
            .filter_map(|p| semantics.get(p.id).map(|s| (p.id, s)))
            .collect();
        let visible: HashSet<_> = ordered
            .iter()
            .map(|(id, _)| *id)
            .chain(std::iter::once(scene.root()))
            .collect();
        self.ids.retain(|id, _| visible.contains(id));
        for (id, _) in &ordered {
            if *id == scene.root() {
                continue;
            }
            let mut parent = scene.parent(*id);
            while let Some(p) = parent {
                if p == scene.root() || semantics.get(p).is_some() {
                    break;
                }
                parent = scene.parent(p);
            }
            let child = self.id(*id);
            children
                .entry(parent.unwrap_or(scene.root()))
                .or_default()
                .push(child);
        }
        let mut nodes = Vec::with_capacity(ordered.len() + 1);
        let mut window = Node::new(accesskit::Role::Window);
        window.set_label(title);
        window.set_children(children.remove(&scene.root()).unwrap_or_default());
        let bounds = scene.bounds(scene.root());
        window.set_bounds(accesskit::Rect::new(
            0.,
            0.,
            bounds.width as f64 * scale,
            bounds.height as f64 * scale,
        ));
        nodes.push((root, window));
        for (id, semantic) in ordered {
            if id == scene.root() {
                continue;
            }
            let mut n = Node::new(role(semantic.role));
            n.set_label(semantic.label.clone());
            if let Some(v) = &semantic.value {
                n.set_value(v.clone());
            }
            if let Some(v) = semantic.checked {
                n.set_toggled(if v {
                    accesskit::Toggled::True
                } else {
                    accesskit::Toggled::False
                });
            }
            let disabled = semantic.disabled
                || scene
                    .ancestors(id)
                    .any(|ancestor| semantics.get(ancestor).is_some_and(|s| s.disabled));
            if disabled {
                n.set_disabled();
            }
            if let Some(v) = semantic.numeric_value {
                n.set_numeric_value(v);
            }
            if let Some(v) = semantic.min {
                n.set_min_numeric_value(v);
            }
            if let Some(v) = semantic.max {
                n.set_max_numeric_value(v);
            }
            if matches!(
                semantic.role,
                Role::Button | Role::CheckBox | Role::MenuItem
            ) {
                n.add_action(Action::Click);
            }
            if matches!(
                semantic.role,
                Role::TextInput | Role::MultilineTextInput | Role::Slider
            ) {
                n.add_action(Action::SetValue);
            }
            if matches!(
                semantic.role,
                Role::Button
                    | Role::CheckBox
                    | Role::MenuItem
                    | Role::TextInput
                    | Role::MultilineTextInput
                    | Role::Slider
            ) {
                n.add_action(Action::Focus);
            }
            if semantic.role == Role::Slider {
                n.add_action(Action::Increment);
                n.add_action(Action::Decrement);
            }
            let r = scene.bounds(id);
            n.set_bounds(accesskit::Rect::new(
                r.x as f64 * scale,
                r.y as f64 * scale,
                (r.x + r.width) as f64 * scale,
                (r.y + r.height) as f64 * scale,
            ));
            n.set_children(children.remove(&id).unwrap_or_default());
            nodes.push((self.id(id), n));
        }
        let live: HashSet<_> = self.ids.values().copied().collect();
        self.cache.retain(|id, _| live.contains(id));
        nodes.retain(|(id, node)| {
            if self.cache.get(id) == Some(node) {
                false
            } else {
                self.cache.insert(*id, node.clone());
                true
            }
        });
        let mut tree = Tree::new(root);
        tree.toolkit_name = Some("zgui".into());
        tree.toolkit_version = Some(env!("CARGO_PKG_VERSION").into());
        TreeUpdate {
            nodes,
            tree: Some(tree),
            tree_id: TreeId::ROOT,
            focus: focused
                .and_then(|n| self.ids.get(&n).copied())
                .unwrap_or(root),
        }
    }
}
fn role(r: Role) -> accesskit::Role {
    match r {
        Role::Window => accesskit::Role::Window,
        Role::Group => accesskit::Role::GenericContainer,
        Role::Label => accesskit::Role::Label,
        Role::Button => accesskit::Role::Button,
        Role::CheckBox => accesskit::Role::CheckBox,
        Role::Slider => accesskit::Role::Slider,
        Role::TextInput => accesskit::Role::TextInput,
        Role::MultilineTextInput => accesskit::Role::MultilineTextInput,
        Role::Progress => accesskit::Role::ProgressIndicator,
        Role::ScrollView => accesskit::Role::ScrollView,
        Role::Dialog => accesskit::Role::Dialog,
        Role::Menu => accesskit::Role::Menu,
        Role::MenuItem => accesskit::Role::MenuItem,
        Role::Image => accesskit::Role::Image,
    }
}
