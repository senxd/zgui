use accesskit::{Action, Role as NativeRole};
use accesskit_consumer::{Node, Tree, TreeChangeHandler as ChangeHandler};
use zgui::{
    input::InputEvent,
    scene::Layout,
    semantics::{Role, SemanticNode},
    widgets::{Ui, fixed},
};
use zgui_desktop::accessibility::AccessibilityTree;
#[derive(Default)]
struct Changes {
    removed: usize,
    updated: usize,
}
impl ChangeHandler for Changes {
    fn node_added(&mut self, _: &Node) {}
    fn node_updated(&mut self, _: &Node, _: &Node) {
        self.updated += 1;
    }
    fn focus_moved(&mut self, _: Option<&Node>, _: Option<&Node>) {}
    fn node_removed(&mut self, _: &Node) {
        self.removed += 1;
    }
}
#[test]
fn consumer_accepts_hierarchy_root_semantics_focus_removal_and_reactivation() {
    let mut ui = Ui::new(800., 600.);
    let root = ui.root();
    ui.semantics
        .borrow_mut()
        .set(root, SemanticNode::new(Role::Window, "root"));
    let group = ui.container(root, Layout::Column, fixed(300., 200.));
    ui.semantics
        .borrow_mut()
        .set(group, SemanticNode::new(Role::Group, "Settings"));
    let plain = ui.container(group, Layout::Column, fixed(200., 100.));
    let first = ui.button(plain, "First", 100., || {});
    let second = ui.button(plain, "Second", 100., || {});
    ui.scene.borrow_mut().flush();
    let mut adapter = AccessibilityTree::new();
    let initial = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(first),
        "App",
        2.,
    );
    let first_id = initial.focus;
    let root_id = initial.tree.as_ref().unwrap().root;
    assert_ne!(root_id, first_id);
    assert_eq!(adapter.scene_node(first_id), Some(first));
    let mut consumer = Tree::new(initial, true);
    assert_eq!(consumer.state().focus().unwrap().role(), NativeRole::Button);
    let idle = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(first),
        "App",
        2.,
    );
    assert!(idle.nodes.is_empty());
    ui.scene
        .borrow_mut()
        .reorder_children(plain, &[second, first]);
    ui.scene.borrow_mut().flush();
    let reordered = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(first),
        "App",
        2.,
    );
    let native_group = reordered
        .nodes
        .iter()
        .find(|(_, node)| node.role() == NativeRole::GenericContainer)
        .unwrap();
    let order: Vec<_> = native_group
        .1
        .children()
        .iter()
        .map(|id| adapter.scene_node(*id).unwrap())
        .collect();
    assert_eq!(order, vec![second, first]);
    consumer.update_and_process_changes(reordered, &mut Changes::default());
    let update = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(second),
        "App",
        2.,
    );
    let second_id = update.focus;
    assert!(update.nodes.is_empty());
    consumer.update_and_process_changes(update, &mut Changes::default());
    ui.remove(first);
    ui.scene.borrow_mut().flush();
    let update = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(second),
        "App",
        2.,
    );
    let mut changes = Changes::default();
    consumer.update_and_process_changes(update, &mut changes);
    assert_eq!(changes.removed, 1);
    assert_eq!(adapter.scene_node(first_id), None);
    assert_eq!(adapter.scene_node(second_id), Some(second));
    adapter.reset();
    let restored = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(second),
        "App",
        2.,
    );
    assert_eq!(restored.focus, second_id);
    let _reconnected = Tree::new(restored, true);
}
#[test]
fn slider_and_editor_accessible_actions_update_values_and_reject_disabled() {
    let mut ui = Ui::new(800., 600.);
    let value = ui.signal(50.);
    let slider = ui.slider(ui.root(), "Volume", value.clone(), 0.0..=100., 200.);
    let text = ui.signal("hello".to_owned());
    let editor = ui.text_input(ui.root(), "Name", text.clone(), 200., false);
    assert!(ui.set_accessible_numeric_value(slider, 150.));
    assert_eq!(value.get(), 100.);
    assert!(!ui.set_accessible_numeric_value(slider, f64::NAN));
    assert_eq!(value.get(), 100.);
    ui.input
        .dispatch_to(&ui.scene, slider, InputEvent::Decrement);
    assert_eq!(value.get(), 99.);
    assert!(ui.set_accessible_value(slider, "25"));
    assert_eq!(value.get(), 25.);
    assert!(ui.set_accessible_value(editor.node, "new\r\nname"));
    assert_eq!(text.get(), "newname");
    ui.set_disabled(slider, true);
    assert!(!ui.set_accessible_numeric_value(slider, 0.));
    assert_eq!(value.get(), 25.);
    ui.runtime.flush();
    ui.scene.borrow_mut().flush();
    let update = AccessibilityTree::new().update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        None,
        "App",
        1.,
    );
    let native = update
        .nodes
        .iter()
        .find(|(_, n)| n.role() == NativeRole::Slider)
        .unwrap();
    assert!(native.1.supports_action(Action::Increment));
    assert_eq!(native.1.numeric_value(), Some(25.));
    assert!(native.1.is_disabled());
    let _consumer = Tree::new(update, true);
}

#[test]
fn hidden_dialog_subtree_leaves_native_tree_and_actions() {
    let mut ui = Ui::new(800., 600.);
    let dialog = ui.container(ui.root(), Layout::Column, fixed(200., 100.));
    ui.semantics
        .borrow_mut()
        .set(dialog, SemanticNode::new(Role::Dialog, "Dialog"));
    let button = ui.button(dialog, "Close", 100., || {});
    ui.scene.borrow_mut().flush();
    let mut adapter = AccessibilityTree::new();
    let initial = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(button),
        "App",
        1.,
    );
    let old = initial.focus;
    let mut consumer = Tree::new(initial, true);
    ui.scene.borrow_mut().set_effects(
        dialog,
        zgui::scene::Effects {
            opacity: 0.,
            ..Default::default()
        },
    );
    ui.scene.borrow_mut().flush();
    let update = adapter.update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        Some(button),
        "App",
        1.,
    );
    assert_eq!(update.focus, update.tree.as_ref().unwrap().root);
    assert_eq!(adapter.scene_node(old), None);
    let mut changes = Changes::default();
    consumer.update_and_process_changes(update, &mut changes);
    assert_eq!(changes.removed, 2);
}

#[test]
fn disabled_container_marks_native_descendants_disabled() {
    let mut ui = Ui::new(500., 500.);
    let group = ui.container(ui.root(), Layout::Column, fixed(200., 100.));
    ui.button(group, "Save", 100., || {});
    ui.set_disabled(group, true);
    ui.scene.borrow_mut().flush();
    let update = AccessibilityTree::new().update(
        &ui.scene.borrow(),
        &ui.semantics.borrow(),
        None,
        "App",
        1.,
    );
    let button = update
        .nodes
        .iter()
        .find(|(_, n)| n.role() == NativeRole::Button)
        .unwrap();
    assert!(button.1.is_disabled());
    let _consumer = Tree::new(update, true);
}
