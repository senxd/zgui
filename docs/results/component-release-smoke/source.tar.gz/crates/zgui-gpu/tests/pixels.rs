use zgui::scene::*;
use zgui_gpu::GpuRenderer;
fn fixed(w: f32, h: f32) -> Style {
    Style {
        width: Some(w),
        height: Some(h),
        ..Default::default()
    }
}
#[test]
fn retained_damage_alpha_text_and_scale() {
    let mut gpu = GpuRenderer::new(128, 64).expect("a Vulkan/Metal adapter is required");
    let mut s = Scene::new(128., 64.);
    s.set_kind(s.root(), NodeKind::Container(Layout::Overlay));
    let bg = s.append(
        s.root(),
        NodeKind::Rect(Color(20, 40, 60, 255)),
        fixed(128., 64.),
    );
    let front = s.append(
        s.root(),
        NodeKind::Rect(Color(200, 0, 0, 128)),
        fixed(20., 20.),
    );
    let damage = s.flush().damage;
    let stats = gpu.render(&s, &damage).unwrap();
    assert!(stats.draw_calls > 0);
    let pixels = gpu.readback().unwrap();
    assert_eq!(
        gpu.present_with_status().unwrap(),
        zgui_gpu::PresentationStatus::Offscreen
    );
    gpu.present().unwrap();
    assert_eq!(pixels, gpu.readback().unwrap());
    assert_eq!(
        &pixels[(30 * 128 + 30) * 4..(30 * 128 + 30) * 4 + 4],
        &[20, 40, 60, 255]
    );
    assert!((pixels[0] as i32 - 110).abs() <= 1);
    assert_eq!(gpu.render(&s, &[]).unwrap().draw_calls, 0);
    s.set_transform(front, Transform { x: 30., y: 0. });
    {
        let d = s.flush().damage;
        gpu.render(&s, &d).unwrap()
    };
    let partial = gpu.readback().unwrap();
    gpu.render(&s, &[Rect::new(0., 0., 128., 64.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    assert_eq!(&partial[..4], &[20, 40, 60, 255]);
    let text = s.append(
        s.root(),
        NodeKind::Text {
            text: "Hello العربية".into(),
            color: Color(255, 255, 255, 255),
            font_size: 16.,
        },
        fixed(128., 32.),
    );
    s.set_transform(text, Transform { x: 0., y: 25. });
    let d = s.flush().damage;
    let stats = gpu.render(&s, &d).unwrap();
    assert_eq!(stats.shaped_nodes, 1);
    assert!(stats.glyph_uploads > 0);
    let pixels = gpu.readback().unwrap();
    assert!(pixels.chunks_exact(4).any(|p| p[0] > 200 && p[1] > 200));
    assert_eq!(gpu.render(&s, &d).unwrap().shaped_nodes, 0);
    s.set_effects(
        front,
        Effects {
            edge_fade: 10.,
            ..Default::default()
        },
    );
    let d = s.flush().damage;
    gpu.render(&s, &d).unwrap();
    let partial = gpu.readback().unwrap();
    gpu.render(&s, &[Rect::new(0., 0., 128., 64.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    s.remove(text);
    s.remove(front);
    s.set_kind(bg, NodeKind::Rect(Color(1, 2, 3, 255)));
    s.resize(64., 32.);
    s.set_style(bg, fixed(64., 32.));
    gpu.set_scale_factor(2.);
    {
        let d = s.flush().damage;
        gpu.render(&s, &d).unwrap()
    };
    assert_eq!(&gpu.readback().unwrap()[..4], &[1, 2, 3, 255]);
}

#[test]
fn backdrop_blur_reconstructs_without_feedback() {
    let mut gpu = GpuRenderer::new(64, 32).unwrap();
    let mut s = Scene::new(64., 32.);
    s.set_kind(s.root(), NodeKind::Container(Layout::Overlay));
    s.append(
        s.root(),
        NodeKind::Rect(Color(0, 0, 0, 255)),
        fixed(64., 32.),
    );
    let white = s.append(
        s.root(),
        NodeKind::Rect(Color(255, 255, 255, 255)),
        fixed(32., 32.),
    );
    let glass = s.append(
        s.root(),
        NodeKind::Rect(Color(255, 0, 0, 40)),
        fixed(64., 32.),
    );
    s.set_effects(
        glass,
        Effects {
            blur_radius: 4.,
            ..Default::default()
        },
    );
    let d = s.flush().damage;
    gpu.render(&s, &d).unwrap();
    let first = gpu.readback().unwrap();
    let index = (16 * 64 + 32) * 4;
    assert!(
        first[index + 1] > 20 && first[index + 1] < 200,
        "blur crosses the white/black boundary"
    );
    gpu.render(&s, &d).unwrap();
    assert_eq!(first, gpu.readback().unwrap(), "no repeated-blur feedback");
    s.set_kind(white, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = s.flush().damage;
    gpu.render(&s, &d).unwrap();
    let partial = gpu.readback().unwrap();
    gpu.render(&s, &[Rect::new(0., 0., 64., 32.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
}

#[test]
fn rounded_border_shadow_images_and_background_damage() {
    let mut gpu = GpuRenderer::new(80, 60).unwrap();
    gpu.set_background(Color(0, 0, 0, 0));
    let mut scene = Scene::new(80., 60.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let id = scene.append(
        scene.root(),
        NodeKind::Quad(QuadStyle {
            fill: Color(255, 0, 0, 255),
            radius: 8.,
            border_color: Color(0, 255, 0, 255),
            border_width: 3.,
            shadow: Some(BoxShadow {
                color: Color(0, 0, 255, 128),
                offset: Transform { x: -6., y: 2. },
                blur_radius: 3.,
                spread: 1.,
            }),
        }),
        fixed(24., 24.),
    );
    scene.set_transform(id, Transform { x: 20., y: 10. });
    let d = scene.flush().damage;
    assert!(d.iter().any(|r| r.x <= 4.));
    gpu.render(&scene, &d).unwrap();
    let pixels = gpu.readback().unwrap();
    let pixel = |x: usize, y: usize| &pixels[(y * 80 + x) * 4..(y * 80 + x) * 4 + 4];
    assert_eq!(pixel(32, 22), &[255, 0, 0, 255]);
    assert!(pixel(32, 10)[1] > 200);
    assert!(pixel(20, 10)[0] < 20);
    assert!(pixel(13, 22)[2] > 0);
    scene.set_transform(id, Transform { x: 40., y: 20. });
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let partial = gpu.readback().unwrap();
    gpu.render(&scene, &[Rect::new(0., 0., 80., 60.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    let image = std::sync::Arc::new(
        zgui::image::ImageData::new(
            2,
            2,
            vec![
                255, 255, 0, 255, 255, 255, 0, 255, 255, 255, 0, 255, 255, 255, 0, 255,
            ],
        )
        .unwrap(),
    );
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        Style {
            clip: true,
            ..fixed(6., 6.)
        },
    );
    scene.append(group, NodeKind::Image(image), fixed(16., 16.));
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let pixels = gpu.readback().unwrap();
    assert_eq!(&pixels[..4], &[255, 255, 0, 255]);
    assert_eq!(&pixels[7 * 4..8 * 4], &[0, 0, 0, 0]);
    scene.remove(group);
    scene.remove(id);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert!(gpu.readback().unwrap().iter().all(|b| *b == 0));
    gpu.set_background(Color(10, 20, 30, 128));
    gpu.render(&scene, &[]).unwrap();
    let p = gpu.readback().unwrap();
    assert_eq!(&p[..4], &[5, 10, 15, 128]);
}

#[test]
fn image_and_svg_decoding_are_bounded_and_alpha_correct() {
    let svg=br#"<svg xmlns="http://www.w3.org/2000/svg" width="2" height="2"><rect width="2" height="2" fill="red" fill-opacity="0.5"/></svg>"#;
    let image = zgui_gpu::assets::decode_svg(svg, 2, 2).unwrap();
    assert_eq!(&image.pixels()[..4], &[255, 0, 0, 128]);
    assert!(zgui_gpu::assets::decode_svg(svg, 0, 2).is_err());
    assert!(zgui_gpu::assets::decode_image(b"invalid").is_err());
    let mut png = std::io::Cursor::new(Vec::new());
    image::DynamicImage::ImageRgba8(image::RgbaImage::from_pixel(
        2,
        2,
        image::Rgba([12, 34, 56, 128]),
    ))
    .write_to(&mut png, image::ImageFormat::Png)
    .unwrap();
    let decoded = zgui_gpu::assets::decode_image(png.get_ref()).unwrap();
    assert_eq!(&decoded.pixels()[..4], &[12, 34, 56, 128]);
}

#[test]
fn text_metrics_match_editor_line_pitch() {
    let mut fonts = cosmic_text::FontSystem::new();
    assert_eq!(zgui_gpu::measure_text(&mut fonts, "", 14., None).1, 20.);
    assert_eq!(zgui_gpu::measure_text(&mut fonts, "a\nb", 14., None).1, 40.);
}

#[test]
fn thousand_streaming_frames_keep_caches_bounded_and_reuse_vertices() {
    let mut gpu = GpuRenderer::new(160, 80).unwrap();
    let mut scene = Scene::new(160., 80.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let stable = scene.append(
        scene.root(),
        NodeKind::Text {
            text: "Retained العربية".into(),
            font_size: 14.,
            color: Color(255, 255, 255, 255),
        },
        fixed(160., 24.),
    );
    let mut changing = scene.append(
        scene.root(),
        NodeKind::Text {
            text: "frame 0".into(),
            font_size: 14.,
            color: Color(255, 0, 0, 255),
        },
        fixed(160., 24.),
    );
    scene.set_transform(changing, Transform { x: 0., y: 30. });
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let initial = gpu.debug_cache_stats().vertex_buffer_bytes;
    scene.set_transform(stable, Transform { x: 1., y: 0. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.geometry_rebuilds, 0);
    assert_eq!(stats.glyph_uploads, 0);
    assert_eq!(stats.vertex_buffer_allocations, 0);
    for frame in 0..1000 {
        if frame % 20 == 0 {
            scene.remove(changing);
            changing = scene.append(
                scene.root(),
                NodeKind::Text {
                    text: "reused".into(),
                    font_size: 14.,
                    color: Color(255, 0, 0, 255),
                },
                fixed(160., 24.),
            );
            scene.set_transform(changing, Transform { x: 0., y: 30. });
        }
        scene.set_kind(
            changing,
            NodeKind::Text {
                text: format!(
                    "frame {frame} {}",
                    char::from_u32(0x400 + (frame % 80)).unwrap()
                )
                .into(),
                font_size: 12. + (frame % 20) as f32 * 0.25,
                color: Color(255, 0, 0, 255),
            },
        );
        let d = scene.flush().damage;
        gpu.render(&scene, &d).unwrap();
        let c = gpu.debug_cache_stats();
        assert!(c.shaped_nodes <= 2);
        assert!(c.shaped_bytes <= 8 * 1024 * 1024);
        assert_eq!(c.swash_images, 0);
        assert_eq!(c.swash_outlines, 0);
        assert!(c.vertex_buffer_bytes <= initial.max(8192));
        assert!(c.atlas_entries < 5000);
    }
    gpu.readback().unwrap();
    scene.remove(changing);
    scene.remove(stable);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().shaped_nodes, 0);
}

#[test]
fn shaped_hit_caret_and_disjoint_bidi_selection_use_visual_clusters() {
    use zgui_gpu::text::{Affinity, ShapedText, TextCursor};
    let mut fonts = cosmic_text::FontSystem::new();
    let rtl = ShapedText::new(&mut fonts, "אבג", 18., None);
    let begin = rtl
        .caret(TextCursor {
            byte_index: 0,
            affinity: Affinity::After,
        })
        .unwrap();
    let end = rtl
        .caret(TextCursor {
            byte_index: 6,
            affinity: Affinity::Before,
        })
        .unwrap();
    assert!(begin.x > end.x);
    assert_eq!(rtl.hit_test(end.x + 0.1, 10.).unwrap().byte_index, 6);
    assert_eq!(rtl.hit_test(begin.x - 0.1, 10.).unwrap().byte_index, 0);
    let mixed = ShapedText::new(&mut fonts, "abc אבג xyz", 18., None);
    let spans = mixed.selection(2..6);
    assert_eq!(spans.len(), 2);
    assert!(spans[0].x + spans[0].width < spans[1].x);
    let ligature = ShapedText::new(&mut fonts, "office", 18., None);
    let positions: Vec<_> = (1..5)
        .map(|byte_index| {
            ligature
                .caret(TextCursor {
                    byte_index,
                    affinity: Affinity::After,
                })
                .unwrap()
                .x
        })
        .collect();
    assert!(positions.windows(2).all(|w| w[0] < w[1]));
    let combining = ShapedText::new(&mut fonts, "e\u{301}x", 18., None);
    for x in 0..40 {
        let cursor = combining.hit_test(x as f32, 5.).unwrap();
        assert!([0, 3, 4].contains(&cursor.byte_index));
    }
    let lines = ShapedText::new(&mut fonts, "a\r\nb", 14., None);
    assert_eq!(lines.hit_test(0., 25.).unwrap().byte_index, 3);
    assert_eq!(
        lines
            .caret(TextCursor {
                byte_index: 3,
                affinity: Affinity::After
            })
            .unwrap()
            .y,
        20.
    );
}

#[test]
fn scene_installs_native_text_geometry() {
    let fonts = std::rc::Rc::new(std::cell::RefCell::new(cosmic_text::FontSystem::new()));
    let mut scene = Scene::new(100., 100.);
    scene.set_text_shaper(
        move |text: &str,
              size: f32,
              width: Option<f32>|
              -> Box<dyn zgui::text_layout::TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::new(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
            ))
        },
    );
    let layout = scene.shape_text("אבג", 14., None);
    assert!(layout.caret(0).x > layout.caret(6).x);
    assert_eq!(scene.measure_text("a\nb", 14., None).1, 40.);
}

#[test]
fn image_cache_reclaims_removed_nodes_and_rejects_oversized_allocations() {
    let mut gpu = GpuRenderer::new(8, 8).unwrap();
    let mut scene = Scene::new(8., 8.);
    let image = std::sync::Arc::new(zgui::image::ImageData::new(2, 2, vec![255; 16]).unwrap());
    let node = scene.append(scene.root(), NodeKind::Image(image.clone()), fixed(8., 8.));
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().image_textures, 1);
    assert_eq!(gpu.debug_cache_stats().image_bytes, 16);
    scene.remove(node);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().image_textures, 0);
    let huge = std::sync::Arc::new(
        zgui::image::ImageData::new(4096, 4097, vec![0; 4096 * 4097 * 4]).unwrap(),
    );
    scene.append(scene.root(), NodeKind::Image(huge), fixed(8., 8.));
    let d = scene.flush().damage;
    let error = gpu.render(&scene, &d).unwrap_err();
    assert!(error.0.contains("64 MiB"));
    assert_eq!(gpu.debug_cache_stats().image_bytes, 0);
}

#[test]
fn isolated_opacity_composites_once_and_retains_transformed_subtrees() {
    let mut gpu = GpuRenderer::new(80, 40).unwrap();
    let mut scene = Scene::new(80., 40.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(24., 24.),
    );
    scene.set_isolated(group, true);
    scene.set_effects(
        group,
        Effects {
            opacity: 0.5,
            ..Default::default()
        },
    );
    scene.append(
        group,
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(24., 24.),
    );
    let top = scene.append(
        group,
        NodeKind::Rect(Color(0, 0, 255, 255)),
        fixed(16., 24.),
    );
    scene.set_transform(top, Transform { x: 8., y: 0. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 1);
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(10 * 80 + 12) * 4..(10 * 80 + 12) * 4 + 4],
        &[0, 0, 128, 128]
    );
    assert_eq!(
        &p[(10 * 80 + 2) * 4..(10 * 80 + 2) * 4 + 4],
        &[128, 0, 0, 128]
    );
    scene.set_transform(group, Transform { x: 30., y: 5. });
    scene.set_effects(
        group,
        Effects {
            opacity: 0.25,
            ..Default::default()
        },
    );
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 0);
    assert_eq!(stats.layer_cache_hits, 1);
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(10 * 80 + 42) * 4..(10 * 80 + 42) * 4 + 4],
        &[0, 0, 64, 64]
    );
    assert_eq!(&p[..4], &[0, 0, 0, 0]);
    scene.set_kind(top, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 1);
    let partial = gpu.readback().unwrap();
    gpu.render(&scene, &[Rect::new(0., 0., 80., 40.)]).unwrap();
    assert_eq!(partial, gpu.readback().unwrap());
    scene.remove(group);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().layer_textures, 0);
    assert!(gpu.readback().unwrap().iter().all(|b| *b == 0));
}

#[test]
fn nested_layers_apply_opacity_at_each_boundary_and_invalidate_ancestors() {
    let mut gpu = GpuRenderer::new(64, 40).unwrap();
    let mut scene = Scene::new(64., 40.);
    let outer = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(30., 30.),
    );
    scene.set_isolated(outer, true);
    scene.set_effects(
        outer,
        Effects {
            opacity: 0.5,
            ..Default::default()
        },
    );
    let inner = scene.append(outer, NodeKind::Container(Layout::Overlay), fixed(20., 20.));
    scene.set_isolated(inner, true);
    scene.set_effects(
        inner,
        Effects {
            opacity: 0.5,
            ..Default::default()
        },
    );
    let red = scene.append(
        inner,
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(20., 20.),
    );
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 2);
    assert_eq!(&gpu.readback().unwrap()[..4], &[64, 0, 0, 64]);
    scene.set_transform(inner, Transform { x: 5., y: 5. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 1);
    assert_eq!(stats.layer_cache_hits, 1);
    scene.set_kind(red, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 2);
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(10 * 64 + 10) * 4..(10 * 64 + 10) * 4 + 4],
        &[0, 64, 0, 64]
    );
}

#[test]
fn isolated_overflow_and_fractional_translation_reuse_content() {
    let mut gpu = GpuRenderer::new(64, 40).unwrap();
    let mut scene = Scene::new(64., 40.);
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(10., 10.),
    );
    scene.set_isolated(group, true);
    let child = scene.append(
        group,
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(20., 12.),
    );
    scene.set_transform(child, Transform { x: -5., y: 0. });
    scene.set_transform(group, Transform { x: 15., y: 5. });
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let p = gpu.readback().unwrap();
    assert_eq!(
        &p[(8 * 64 + 11) * 4..(8 * 64 + 11) * 4 + 4],
        &[255, 0, 0, 255]
    );
    scene.set_transform(group, Transform { x: 15.5, y: 5. });
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 0);
    let half = gpu.readback().unwrap();
    assert_ne!(p, half);
    scene.set_transform(group, Transform { x: 15.75, y: 5. });
    let d = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &d).unwrap().layer_repaints, 0);
    assert_ne!(half, gpu.readback().unwrap());
    scene.set_isolated(group, false);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert_eq!(gpu.debug_cache_stats().layer_textures, 0);
}

#[test]
fn layer_texture_budget_fails_before_allocation_and_recovers_after_removal() {
    let mut gpu = GpuRenderer::new(8, 8).unwrap();
    let mut scene = Scene::new(8., 8.);
    let huge = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(4096., 4096.),
    );
    scene.set_isolated(huge, true);
    let d = scene.flush().damage;
    assert!(gpu.render(&scene, &d).unwrap_err().0.contains("64 MiB"));
    assert_eq!(gpu.debug_cache_stats().layer_bytes, 0);
    scene.remove(huge);
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    assert!(gpu.readback().unwrap().iter().all(|p| *p == 0));
}

#[test]
fn blur_inside_isolated_layer_rebuilds_on_backdrop_mutation() {
    let mut gpu = GpuRenderer::new(48, 32).unwrap();
    let mut scene = Scene::new(48., 32.);
    let group = scene.append(
        scene.root(),
        NodeKind::Container(Layout::Overlay),
        fixed(48., 32.),
    );
    scene.set_isolated(group, true);
    scene.append(group, NodeKind::Rect(Color(0, 0, 0, 255)), fixed(48., 32.));
    let behind = scene.append(
        group,
        NodeKind::Rect(Color(255, 255, 255, 255)),
        fixed(24., 32.),
    );
    let blur = scene.append(group, NodeKind::Rect(Color(255, 0, 0, 24)), fixed(48., 32.));
    scene.set_effects(
        blur,
        Effects {
            blur_radius: 3.,
            ..Default::default()
        },
    );
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let before = gpu.readback().unwrap();
    scene.set_kind(behind, NodeKind::Rect(Color(0, 255, 0, 255)));
    let d = scene.flush().damage;
    let stats = gpu.render(&scene, &d).unwrap();
    assert_eq!(stats.layer_repaints, 1);
    assert_eq!(stats.layer_texture_allocations, 0);
    let after = gpu.readback().unwrap();
    assert!(before != after);
    gpu.render(&scene, &[Rect::new(0., 0., 48., 32.)]).unwrap();
    assert!(after == gpu.readback().unwrap());
}

#[test]
fn shared_device_and_fonts_outlive_individual_renderers_with_lazy_atlases() {
    use zgui_gpu::GpuContext;
    let context = GpuContext::new().unwrap();
    let fonts = std::rc::Rc::downgrade(&context.text_system());
    let mut first = GpuRenderer::new_with_context(32, 32, &context).unwrap();
    let mut second = GpuRenderer::new_with_context(32, 32, &context).unwrap();
    assert!(first.context().shares_device(&second.context()));
    assert!(std::rc::Rc::ptr_eq(
        &first.text_system(),
        &second.text_system()
    ));
    assert_eq!(first.debug_cache_stats().atlas_bytes, 4);
    assert_eq!(second.debug_cache_stats().atlas_bytes, 4);
    let mut scene = Scene::new(32., 32.);
    scene.append(
        scene.root(),
        NodeKind::Rect(Color(255, 0, 0, 255)),
        fixed(32., 32.),
    );
    let d = scene.flush().damage;
    first.render(&scene, &d).unwrap();
    assert_eq!(first.debug_cache_stats().atlas_bytes, 4);
    assert_eq!(&first.readback().unwrap()[..4], &[255, 0, 0, 255]);
    drop(first);
    drop(context);
    assert!(fonts.upgrade().is_some());
    scene.set_kind(
        scene.root(),
        NodeKind::Text {
            text: "A".into(),
            font_size: 14.,
            color: Color(255, 255, 255, 255),
        },
    );
    let d = scene.flush().damage;
    second.render(&scene, &d).unwrap();
    assert_eq!(second.debug_cache_stats().atlas_bytes, 512 * 512 * 4);
    second.readback().unwrap();
    drop(second);
    assert!(fonts.upgrade().is_none());
}

#[test]
fn glyph_atlas_grows_only_when_a_frame_needs_more_capacity() {
    let mut gpu = GpuRenderer::new(800, 800).unwrap();
    let mut scene = Scene::new(800., 800.);
    scene.append(
        scene.root(),
        NodeKind::Text {
            text: "W".into(),
            font_size: 700.,
            color: Color(255, 255, 255, 255),
        },
        fixed(800., 800.),
    );
    let d = scene.flush().damage;
    gpu.render(&scene, &d).unwrap();
    let cache = gpu.debug_cache_stats();
    assert!(cache.atlas_bytes >= 1024 * 1024 * 4);
    assert!(cache.atlas_bytes <= 2048 * 2048 * 4);
    assert!(gpu.readback().unwrap().iter().any(|p| *p > 0));
    let stats = gpu
        .render(&scene, &[Rect::new(0., 0., 800., 800.)])
        .unwrap();
    assert_eq!(stats.glyph_uploads, 0);
    assert_eq!(stats.geometry_rebuilds, 0);
}

#[test]
fn decorated_container_paints_background_before_children() {
    let mut gpu = GpuRenderer::new(64, 64).unwrap();
    let mut scene = Scene::new(64., 64.);
    let panel = scene.append(
        scene.root(),
        NodeKind::Panel {
            layout: Layout::Row,
            quad: QuadStyle {
                fill: Color(20, 40, 60, 255),
                radius: 4.,
                border_color: Color(200, 100, 0, 255),
                border_width: 2.,
                ..Default::default()
            },
        },
        Style {
            padding_edges: Some(Insets {
                left: 10.,
                top: 12.,
                right: 3.,
                bottom: 5.,
            }),
            ..fixed(40., 40.)
        },
    );
    scene.append(panel, NodeKind::Rect(Color(255, 0, 0, 255)), fixed(8., 8.));
    let damage = scene.flush().damage;
    gpu.render(&scene, &damage).unwrap();
    let pixels = gpu.readback().unwrap();
    let at = |x: usize, y: usize| &pixels[(y * 64 + x) * 4..(y * 64 + x) * 4 + 4];
    assert_eq!(at(6, 6), &[20, 40, 60, 255]);
    assert_eq!(at(12, 14), &[255, 0, 0, 255]);
    assert_eq!(at(20, 1), &[200, 100, 0, 255]);
}

#[test]
fn composed_fluent_styles_render_and_repaint_without_relayout() {
    use zgui::{
        compose::{column, text},
        style::{Styled, Styles, rgb},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(128, 64).unwrap();
    let mut ui = Ui::new(128., 64.);
    let color = ui.signal(rgb(0x204060));
    let read = color.clone();
    let view = ui.mount(
        column()
            .size(128., 64.)
            .p(8.)
            .text_color(rgb(0xffffff))
            .text_size(20.)
            .reactive_style(move || Styles::new().bg(read.get()))
            .child(text("Hello").id("label")),
    );
    let label = view.find("label").unwrap();
    let initial_bounds;
    {
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        initial_bounds = scene.bounds(label);
        gpu.render(&scene, &damage).unwrap();
    }
    let first = gpu.readback().unwrap();
    assert_eq!(
        &first[(60 * 128 + 120) * 4..(60 * 128 + 120) * 4 + 4],
        &[32, 64, 96, 255]
    );
    assert!(
        first
            .chunks_exact(4)
            .any(|p| p[0] > 220 && p[1] > 220 && p[2] > 220),
        "composed text must render over the panel"
    );
    color.set(rgb(0x603020));
    {
        let mut scene = ui.scene.borrow_mut();
        let report = scene.flush();
        assert_eq!(report.layout_nodes, 0);
        assert_eq!(scene.bounds(label), initial_bounds);
        gpu.render(&scene, &report.damage).unwrap();
    }
    let second = gpu.readback().unwrap();
    assert_eq!(
        &second[(60 * 128 + 120) * 4..(60 * 128 + 120) * 4 + 4],
        &[96, 48, 32, 255]
    );
    gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 64.)])
        .unwrap();
    assert_eq!(
        second,
        gpu.readback().unwrap(),
        "damage repaint matches full composition"
    );
}

#[test]
fn fluent_text_padding_and_background_render_as_one_box() {
    use zgui::{
        compose::text,
        style::{Styled, rgb},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(96, 48).unwrap();
    let mut ui = Ui::new(96., 48.);
    let mounted = ui.mount(
        text("A")
            .p(8.)
            .bg(rgb(0x206040))
            .text_color(rgb(0xffffff))
            .text_size(20.),
    );
    let mut scene = ui.scene.borrow_mut();
    let report = scene.flush();
    let outer = scene.bounds(mounted.node());
    let children = scene.children(mounted.node());
    assert_eq!(children.len(), 1);
    let inner = scene.bounds(children[0]);
    assert_eq!(inner.x, outer.x + 8.);
    assert_eq!(inner.y, outer.y + 8.);
    assert_eq!(outer.width, inner.width + 16.);
    assert_eq!(outer.height, inner.height + 16.);
    gpu.render(&scene, &report.damage).unwrap();
    let pixels = gpu.readback().unwrap();
    assert_eq!(
        &pixels[(2 * 96 + 2) * 4..(2 * 96 + 2) * 4 + 4],
        &[32, 96, 64, 255]
    );
    assert!(
        pixels
            .chunks_exact(4)
            .any(|p| p[0] > 220 && p[1] > 220 && p[2] > 220)
    );
}

#[test]
fn font_selection_changes_pixels_and_measurement_without_stale_cached_glyphs() {
    use zgui::text_layout::{FontFamily, FontStyle, TextLayout};
    let mut gpu = GpuRenderer::new(360, 80).unwrap();
    let mut scene = Scene::new(360., 80.);
    let fonts = gpu.text_system();
    let shared = fonts.clone();
    scene.set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut shared.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let id = scene.append(
        scene.root(),
        NodeKind::Text {
            text: "Hamburgefonts ffi".into(),
            color: Color(255, 255, 255, 255),
            font_size: 24.,
        },
        Style::default(),
    );
    let default_damage = scene.flush().damage;
    assert_eq!(gpu.render(&scene, &default_damage).unwrap().shaped_nodes, 1);
    let regular = gpu.readback().unwrap();
    let mut previous = regular.clone();
    for font in [
        FontStyle {
            weight: 700,
            ..Default::default()
        },
        FontStyle {
            italic: true,
            ..Default::default()
        },
        FontStyle {
            family: FontFamily::Monospace,
            ..Default::default()
        },
        FontStyle {
            family: FontFamily::Serif,
            weight: 700,
            italic: true,
        },
    ] {
        scene.set_font(id, font.clone());
        let report = scene.flush();
        assert!(report.layout_nodes > 0);
        let measured = scene.measure_text_with_font("Hamburgefonts ffi", 24., None, &font);
        assert_eq!(scene.bounds(id).width, measured.0);
        assert_eq!(gpu.render(&scene, &report.damage).unwrap().shaped_nodes, 1);
        let pixels = gpu.readback().unwrap();
        assert_ne!(
            pixels, previous,
            "font change must affect rasterized pixels"
        );
        assert_eq!(
            gpu.render(&scene, &[Rect::new(0., 0., 360., 80.)])
                .unwrap()
                .shaped_nodes,
            0
        );
        assert_eq!(gpu.readback().unwrap(), pixels);
        scene.set_font(id, font);
        assert!(scene.flush().is_idle());
        previous = pixels;
    }
    scene.set_font(id, FontStyle::default());
    let damage = scene.flush().damage;
    gpu.render(&scene, &damage).unwrap();
    assert_eq!(gpu.readback().unwrap(), regular);
}

#[test]
fn declarative_editors_keep_styled_text_caret_and_selection_correct_when_resized() {
    use zgui::{
        compose::{column, text_area, text_input},
        input::{InputEvent, Key, Modifiers},
        style::{Styled, Styles, rgb},
        text_layout::{FontFamily, FontStyle, TextLayout},
        widgets::Ui,
    };
    let mut gpu = GpuRenderer::new(320, 200).unwrap();
    let mut ui = Ui::new(320., 200.);
    let fonts = gpu.text_system();
    ui.scene.borrow_mut().set_font_text_shaper(
        move |text: &str, size, width, font: &FontStyle| -> Box<dyn TextLayout> {
            Box::new(zgui_gpu::text::ShapedText::with_font(
                &mut fonts.borrow_mut(),
                text,
                size,
                width,
                font,
            ))
        },
    );
    let value = ui.signal("MMMM WWWW iii 0123".to_owned());
    let multiline = ui.signal("First line\nSecond line\nThird line".to_owned());
    let weight = ui.signal(700);
    let inherited_weight = weight.clone();
    let width = ui.signal(280.);
    let height = ui.signal(108.);
    let input_width = width.clone();
    let area_width = width.clone();
    let area_height = height.clone();
    let mounted = ui.mount(
        column()
            .size(320., 200.)
            .gap(8.)
            .bg(rgb(0x101820))
            .text_color(rgb(0xff4020))
            .text_size(22.)
            .font_family(FontFamily::Monospace)
            .reactive_style(move || Styles::new().font_weight(inherited_weight.get()))
            .child(
                text_input("Name", value.clone())
                    .id("input")
                    .h(44.)
                    .p(6.)
                    .bg(rgb(0x203040))
                    .rounded(0.)
                    .reactive_style(move || Styles::new().w(input_width.get())),
            )
            .child(
                text_area("Details", multiline.clone())
                    .id("area")
                    .p(6.)
                    .bg(rgb(0x203040))
                    .rounded(0.)
                    .reactive_style(move || Styles::new().w(area_width.get()).h(area_height.get())),
            ),
    );
    let render = |ui: &Ui, gpu: &mut GpuRenderer| {
        ui.prepare_frame();
        let mut scene = ui.scene.borrow_mut();
        let damage = scene.flush().damage;
        gpu.render(&scene, &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&scene, &[Rect::new(0., 0., 320., 200.)])
            .unwrap();
        assert!(
            partial == gpu.readback().unwrap(),
            "incremental editor damage must reconstruct the full frame"
        );
        partial
    };
    let initial = render(&ui, &mut gpu);
    assert!(
        initial
            .chunks_exact(4)
            .filter(|p| p[0] > 200 && p[1] < 100 && p[2] < 80)
            .count()
            > 100,
        "inherited foreground must color actual glyph pixels"
    );
    weight.set(400);
    let regular = render(&ui, &mut gpu);
    assert!(
        regular != initial,
        "changing inherited font weight must change actual editor glyphs"
    );
    weight.set(700);
    assert!(
        render(&ui, &mut gpu) == initial,
        "restoring inherited typography restores both editors"
    );
    for id in ["input", "area"] {
        ui.input.focus(&ui.scene, Some(mounted.find(id).unwrap()));
        ui.dispatch(InputEvent::KeyDown {
            key: Key::End,
            modifiers: Modifiers::default(),
            repeat: false,
        });
        let pixels = render(&ui, &mut gpu);
        let editor = ui.focused_editor().unwrap();
        let caret = ui.scene.borrow().bounds(editor.caret);
        let x = caret.x.round() as usize;
        let y = (caret.y + caret.height / 2.).floor() as usize;
        let at = (y * 320 + x) * 4;
        assert!(
            pixels[at] > 200 && pixels[at + 1] < 100,
            "caret must inherit the red foreground: {:?}",
            &pixels[at..at + 4]
        );
        for _ in 0..4 {
            ui.dispatch(InputEvent::KeyDown {
                key: Key::ArrowLeft,
                modifiers: Modifiers {
                    shift: true,
                    ..Default::default()
                },
                repeat: false,
            });
        }
        let selected = render(&ui, &mut gpu);
        assert_ne!(
            selected, pixels,
            "keyboard selection must change rendered pixels"
        );
        assert!(!editor.copy().is_empty());
        assert!(
            selected.chunks_exact(4).any(|p| p[0].abs_diff(48) <= 1
                && p[1].abs_diff(81) <= 1
                && p[2].abs_diff(127) <= 1),
            "selection background must alpha-composite over the styled editor surface"
        );
        // Only allocation changes: neither text nor selection is reassigned.
        for (w, h) in [(110., 48.), (280., 108.), (150., 64.), (280., 108.)] {
            width.set(w);
            height.set(h);
            let resized = render(&ui, &mut gpu);
            if w == 280. {
                assert!(
                    resized == selected,
                    "growing the {id} editor restores its exact selection and text pixels"
                );
            }
        }
        ui.dispatch(InputEvent::Text("X".into()));
        assert_ne!(
            render(&ui, &mut gpu),
            selected,
            "editing selected text must repaint"
        );
    }
}

#[test]
fn declarative_virtual_rows_clip_padding_and_repair_scroll_damage() {
    use zgui::{compose::prelude::*, widgets::Ui};
    let mut gpu = GpuRenderer::new(128, 96).unwrap();
    let mut ui = Ui::new(128., 96.);
    let offset = ui.signal(0.);
    let height = ui.signal(80.);
    let read_height = height.clone();
    ui.mount(
        virtual_list(
            offset.clone(),
            20.,
            2,
            || 100_000,
            |i| i,
            |_, key, _| {
                div().size(112., 20.).bg(if key.is_multiple_of(2) {
                    rgb(0xee3322)
                } else {
                    rgb(0x2244ee)
                })
            },
        )
        .w(128.)
        .p(8.)
        .bg(rgb(0x102030))
        .reactive_style(move || Styles::new().h(read_height.get())),
    );
    for (scroll, viewport_height) in [
        (0., 80.),
        (13., 80.),
        (56013., 80.),
        (56013., 60.),
        (1999900., 80.),
        (0., 80.),
    ] {
        height.set(viewport_height);
        offset.set(scroll);
        ui.prepare_frame();
        let damage = ui.scene.borrow_mut().flush().damage;
        gpu.render(&ui.scene.borrow(), &damage).unwrap();
        let partial = gpu.readback().unwrap();
        gpu.render(&ui.scene.borrow(), &[Rect::new(0., 0., 128., 96.)])
            .unwrap();
        assert_eq!(
            partial,
            gpu.readback().unwrap(),
            "scroll {scroll} height {viewport_height}"
        );
        let pixel = |x: usize, y: usize| &partial[(y * 128 + x) * 4..(y * 128 + x) * 4 + 4];
        assert_eq!(
            pixel(64, 4),
            &[16, 32, 48, 255],
            "rows must not paint top padding"
        );
        assert_eq!(
            pixel(64, viewport_height as usize - 4),
            &[16, 32, 48, 255],
            "rows must not paint bottom padding"
        );
        let key = ((offset.get() + 2.) / 20.).floor() as usize;
        assert_eq!(
            pixel(64, 10),
            if key.is_multiple_of(2) {
                &[238, 51, 34, 255]
            } else {
                &[34, 68, 238, 255]
            }
        );
        assert!(ui.scene.borrow().paint_items().count() < 100);
    }
}
