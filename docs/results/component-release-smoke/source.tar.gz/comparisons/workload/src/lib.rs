//! Identical bounded deterministic work and geometry for all three adapters.
use std::{fmt::Write, ops::Range, time::Duration};
pub const WIDTH: f32 = 960.0;
pub const HEIGHT: f32 = 720.0;
pub const ROW_HEIGHT: f32 = 28.0;
pub const ROW_COUNT: usize = 100_000;
pub const VIEWPORT_HEIGHT: f32 = 400.0;
pub const PERIOD: Duration = Duration::from_nanos(16_666_667);
pub const TOKEN: &str = "The quick brown fox streams a token. ";
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    Idle,
    Stream,
    Scroll,
    Both,
}
impl Mode {
    pub fn from_env() -> Self {
        match std::env::var("ZGUI_MODE").as_deref() {
            Ok("idle") => Self::Idle,
            Ok("stream") => Self::Stream,
            Ok("scroll") => Self::Scroll,
            _ => Self::Both,
        }
    }
}
pub struct Workload {
    pub text: String,
    pub scroll_offset: f32,
    pub frames: u64,
    pub mode: Mode,
    pub seconds: f64,
}
impl Default for Workload {
    fn default() -> Self {
        Self::from_env()
    }
}
impl Workload {
    pub fn from_env() -> Self {
        let mut work = Self {
            text: String::with_capacity(8256),
            scroll_offset: 0.,
            frames: 0,
            mode: Mode::from_env(),
            seconds: std::env::var("ZGUI_SECONDS")
                .ok()
                .and_then(|v| v.parse::<f64>().ok())
                .filter(|v| v.is_finite() && *v >= 0.)
                .unwrap_or(30.),
        };
        let initial_ticks = std::env::var("ZGUI_INITIAL_TICKS")
            .ok()
            .and_then(|v| v.parse::<u64>().ok())
            .unwrap_or(0)
            .min(100_000);
        let mode = work.mode;
        work.mode = Mode::Both;
        for _ in 0..initial_ticks {
            work.tick();
        }
        work.mode = mode;
        work
    }
    pub fn tick(&mut self) {
        self.frames += 1;
        if matches!(self.mode, Mode::Stream | Mode::Both) {
            write!(self.text, "{:06} {TOKEN}", self.frames).unwrap();
            if self.text.len() > 8192 {
                self.text.drain(..self.text.len() - 8192);
            }
        }
        if matches!(self.mode, Mode::Scroll | Mode::Both) {
            self.scroll_offset =
                (self.scroll_offset + 14.) % (ROW_COUNT as f32 * ROW_HEIGHT - VIEWPORT_HEIGHT);
        }
    }
    pub fn row_range(&self) -> Range<usize> {
        let first = (self.scroll_offset / ROW_HEIGHT) as usize;
        first.saturating_sub(2)..(first + 18).min(ROW_COUNT)
    }
    pub fn visible_text(&self) -> String {
        self.text.as_bytes()[self.text.len().saturating_sub(735)..]
            .chunks(105)
            .take(7)
            .map(|s| std::str::from_utf8(s).unwrap())
            .collect::<Vec<_>>()
            .join("\n")
    }
}
pub fn row_label(index: usize) -> String {
    format!("Row {index:06} — retained virtual item")
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bounded_and_deterministic() {
        let mut w = Workload::from_env();
        w.mode = Mode::Both;
        for _ in 0..10_000 {
            let before = w.visible_text();
            w.tick();
            assert!(w.text.len() <= 8192);
            assert!(w.row_range().len() <= 20);
            assert_ne!(before, w.visible_text());
        }
        assert_eq!(w.scroll_offset, 140_000.);
    }
}
