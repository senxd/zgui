//! Platform-independent shaped text geometry consumed by editors and selection widgets.
use crate::scene::Rect;
use std::ops::Range;
use unicode_segmentation::UnicodeSegmentation;
/// Portable font selection. Named families fall back through the platform font database.
#[derive(Clone, Debug, Default, PartialEq, Eq, Hash)]
pub enum FontFamily {
    #[default]
    SansSerif,
    Serif,
    Monospace,
    Named(std::sync::Arc<str>),
}
impl From<&str> for FontFamily {
    fn from(value: &str) -> Self {
        Self::Named(value.into())
    }
}
impl From<String> for FontFamily {
    fn from(value: String) -> Self {
        Self::Named(value.into())
    }
}
/// Logical line-box pitch. Normal uses `ceil(font_size * 1.4)`.
///
/// Positive finite pixel values are preserved, including pitches smaller than
/// glyph ink. Text still obeys its allocated paint bounds: tight lines may
/// overlap internally and ink at the outer text-box edges may be clipped.
/// Private normalized bits give font caches stable equality and hashing.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub struct LineHeight(u32);
impl LineHeight {
    pub const NORMAL: Self = Self(0);

    /// Invalid, zero, or negative values reset the normal line pitch.
    pub fn px(value: f32) -> Self {
        if value.is_finite() && value > 0. {
            Self(value.to_bits())
        } else {
            Self::NORMAL
        }
    }

    pub fn pixels(self) -> Option<f32> {
        (self != Self::NORMAL).then(|| f32::from_bits(self.0))
    }

    pub fn resolve(self, font_size: f32) -> f32 {
        self.pixels().unwrap_or_else(|| {
            let size = if font_size.is_finite() {
                font_size.max(1.)
            } else {
                1.
            };
            (size * 1.4).min(f32::MAX).ceil()
        })
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct FontStyle {
    pub family: FontFamily,
    /// OpenType weight in the inclusive range 1..=1000 (400 regular, 700 bold).
    pub weight: u16,
    pub italic: bool,
    pub line_height: LineHeight,
}
impl Default for FontStyle {
    fn default() -> Self {
        Self {
            family: FontFamily::SansSerif,
            weight: 400,
            italic: false,
            line_height: LineHeight::NORMAL,
        }
    }
}
/// Font-aware shaping callback. The legacy TextShaper remains available for default fonts.
pub trait FontTextShaper {
    fn shape(
        &self,
        text: &str,
        size: f32,
        width: Option<f32>,
        font: &FontStyle,
    ) -> Box<dyn TextLayout>;
}
impl<F: Fn(&str, f32, Option<f32>, &FontStyle) -> Box<dyn TextLayout>> FontTextShaper for F {
    fn shape(
        &self,
        text: &str,
        size: f32,
        width: Option<f32>,
        font: &FontStyle,
    ) -> Box<dyn TextLayout> {
        self(text, size, width, font)
    }
}
/// Which side of a shared cluster or soft-wrap boundary owns a caret.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum TextAffinity {
    /// Trailing edge of the preceding logical cluster; upstream at a soft wrap.
    Before,
    /// Leading edge of the following logical cluster; downstream at a soft wrap.
    #[default]
    After,
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct TextPosition {
    /// UTF-8 byte offset on a grapheme boundary.
    pub byte_offset: usize,
    pub affinity: TextAffinity,
}
pub trait TextLayout {
    fn size(&self) -> (f32, f32);
    /// Returns a UTF-8 byte offset on a grapheme boundary.
    fn hit_test(&self, x: f32, y: f32) -> usize;
    fn caret(&self, byte_offset: usize) -> Rect;
    /// Visual spans may be disjoint for bidirectional text.
    fn selection(&self, range: Range<usize>) -> Vec<Rect>;
    /// Affinity-aware geometry; defaults preserve compatibility with custom shapers.
    fn hit_position(&self, x: f32, y: f32) -> TextPosition {
        TextPosition {
            byte_offset: self.hit_test(x, y),
            affinity: TextAffinity::After,
        }
    }
    fn caret_position(&self, position: TextPosition) -> Rect {
        self.caret(position.byte_offset)
    }
    /// Physical left/right edge of the caret's visual line, excluding line endings.
    fn visual_line_edge(&self, position: TextPosition, end: bool) -> TextPosition {
        let caret = self.caret_position(position);
        self.hit_position(
            if end { f32::MAX } else { -f32::MAX },
            caret.y + caret.height * 0.5,
        )
    }
}
pub trait TextShaper {
    fn shape(&self, text: &str, font_size: f32, max_width: Option<f32>) -> Box<dyn TextLayout>;
}
impl<F: Fn(&str, f32, Option<f32>) -> Box<dyn TextLayout>> TextShaper for F {
    fn shape(&self, text: &str, font_size: f32, max_width: Option<f32>) -> Box<dyn TextLayout> {
        self(text, font_size, max_width)
    }
}
/// Approximate grapheme cells for headless/core use. Native hosts install a real shaper.
pub struct FallbackTextLayout {
    cells: Vec<(Range<usize>, Rect)>,
    end: Rect,
    size: (f32, f32),
}
impl FallbackTextLayout {
    pub fn new(text: &str, size: f32, max_width: Option<f32>) -> Self {
        Self::with_line_height(text, size, max_width, LineHeight::NORMAL)
    }
    pub fn with_line_height(
        text: &str,
        size: f32,
        max_width: Option<f32>,
        line_height: LineHeight,
    ) -> Self {
        let mut cells = Vec::new();
        let (end, size) = Self::place(text, size, max_width, line_height, |range, rect| {
            cells.push((range, rect))
        });
        Self { cells, end, size }
    }
    /// Measurement shares shaping's grapheme placement with O(1) auxiliary memory.
    pub fn measure(
        text: &str,
        size: f32,
        max_width: Option<f32>,
        line_height: LineHeight,
    ) -> (f32, f32) {
        Self::place(text, size, max_width, line_height, |_, _| {}).1
    }
    fn place(
        text: &str,
        size: f32,
        max_width: Option<f32>,
        line_height: LineHeight,
        mut cell: impl FnMut(Range<usize>, Rect),
    ) -> (Rect, (f32, f32)) {
        let advance = size.max(1.) * 0.6;
        let height = line_height.resolve(size);
        let mut x = 0.;
        let mut y = 0.;
        let mut width = 0_f32;
        for (index, grapheme) in text.grapheme_indices(true) {
            if grapheme.contains(['\n', '\r']) {
                cell(index..index + grapheme.len(), Rect::new(x, y, 0., height));
                width = width.max(x);
                x = 0.;
                y += height;
                continue;
            }
            if max_width.is_some_and(|w| w > 0. && x > 0. && x + advance > w) {
                width = width.max(x);
                x = 0.;
                y += height
            }
            cell(
                index..index + grapheme.len(),
                Rect::new(x, y, advance, height),
            );
            x += advance;
        }
        width = width.max(x);
        (Rect::new(x, y, 1., height), (width, y + height))
    }
}
impl TextLayout for FallbackTextLayout {
    fn size(&self) -> (f32, f32) {
        self.size
    }
    fn hit_test(&self, x: f32, y: f32) -> usize {
        self.hit_position(x, y).byte_offset
    }
    fn hit_position(&self, x: f32, y: f32) -> TextPosition {
        let y = y.max(0.);
        let mut result = TextPosition::default();
        for (range, r) in &self.cells {
            if y >= r.y && y < r.y + r.height {
                if r.width == 0. || x < r.x + r.width * 0.5 {
                    return TextPosition {
                        byte_offset: range.start,
                        affinity: TextAffinity::After,
                    };
                }
                result = TextPosition {
                    byte_offset: range.end,
                    affinity: TextAffinity::Before,
                };
            } else if y >= r.y + r.height {
                result = TextPosition {
                    byte_offset: range.end,
                    affinity: TextAffinity::After,
                };
            }
        }
        result
    }
    fn caret_position(&self, position: TextPosition) -> Rect {
        if position.affinity == TextAffinity::Before {
            for (range, rect) in &self.cells {
                if range.end == position.byte_offset && rect.width > 0. {
                    return Rect::new(rect.x + rect.width, rect.y, 1., rect.height);
                }
            }
        }
        self.caret(position.byte_offset)
    }
    fn caret(&self, byte_offset: usize) -> Rect {
        for (range, r) in &self.cells {
            if byte_offset <= range.start || range.contains(&byte_offset) {
                return Rect::new(r.x, r.y, 1., r.height);
            }
        }
        self.end
    }
    fn selection(&self, range: Range<usize>) -> Vec<Rect> {
        let start = range.start.min(range.end);
        let end = range.start.max(range.end);
        if start == end {
            return Vec::new();
        }
        let mut result: Vec<Rect> = Vec::new();
        for (index, r) in &self.cells {
            if index.start < end && index.end > start && r.width > 0. {
                if let Some(last) = result.last_mut()
                    && last.y == r.y
                    && last.x + last.width >= r.x
                {
                    *last = last.union(*r);
                    continue;
                }
                result.push(*r);
            }
        }
        result
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn line_height_normalization_hashing_and_tight_pitch() {
        use std::collections::HashSet;
        let invalid = [f32::NAN, f32::INFINITY, f32::NEG_INFINITY, -1., -0., 0.];
        let mut heights: HashSet<_> = invalid.into_iter().map(LineHeight::px).collect();
        assert_eq!(heights.len(), 1);
        assert!(heights.contains(&LineHeight::NORMAL));
        assert_eq!(LineHeight::NORMAL.resolve(10.), 14.);
        assert_eq!(LineHeight::NORMAL.resolve(11.), 16.);
        assert_eq!(LineHeight::NORMAL.resolve(f32::MAX), f32::MAX);
        assert!(LineHeight::NORMAL.resolve(f32::INFINITY).is_finite());
        heights.insert(LineHeight::px(14.));
        assert_eq!(
            heights.len(),
            2,
            "normal remains size-dependent, unlike explicit14px"
        );
        assert_eq!(LineHeight::px(0.5).resolve(40.), 0.5);
        assert_eq!(
            LineHeight::px(f32::from_bits(1)).pixels(),
            Some(f32::from_bits(1))
        );
    }
    #[test]
    fn explicit_pitch_keeps_wrapped_unicode_hit_selection_and_caret_aligned() {
        let layout = FallbackTextLayout::with_line_height(
            "a👩‍💻e\u{301}z\n",
            10.,
            Some(12.),
            LineHeight::px(7.5),
        );
        assert_eq!(layout.size(), (12., 22.5));
        assert_eq!(layout.caret(12), Rect::new(0., 7.5, 1., 7.5));
        assert_eq!(layout.hit_test(1., 8.), 12);
        assert_eq!(layout.caret(17), Rect::new(0., 15., 1., 7.5));
        assert_eq!(
            layout.selection(1..15),
            vec![Rect::new(6., 0., 6., 7.5), Rect::new(0., 7.5, 6., 7.5)]
        );
    }
    #[test]
    fn measurement_and_shape_agree_for_unbounded_and_tiny_widths() {
        for width in [
            None,
            Some(-1.),
            Some(0.),
            Some(f32::NAN),
            Some(f32::from_bits(1)),
            Some(6.),
        ] {
            for pitch in [LineHeight::NORMAL, LineHeight::px(0.5), LineHeight::px(30.)] {
                let text = "a👩‍💻e\u{301}\r\nz\n";
                let measured = FallbackTextLayout::measure(text, 10., width, pitch);
                assert_eq!(
                    measured,
                    FallbackTextLayout::with_line_height(text, 10., width, pitch).size()
                );
                assert!(measured.0 > 0. && measured.1 > 0. && measured.1.is_finite());
            }
        }
    }
    #[test]
    fn grapheme_offsets_newlines_and_wrap() {
        let layout = FallbackTextLayout::new("e\u{301}👩‍💻\nx", 10., None);
        assert_eq!(layout.hit_test(1., 2.), 0);
        assert_eq!(layout.hit_test(8., 2.), 3);
        assert_eq!(layout.caret(3).x, 6.);
        assert_eq!(layout.selection(0..3).len(), 1);
        assert_eq!(layout.size().1, 28.);
    }
    #[test]
    fn wrapped_grapheme_boundary_preserves_visual_affinity() {
        let layout = FallbackTextLayout::new("a👩‍💻e\u{301}z", 10., Some(12.));
        let end = layout.visual_line_edge(TextPosition::default(), true);
        assert_eq!(
            end,
            TextPosition {
                byte_offset: 12,
                affinity: TextAffinity::Before
            }
        );
        assert_eq!(layout.caret_position(end), Rect::new(12., 0., 1., 14.));
        let next = TextPosition {
            affinity: TextAffinity::After,
            ..end
        };
        assert_eq!(layout.caret_position(next), Rect::new(0., 14., 1., 14.));
        assert_eq!(layout.visual_line_edge(next, false), next);
        assert_eq!(layout.hit_position(100., 5.), end);
        assert_eq!(layout.hit_position(-10., 18.), next);
        assert_eq!(
            layout.selection(1..15),
            vec![Rect::new(6., 0., 6., 14.), Rect::new(0., 14., 6., 14.)]
        );
        assert!(layout.selection(2..2).is_empty());
    }
    #[test]
    fn visual_edges_exclude_crlf_and_preserve_empty_final_lines() {
        let layout = FallbackTextLayout::new("ab\r\n\n", 10., Some(30.));
        assert_eq!(layout.hit_test(100., 2.), 2);
        assert_eq!(layout.hit_test(100., 16.), 4);
        assert_eq!(layout.hit_test(100., 30.), 5);
        assert_eq!(layout.caret(5).y, 28.);
        assert_eq!(layout.hit_test(10., -10.), 2);
    }
}
