//! Native display refresh sources for [`zgui::frame::FrameClock`].
//!
//! macOS uses a per-view `CADisplayLink`, which follows the window across
//! displays and ProMotion rates. Wayland paces through compositor frame
//! callbacks (driven from the host's redraw requests). Everything else, and
//! any platform whose native source is unavailable, uses [`FrameTimer`]:
//! event-loop deadlines on a fixed grid at the display's reported refresh rate.
use std::time::{Duration, Instant};
use zgui::frame::Frame;

pub(crate) const DEFAULT_INTERVAL: Duration = Duration::from_nanos(16_666_667);
/// A native source that stops ticking while frames are wanted is backed up by
/// the timer after this long, so animations degrade instead of freezing.
pub(crate) const WATCHDOG: Duration = Duration::from_millis(250);

pub(crate) fn interval_for(refresh_hz: Option<f64>) -> Duration {
    refresh_hz
        .filter(|hz| hz.is_finite() && *hz >= 1.)
        .map_or(DEFAULT_INTERVAL, |hz| Duration::from_secs_f64(1. / hz))
}

/// Refresh-aligned deadlines without a native vsync signal. Ticks land on a
/// fixed grid from `epoch`, so a late wake-up does not drift later ticks.
pub(crate) struct FrameTimer {
    epoch: Instant,
}
impl FrameTimer {
    pub(crate) fn new(epoch: Instant) -> Self {
        Self { epoch }
    }
    fn index(&self, at: Instant, interval: Duration) -> u64 {
        (at.saturating_duration_since(self.epoch).as_secs_f64() / interval.as_secs_f64()) as u64
    }
    /// The first refresh boundary strictly after `now`.
    pub(crate) fn next_deadline(&self, now: Instant, interval: Duration) -> Instant {
        let next = self.index(now, interval) + 1;
        self.epoch + interval.mul_f64(next as f64)
    }
    /// The frame for the boundary at or before `now`. It is expected on screen
    /// one refresh later, once rendered.
    pub(crate) fn frame(&self, now: Instant, interval: Duration) -> Frame {
        let index = self.index(now, interval);
        Frame {
            index,
            time: self.epoch + interval.mul_f64((index + 1) as f64),
            interval,
        }
    }
}

#[cfg(target_os = "macos")]
pub(crate) use display_link::DisplayLink;

#[cfg(target_os = "macos")]
mod display_link {
    use super::*;
    use objc2::{
        DefinedClass, Encode, Encoding, MainThreadMarker, MainThreadOnly, define_class, msg_send,
        rc::Retained,
        runtime::{AnyClass, AnyObject, NSObject, NSObjectProtocol},
        sel,
    };
    use winit::{
        raw_window_handle::{HasWindowHandle, RawWindowHandle},
        window::Window,
    };

    #[link(name = "QuartzCore", kind = "framework")]
    unsafe extern "C" {
        fn CACurrentMediaTime() -> f64;
    }
    #[link(name = "Foundation", kind = "framework")]
    unsafe extern "C" {
        /// Run loops recognise the common-modes set by this exact object, not
        /// by its string value.
        static NSRunLoopCommonModes: *const AnyObject;
    }

    #[repr(C)]
    #[derive(Clone, Copy, PartialEq)]
    struct CAFrameRateRange {
        minimum: f32,
        maximum: f32,
        preferred: f32,
    }
    // SAFETY: Matches QuartzCore's `CAFrameRateRange` of three floats.
    unsafe impl Encode for CAFrameRateRange {
        const ENCODING: Encoding = Encoding::Struct(
            "CAFrameRateRange",
            &[Encoding::Float, Encoding::Float, Encoding::Float],
        );
    }

    pub(crate) struct Ivars {
        view: Retained<AnyObject>,
        deliver: Box<dyn Fn(Frame)>,
    }
    define_class!(
        #[unsafe(super(NSObject))]
        #[thread_kind = MainThreadOnly]
        #[ivars = Ivars]
        struct LinkTarget;
        unsafe impl NSObjectProtocol for LinkTarget {}
        impl LinkTarget {
            #[unsafe(method(tick:))]
            fn tick(&self, link: &AnyObject) {
                // SAFETY: CADisplayLink timing properties are plain doubles.
                let (target, duration): (f64, f64) =
                    unsafe { (msg_send![link, targetTimestamp], msg_send![link, duration]) };
                // SAFETY: Current media time is the display link's clock.
                let media_now = unsafe { CACurrentMediaTime() };
                let now = Instant::now();
                // Index against the display's maximum rate so a lowered
                // (ProMotion or capped) link still counts whole refreshes.
                let max_fps = self.max_fps().unwrap_or_else(|| (1. / duration.max(1e-3)).round());
                let interval = Duration::from_secs_f64(1. / max_fps.max(1.));
                (self.ivars().deliver)(Frame {
                    index: (target * max_fps).round().max(0.) as u64,
                    time: now + Duration::from_secs_f64((target - media_now).clamp(0., 1.)),
                    interval,
                });
            }
        }
    );
    impl LinkTarget {
        fn max_fps(&self) -> Option<f64> {
            // SAFETY: NSView -window, NSWindow -screen and NSScreen
            // -maximumFramesPerSecond (macOS 12+) on the main thread.
            unsafe {
                let window: Option<Retained<AnyObject>> = msg_send![&*self.ivars().view, window];
                let screen: Option<Retained<AnyObject>> = msg_send![&*window?, screen];
                let screen = screen?;
                if !screen.class().responds_to(sel!(maximumFramesPerSecond)) {
                    return None;
                }
                let fps: isize = msg_send![&*screen, maximumFramesPerSecond];
                (fps > 0).then_some(fps as f64)
            }
        }
    }

    /// A paused-by-default `CADisplayLink` bound to one window's view.
    pub(crate) struct DisplayLink {
        link: Retained<AnyObject>,
        _target: Retained<LinkTarget>,
        running: bool,
        range: Option<CAFrameRateRange>,
    }
    impl DisplayLink {
        /// `None` before macOS 14 or without an AppKit view; hosts fall back to
        /// the timer. `deliver` runs on the main thread once per refresh.
        pub(crate) fn new(window: &Window, deliver: impl Fn(Frame) + 'static) -> Option<Self> {
            let mtm = MainThreadMarker::new()?;
            let RawWindowHandle::AppKit(handle) = window.window_handle().ok()?.as_raw() else {
                return None;
            };
            // SAFETY: winit keeps this NSView alive while the window exists;
            // retaining it keeps it valid for the link's lifetime.
            let view: Retained<AnyObject> =
                unsafe { Retained::retain(handle.ns_view.as_ptr().cast())? };
            if !view
                .class()
                .responds_to(sel!(displayLinkWithTarget:selector:))
            {
                return None;
            }
            let target = LinkTarget::alloc(mtm).set_ivars(Ivars {
                view: view.clone(),
                deliver: Box::new(deliver),
            });
            // SAFETY: NSObject initializer on our allocated main-thread class.
            let target: Retained<LinkTarget> = unsafe { msg_send![super(target), init] };
            // SAFETY: -[NSView displayLinkWithTarget:selector:] (macOS 14+),
            // checked above; `tick:` takes the link as its only argument.
            let link: Option<Retained<AnyObject>> = unsafe {
                msg_send![&*view, displayLinkWithTarget: &*target, selector: sel!(tick:)]
            };
            let link = link?;
            let run_loop_class = AnyClass::get(c"NSRunLoop")?;
            // SAFETY: Scheduling a new display link on the main run loop in
            // the common modes, which keep ticking during live resize and menu
            // tracking. Foundation's constant is a valid immortal NSString.
            unsafe {
                let _: () = msg_send![&*link, setPaused: true];
                let main: Retained<AnyObject> = msg_send![run_loop_class, mainRunLoop];
                let common = &*NSRunLoopCommonModes;
                let _: () = msg_send![&*link, addToRunLoop: &*main, forMode: common];
            }
            Some(Self {
                link,
                _target: target,
                running: false,
                range: None,
            })
        }
        pub(crate) fn running(&self) -> bool {
            self.running
        }
        pub(crate) fn set_running(&mut self, running: bool) {
            if self.running != running {
                self.running = running;
                // SAFETY: CADisplayLink paused property.
                unsafe {
                    let _: () = msg_send![&*self.link, setPaused: !running];
                }
            }
        }
        /// Ask the display for at most `hz` refreshes while animating, letting
        /// ProMotion panels drop their rate. `None` restores the default.
        pub(crate) fn set_preferred_rate(&mut self, hz: Option<f64>) {
            let range = hz.map(|hz| {
                let hz = hz.clamp(1., 1000.) as f32;
                CAFrameRateRange {
                    minimum: (hz / 2.).max(1.),
                    maximum: hz,
                    preferred: hz,
                }
            });
            if self.range == range {
                return;
            }
            self.range = range;
            let range = range.unwrap_or(CAFrameRateRange {
                minimum: 0.,
                maximum: 0.,
                preferred: 0.,
            });
            if self
                .link
                .class()
                .responds_to(sel!(setPreferredFrameRateRange:))
            {
                // SAFETY: CADisplayLink preferredFrameRateRange (macOS 14+).
                unsafe {
                    let _: () = msg_send![&*self.link, setPreferredFrameRateRange: range];
                }
            }
        }
    }
    impl Drop for DisplayLink {
        fn drop(&mut self) {
            // The run loop retains the link, and the link retains its target,
            // until it is invalidated.
            // SAFETY: CADisplayLink invalidate on the main thread.
            unsafe {
                let _: () = msg_send![&*self.link, invalidate];
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn timer_ticks_on_a_fixed_grid_after_late_wakeups() {
        let epoch = Instant::now();
        let timer = FrameTimer::new(epoch);
        let interval = Duration::from_millis(10);
        assert_eq!(timer.next_deadline(epoch, interval), epoch + interval);
        // Waking 3 ms late still schedules the following boundary on the grid.
        let late = epoch + Duration::from_millis(13);
        assert_eq!(timer.next_deadline(late, interval), epoch + interval * 2);
        let frame = timer.frame(late, interval);
        assert_eq!(frame.index, 1);
        assert_eq!(frame.time, epoch + interval * 2);
        assert_eq!(frame.interval, interval);
    }

    #[test]
    fn missing_or_bogus_refresh_rates_fall_back_to_60_hz() {
        assert_eq!(interval_for(None), DEFAULT_INTERVAL);
        assert_eq!(interval_for(Some(0.)), DEFAULT_INTERVAL);
        assert_eq!(interval_for(Some(f64::NAN)), DEFAULT_INTERVAL);
        assert_eq!(interval_for(Some(120.)), Duration::from_secs_f64(1. / 120.));
    }
}
