//! Immutable display text with continuous UTF-8 styled runs.
use crate::{scene::Color, text_layout::FontStyle};
use std::{ops::Range, sync::Arc};
pub(crate) type RichShaper =
    dyn Fn(&RichText, Option<f32>) -> Box<dyn crate::text_layout::TextLayout>;
pub(crate) type RichMeasurer = dyn Fn(&RichText, Option<f32>) -> (f32, f32);

/// A solid text decoration. An unspecified color uses the run foreground.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Decoration {
    pub color: Option<Color>,
    thickness: f32,
}
impl Decoration {
    pub fn new(thickness: f32) -> Self {
        Self {
            color: None,
            thickness: if thickness.is_finite() && thickness > 0. {
                thickness
            } else {
                1.
            },
        }
    }
    pub fn color(mut self, color: Color) -> Self {
        self.color = Some(color);
        self
    }
    pub fn thickness(self) -> f32 {
        self.thickness
    }
}
impl Default for Decoration {
    fn default() -> Self {
        Self::new(1.)
    }
}

/// One resolved style over a contiguous UTF-8 byte range.
#[derive(Clone, Debug, PartialEq)]
pub struct TextRun {
    pub range: Range<usize>,
    pub font: FontStyle,
    pub font_size: f32,
    pub color: Color,
    pub background: Option<Color>,
    pub underline: Option<Decoration>,
    pub strikethrough: Option<Decoration>,
}

impl Default for TextRun {
    fn default() -> Self {
        Self {
            range: 0..0,
            font: Default::default(),
            font_size: 16.,
            color: Color(255, 255, 255, 255),
            background: None,
            underline: None,
            strikethrough: None,
        }
    }
}

/// Validated, immutable styled display text. Runs cover the entire string exactly;
/// empty strings use no runs. Adjacent styles may cross grapheme boundaries: the
/// native shaper still shapes the paragraph continuously.
#[derive(Clone, Debug, PartialEq)]
pub struct RichText {
    options: crate::text_layout::TextOptions,
    text: Arc<str>,
    runs: Arc<[TextRun]>,
}
impl RichText {
    pub fn new(
        text: impl Into<Arc<str>>,
        runs: impl Into<Arc<[TextRun]>>,
    ) -> Result<Self, &'static str> {
        let text = text.into();
        let runs = runs.into();
        let mut end = 0;
        for run in runs.iter() {
            if run.range.start != end
                || run.range.end <= end
                || run.range.end > text.len()
                || !text.is_char_boundary(run.range.start)
                || !text.is_char_boundary(run.range.end)
            {
                return Err("rich text runs must cover contiguous nonempty UTF-8 ranges");
            }
            if !run.font_size.is_finite() || run.font_size <= 0. {
                return Err("rich text font size must be finite and positive");
            }
            end = run.range.end;
        }
        if end != text.len() {
            return Err("rich text runs must cover the entire string");
        }
        Ok(Self {
            text,
            runs,
            options: Default::default(),
        })
    }
    pub fn with_options(mut self, options: crate::text_layout::TextOptions) -> Self {
        self.options = options;
        self
    }
    pub fn options(&self) -> crate::text_layout::TextOptions {
        self.options
    }
    pub(crate) fn same_metrics(&self, other: &Self) -> bool {
        self.options == other.options
            && self.text == other.text
            && self.runs.len() == other.runs.len()
            && self
                .runs
                .iter()
                .zip(other.runs.iter())
                .all(|(a, b)| a.range == b.range && a.font == b.font && a.font_size == b.font_size)
    }
    pub fn text(&self) -> &str {
        &self.text
    }
    pub fn text_arc(&self) -> Arc<str> {
        self.text.clone()
    }
    /// Conservative payload accounting for bounded caches; shared font names may
    /// be charged more than once. Excludes allocator and font-engine overhead.
    pub fn storage_bytes(&self) -> usize {
        self.text
            .len()
            .saturating_add(std::mem::size_of_val(self.runs.as_ref()))
            .saturating_add(
                self.runs
                    .iter()
                    .map(|run| run.font.storage_bytes())
                    .fold(0usize, usize::saturating_add),
            )
    }
    pub fn runs(&self) -> &[TextRun] {
        &self.runs
    }
}

/// Approximate, allocation-free headless metrics. Native hosts replace this with
/// full paragraph shaping; grapheme widths here follow the fallback text model.
pub fn fallback_measure(rich: &RichText, width: Option<f32>) -> (f32, f32) {
    use unicode_segmentation::UnicodeSegmentation;
    if rich.text.is_empty() {
        return (0., 0.);
    }
    let mut run_index = 0;
    let limit = rich
        .options
        .line_clamp
        .map(|n| n.get())
        .or((rich.options.overflow == crate::text_layout::TextOverflow::Ellipsis).then_some(1));
    let mut row = 1;
    let (mut x, mut y, mut max_x, mut pitch) = (0_f32, 0_f32, 0_f32, 0_f32);
    for (index, grapheme) in rich.text.grapheme_indices(true) {
        while rich.runs[run_index].range.end <= index {
            run_index += 1;
        }
        let run = &rich.runs[run_index];
        let line = run.font.line_height.resolve(run.font_size);
        if grapheme == "\n" || grapheme == "\r\n" || grapheme == "\r" {
            if limit.is_some_and(|limit| row >= limit) {
                return (
                    width.map_or(max_x.max(x), |w| {
                        max_x
                            .max(
                                x + if rich.options.overflow
                                    == crate::text_layout::TextOverflow::Ellipsis
                                {
                                    run.font_size * 0.6
                                } else {
                                    0.
                                },
                            )
                            .min(w.max(0.))
                    }),
                    y + pitch.max(line),
                );
            }
            row += 1;
            max_x = max_x.max(x);
            y += pitch.max(line);
            x = 0.;
            pitch = line;
            continue;
        }
        let advance = (run.font_size * 0.6 + run.font.letter_spacing.pixels()).max(0.);
        if width.is_some_and(|w| x > 0. && x + advance > w.max(0.)) {
            if limit.is_some_and(|limit| row >= limit) {
                return (
                    width.unwrap().max(0.).min(max_x.max(
                        x + if rich.options.overflow == crate::text_layout::TextOverflow::Ellipsis {
                            advance
                        } else {
                            0.
                        },
                    )),
                    y + pitch,
                );
            }
            row += 1;
            max_x = max_x.max(x);
            y += pitch;
            x = 0.;
            pitch = 0.;
        }
        pitch = pitch.max(line);
        x += advance;
    }
    (max_x.max(x), y + pitch)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn run(range: Range<usize>) -> TextRun {
        TextRun {
            range,
            font: Default::default(),
            font_size: 16.,
            color: Color(255, 255, 255, 255),
            ..Default::default()
        }
    }
    #[test]
    fn validates_unicode_coverage_sizes_and_empty_text() {
        assert!(RichText::new("é字", vec![run(0..2), run(2..5)]).is_ok());
        for ranges in [
            vec![0..1, 1..5],
            vec![0..2, 3..5],
            std::iter::once(0..2).collect(),
            vec![0..0, 0..5],
        ] {
            assert!(RichText::new("é字", ranges.into_iter().map(run).collect::<Vec<_>>()).is_err());
        }
        assert!(RichText::new("", Vec::new()).is_ok());
        for size in [0., -1., f32::NAN, f32::INFINITY] {
            let mut r = run(0..1);
            r.font_size = size;
            assert!(RichText::new("x", vec![r]).is_err());
        }
    }
}
