//! Bounded retained SVG pixels, shared by GPU and software renderers.
use crate::GpuError;
use std::{collections::HashMap, sync::Arc};
use zgui::{
    image::ImageData,
    scene::{NodeId, NodeKind, Scene},
    svg::SvgData,
};
const MAX_ENTRIES: usize = 1024;
struct Entry {
    source_id: u64,
    tint: Option<zgui::scene::Color>,
    width: u32,
    height: u32,
    image: Arc<ImageData>,
    transformed: Arc<ImageData>,
    used: u64,
}
#[derive(Default)]
pub struct SvgCache {
    entries: HashMap<NodeId, Entry>,
    bytes: usize,
    clock: u64,
    rasterizations: u64,
}
impl SvgCache {
    pub fn retain(&mut self, scene: &Scene) {
        self.entries.retain(|node, _| {
            scene.contains(*node) && matches!(scene.kind(*node), NodeKind::Svg(_))
        });
        self.bytes = self.entries.values().map(|e| e.image.pixels().len()).sum();
    }
    pub fn image_ids(&self) -> impl Iterator<Item = u64> + '_ {
        self.entries.values().map(|e| e.image.id())
    }
    pub fn bytes(&self) -> usize {
        self.bytes
    }
    pub fn rasterizations(&self) -> u64 {
        self.rasterizations
    }
    pub fn get(
        &mut self,
        node: NodeId,
        source: &Arc<SvgData>,
        width: f32,
        height: f32,
        scale: f32,
    ) -> Result<Arc<ImageData>, GpuError> {
        if ![width, height, scale]
            .iter()
            .all(|v| v.is_finite() && *v > 0.)
        {
            return Err(GpuError("invalid SVG size".into()));
        }
        let (width, height) = (
            (width * scale).ceil() as u32,
            (height * scale).ceil() as u32,
        );
        if (u64::from(width) * u64::from(height))
            .checked_mul(4)
            .is_none_or(|bytes| bytes > 32 * 1024 * 1024)
        {
            return Err(GpuError("SVG raster exceeds 32 MiB".into()));
        }
        self.clock = self.clock.wrapping_add(1);
        if let Some(entry) = self.entries.get_mut(&node)
            && entry.source_id == source.source_id()
            && entry.tint == source.tint()
            && (entry.width, entry.height) == (width, height)
        {
            entry.used = self.clock;
            if entry.transformed.transform() != source.transform() {
                entry.transformed = Arc::new(entry.image.transformed(source.transform()));
            }
            return Ok(entry.transformed.clone());
        }
        let mut image = crate::assets::decode_svg(source.bytes(), width, height)?;
        if let Some(color) = source.tint() {
            let mut pixels = image.pixels().to_vec();
            for p in pixels.chunks_exact_mut(4) {
                p[0] = color.0;
                p[1] = color.1;
                p[2] = color.2;
                p[3] = ((u16::from(p[3]) * u16::from(color.3) + 127) / 255) as u8;
            }
            image =
                Arc::new(ImageData::new(width, height, pixels).map_err(|e| GpuError(e.into()))?);
        }
        if let Some(old) = self.entries.remove(&node) {
            self.bytes -= old.image.pixels().len();
        }
        let bytes = image.pixels().len();
        while (self.bytes + bytes > 32 * 1024 * 1024 || self.entries.len() >= MAX_ENTRIES)
            && !self.entries.is_empty()
        {
            let victim = *self.entries.iter().min_by_key(|(_, e)| e.used).unwrap().0;
            self.bytes -= self.entries.remove(&victim).unwrap().image.pixels().len();
        }
        self.bytes += bytes;
        self.rasterizations += 1;
        let transformed = if source.transform() == image.transform() {
            image.clone()
        } else {
            Arc::new(image.transformed(source.transform()))
        };
        self.entries.insert(
            node,
            Entry {
                source_id: source.source_id(),
                tint: source.tint(),
                width,
                height,
                image: image.clone(),
                transformed: transformed.clone(),
                used: self.clock,
            },
        );
        Ok(transformed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn unchanged_svg_reuses_transformed_handle_without_rasterization() {
        let mut scene = Scene::new(100., 100.);
        let source=Arc::new(SvgData::new(&b"<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10'><rect width='10' height='10' fill='red'/></svg>"[..]).unwrap());
        let node = scene.append(
            scene.root(),
            NodeKind::Svg(source.clone()),
            Default::default(),
        );
        let mut cache = SvgCache::default();
        let first = cache.get(node, &source, 20., 20., 1.).unwrap();
        let second = cache.get(node, &source, 20., 20., 1.).unwrap();
        assert!(Arc::ptr_eq(&first, &second));
        let rotated = Arc::new(source.transformed(zgui::affine::Affine::rotation(0.5)));
        let third = cache.get(node, &rotated, 20., 20., 1.).unwrap();
        assert!(!Arc::ptr_eq(&first, &third));
        let fourth = cache.get(node, &rotated, 20., 20., 1.).unwrap();
        assert!(Arc::ptr_eq(&third, &fourth));
        assert_eq!(cache.rasterizations(), 1);
    }
    #[test]
    fn removed_svg_source_drops_before_next_paint_and_transform_keeps_pixels() {
        let mut scene = Scene::new(100., 100.);
        let bytes:Arc<[u8]>=Arc::from(&b"<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10'><rect width='10' height='10'/></svg>"[..]);
        let source = Arc::new(SvgData::new(bytes.clone()).unwrap());
        let weak = Arc::downgrade(&source);
        let transformed = Arc::new(source.transformed(zgui::affine::Affine::rotation(0.3)));
        let node = scene.append(
            scene.root(),
            NodeKind::Svg(source.clone()),
            Default::default(),
        );
        let mut cache = SvgCache::default();
        let first = cache.get(node, &source, 20., 20., 1.).unwrap();
        scene.set_kind(node, NodeKind::Svg(transformed.clone()));
        drop(source);
        assert!(weak.upgrade().is_none());
        let second = cache.get(node, &transformed, 20., 20., 1.).unwrap();
        assert_eq!(first.id(), second.id());
        assert_eq!(cache.rasterizations(), 1);
        scene.remove(node);
        drop(transformed);
        assert_eq!(
            Arc::strong_count(&bytes),
            1,
            "cache must not keep SVG byte storage alive"
        );
        assert!(
            cache.bytes() > 0,
            "test runs before next render retention pass"
        );
    }
    #[test]
    fn tiny_svg_rasters_obey_entry_count_and_lru_limit() {
        let mut scene = Scene::new(100., 100.);
        let source = Arc::new(
            SvgData::new(&b"<svg xmlns='http://www.w3.org/2000/svg' width='1' height='1'/>"[..])
                .unwrap(),
        );
        let mut cache = SvgCache::default();
        let mut first = None;
        for _ in 0..=MAX_ENTRIES {
            let node = scene.append(
                scene.root(),
                NodeKind::Svg(source.clone()),
                Default::default(),
            );
            first.get_or_insert(node);
            cache.get(node, &source, 1., 1., 1.).unwrap();
        }
        assert_eq!(cache.entries.len(), MAX_ENTRIES);
        assert_eq!(cache.bytes(), MAX_ENTRIES * 4);
        assert!(!cache.entries.contains_key(&first.unwrap()));
    }
}
