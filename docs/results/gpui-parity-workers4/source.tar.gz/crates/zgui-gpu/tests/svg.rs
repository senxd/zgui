use std::sync::Arc;
use zgui::{affine::Affine, scene::*, svg::SvgData};
use zgui_gpu::GpuRenderer;
fn data() -> Arc<SvgData> {
    Arc::new(SvgData::new(&br##"<svg xmlns="http://www.w3.org/2000/svg" width="2" height="1"><rect width="1" height="1" fill="red"/><rect x="1" width="1" height="1" fill="green"/></svg>"##[..]).unwrap())
}
#[test]
fn svg_resizes_at_device_scale_tints_and_transforms_without_reupload() {
    let mut scene = Scene::new(140., 120.);
    scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
    let source = data();
    let node = scene.append(
        scene.root(),
        NodeKind::Svg(source.clone()),
        Style {
            width: Some(40.),
            height: Some(20.),
            ..Default::default()
        },
    );
    scene.set_transform(node, Transform { x: 40., y: 40. });
    let mut gpu = GpuRenderer::new(140, 120).unwrap();
    let report = scene.flush();
    let stats = gpu.render(&scene, &report.damage).unwrap();
    assert_eq!(stats.svg_rasterizations, 1);
    assert_eq!(stats.image_uploads, 1);
    scene.set_kind(
        node,
        NodeKind::Svg(Arc::new(
            source.transformed(Affine::rotation(std::f32::consts::FRAC_PI_2)),
        )),
    );
    let report = scene.flush();
    assert_eq!(report.layout_nodes, 0);
    let stats = gpu.render(&scene, &report.damage).unwrap();
    assert_eq!(stats.svg_rasterizations, 0);
    assert_eq!(stats.image_uploads, 0);
    let pixels = gpu.readback().unwrap();
    assert_eq!(&pixels[(35 * 140 + 60) * 4..][..3], &[255, 0, 0]);
    let mut fresh = GpuRenderer::new(140, 120).unwrap();
    fresh
        .render(&scene, &[Rect::new(0., 0., 140., 120.)])
        .unwrap();
    assert_eq!(pixels, fresh.readback().unwrap());
    scene.set_kind(
        node,
        NodeKind::Svg(Arc::new(source.tinted(Color(20, 40, 255, 255)))),
    );
    let report = scene.flush();
    assert_eq!(
        gpu.render(&scene, &report.damage)
            .unwrap()
            .svg_rasterizations,
        1
    );
    let pixels = gpu.readback().unwrap();
    assert_eq!(&pixels[(45 * 140 + 50) * 4..][..3], &[20, 40, 255]);
    gpu.set_scale_factor(2.);
    gpu.render(&scene, &[Rect::new(0., 0., 140., 120.)])
        .unwrap();
    assert_eq!(gpu.debug_cache_stats().svg_raster_bytes, 80 * 40 * 4);
    scene.remove(node);
    let report = scene.flush();
    gpu.render(&scene, &report.damage).unwrap();
    assert_eq!(gpu.debug_cache_stats().svg_raster_bytes, 0);
}
