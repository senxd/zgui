use std::sync::Arc;
use zgui::{canvas::GradientStop, decoration::*, scene::*};
use zgui_gpu::GpuRenderer;
fn style(angle: f32) -> QuadStyle {
    QuadStyle {
        fill: Color(20, 40, 80, 255),
        border_color: Color(255, 255, 255, 255),
        decoration: Some(Arc::new(Decoration {
            background: Some(Background::Linear {
                angle,
                stops: vec![
                    GradientStop {
                        offset: 0.,
                        color: Color(255, 0, 0, 255),
                    },
                    GradientStop {
                        offset: 1.,
                        color: Color(0, 0, 255, 255),
                    },
                ]
                .into(),
            }),
            corners: Some(Corners {
                top_left: 20.,
                top_right: 3.,
                bottom_right: 14.,
                bottom_left: 0.,
            }),
            border_widths: Some(Insets {
                left: 8.,
                right: 2.,
                top: 4.,
                bottom: 6.,
            }),
            shadows: Some(
                vec![
                    BoxShadow {
                        color: Color(0, 255, 0, 180),
                        offset: Transform { x: -12., y: 0. },
                        blur_radius: 2.,
                        spread: 1.,
                    },
                    BoxShadow {
                        color: Color(255, 0, 255, 180),
                        offset: Transform { x: 12., y: 0. },
                        blur_radius: 2.,
                        spread: 1.,
                    },
                ]
                .into(),
            ),
            ..Default::default()
        })),
        ..Default::default()
    }
}
#[test]
fn detailed_panels_cache_resize_and_restore_all_shadow_extents() {
    for isolated in [false, true] {
        let mut scene = Scene::new(160., 130.);
        scene.set_kind(scene.root(), NodeKind::Container(Layout::Overlay));
        let node = scene.append(
            scene.root(),
            NodeKind::Quad(style(0.)),
            Style {
                width: Some(80.),
                height: Some(70.),
                ..Default::default()
            },
        );
        scene.set_transform(node, Transform { x: 40., y: 30. });
        scene.set_isolated(node, isolated);
        let mut gpu = GpuRenderer::new(160, 130).unwrap();
        let report = scene.flush();
        let stats = gpu.render(&scene, &report.damage).unwrap();
        assert_eq!(stats.canvas_rasterizations, 1);
        let data = gpu.readback().unwrap();
        let pixel = |x: usize, y: usize| &data[(y * 160 + x) * 4..][..4];
        assert!(pixel(50, 65)[0] > 200);
        assert!(pixel(110, 65)[2] > 200);
        assert!(pixel(42, 70)[0] > 245 && pixel(42, 70)[1] > 245);
        assert!(pixel(30, 60)[1] > 50);
        assert!(pixel(128, 60)[0] > 50 && pixel(128, 60)[2] > 50);
        let stats = gpu
            .render(&scene, &[Rect::new(0., 0., 160., 130.)])
            .unwrap();
        assert_eq!(stats.canvas_rasterizations, 0);
        assert_eq!(stats.image_uploads, 0);
        let mut changed = style(1.);
        Arc::make_mut(changed.decoration.as_mut().unwrap()).border_style = BorderStyle::Dashed {
            length: 8.,
            gap: 5.,
        };
        scene.set_kind(node, NodeKind::Quad(changed));
        let report = scene.flush();
        assert_eq!(report.layout_nodes, 0);
        gpu.render(&scene, &report.damage).unwrap();
        let mut fresh = GpuRenderer::new(160, 130).unwrap();
        fresh
            .render(&scene, &[Rect::new(0., 0., 160., 130.)])
            .unwrap();
        assert_eq!(gpu.readback().unwrap(), fresh.readback().unwrap());
        scene.set_kind(
            node,
            NodeKind::Quad(QuadStyle {
                fill: Color(10, 20, 30, 255),
                ..Default::default()
            }),
        );
        let report = scene.flush();
        gpu.render(&scene, &report.damage).unwrap();
        let mut fresh = GpuRenderer::new(160, 130).unwrap();
        fresh
            .render(&scene, &[Rect::new(0., 0., 160., 130.)])
            .unwrap();
        assert_eq!(gpu.readback().unwrap(), fresh.readback().unwrap());
        assert_eq!(gpu.debug_cache_stats().canvas_raster_bytes, 0);
    }
}
