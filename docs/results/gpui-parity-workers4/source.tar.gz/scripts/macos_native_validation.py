#!/usr/bin/env python3
"""Mac-only validation bundle. Automated GPU/host checks plus explicit manual UI checks.

Run on a logged-in macOS desktop. --interactive additionally launches native
menu/dialog and accessibility fixtures for operator verification. Omitting it
leaves those checks pending, never reported as passed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--target-dir', type=Path, default=Path('target'))
    parser.add_argument('--interactive', action='store_true')
    args = parser.parse_args()
    if platform.system() != 'Darwin':
        parser.error('This bundle requires an actual macOS host; cross-compilation is not runtime validation.')
    root = Path(__file__).resolve().parents[1]
    args.output = args.output.resolve()
    args.target_dir = args.target_dir.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, CARGO_TARGET_DIR=str(args.target_dir))
    results = {'status': 'running', 'platform': platform.platform(), 'automated': [], 'manual': [], 'binaries': {}}
    def run(name, command, timeout=600):
        try:
            with (args.output / (name + '.log')).open('w') as log:
                process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
        except subprocess.TimeoutExpired:
            results['automated'].append({'name': name, 'command': list(map(str, command)), 'exit_code': None, 'error': 'timeout', 'timeout_seconds': timeout})
            raise
        results['automated'].append({'name': name, 'command': list(map(str, command)), 'exit_code': process.returncode})
        if process.returncode:
            raise RuntimeError(f'{name} failed; inspect its retained log')
        return (args.output / (name + '.log')).read_text()
    try:
        run('metal-surface-tests', ['cargo', 'test', '-p', 'zgui-gpu', '--test', 'native_surfaces', '--locked', '--', '--test-threads=1'])
        run('accessibility-projection-tests', ['cargo', 'test', '-p', 'zgui-desktop', '--lib', 'accessibility::', '--locked'])
        examples = ['native_surfaces', 'rich_text', 'platform_services', 'dynamic_menus', 'atspi']
        command = ['cargo', 'build', '-p', 'zgui-desktop', '--locked']
        for example in examples:
            command += ['--example', example]
        run('build-fixtures', command)
        directory = args.target_dir / 'debug' / 'examples'
        for name in examples:
            results['binaries'][name] = hashlib.sha256((directory / name).read_bytes()).hexdigest()
        log = run('native-surfaces-window', [str(directory / 'native_surfaces'), '--smoke-test'], 30)
        assert re.findall(r'NATIVE_SURFACE frame=(\d+) nv12=(true|false)', log) == [('1', 'false'), ('2', 'true'), ('3', 'false'), ('4', 'true')], log
        log = run('rich-text-window', [str(directory / 'rich_text'), '--smoke-test'], 30)
        assert 'RICH_CLAMP height=56' in log, log
        checks = [
            ('platform_services', 'Open file, choose folder, save and cancel; native prompt answer; close an owner while its picker is open. Verify the selected path/result in the log.'),
            ('dynamic_menus', 'Use Cmd+B, Cmd+S, Cmd+R and Cmd+D as shown. Verify native menu checked/disabled state, command routing and menu replacement.'),
            ('atspi', 'Enable VoiceOver or Accessibility Inspector. Read static labels/editor text, change selection/value/checked state through accessibility, and verify disabled actions are rejected. This is the macOS AX check despite the fixture historical name.'),
            ('rich_text', 'Use Tab and Enter on the inline link; verify VoiceOver exposes a named clickable link and full unclipped paragraph text.'),
        ]
        checklist = []
        for example, instruction in checks:
            entry = {'fixture': example, 'instruction': instruction, 'status': 'pending'}
            checklist.append(f'- `{directory / example}`: {instruction}')
            if args.interactive:
                with (args.output / ('manual-' + example + '.log')).open('w') as log:
                    process = subprocess.Popen([str(directory / example)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
                    try:
                        print(instruction)
                        response = input('Record observed PASS, FAIL, or SKIP, followed by notes: ').strip()
                        entry.update(status='operator-report', report=response)
                    finally:
                        if process.poll() is None:
                            process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
            results['manual'].append(entry)
        (args.output / 'manual-validation.md').write_text('# Native Mac operator checks\n\nAutomation/VoiceOver permissions may be required. These are pending unless operator reports are recorded.\n\n' + '\n'.join(checklist) + '\n')
        results['status'] = 'automated-subset-passed'
        results['manual_qualification'] = 'operator-reports-recorded' if args.interactive else 'pending'
    except BaseException as error:
        results['status'] = 'failed'
        results['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        (args.output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print('Automated Mac subset passed. Inspect results.json for manual checks; pending checks are not parity proof.')


if __name__ == '__main__':
    main()
