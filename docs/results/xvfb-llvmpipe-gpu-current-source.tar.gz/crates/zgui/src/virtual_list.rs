//! Constant-space range calculation for fixed-height virtualized lists.
use std::ops::Range;

#[derive(Clone, Copy, Debug)]
pub struct VirtualList {
    pub count: usize,
    pub row_height: f32,
    pub overscan: usize,
}

impl VirtualList {
    pub fn new(count: usize, row_height: f32, overscan: usize) -> Self {
        assert!(row_height.is_finite() && row_height > 0.0);
        Self {
            count,
            row_height,
            overscan,
        }
    }
    pub fn content_height(&self) -> f32 {
        self.count as f32 * self.row_height
    }
    pub fn visible_range(&self, offset: f32, viewport_height: f32) -> Range<usize> {
        if self.count == 0 || !viewport_height.is_finite() || viewport_height <= 0.0 {
            return 0..0;
        }
        let offset = if offset.is_finite() {
            offset
                .max(0.0)
                .min((self.content_height() - viewport_height).max(0.0))
        } else {
            0.0
        };
        let first = (offset / self.row_height).floor() as usize;
        let end = ((offset + viewport_height) / self.row_height).ceil() as usize;
        first.saturating_sub(self.overscan)..end.saturating_add(self.overscan).min(self.count)
    }
    pub fn row_offset(&self, index: usize) -> f32 {
        index as f32 * self.row_height
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn million_rows_remain_bounded() {
        let list = VirtualList::new(1_000_000, 24.0, 3);
        for offset in [0.0, 5000.0, 24_000_000.0] {
            let range = list.visible_range(offset, 480.0);
            assert!(range.len() <= 27);
            assert!(range.end <= list.count);
        }
        assert_eq!(list.visible_range(0.0, 48.0), 0..5);
    }
    #[test]
    fn handles_empty_and_invalid_viewports() {
        assert_eq!(VirtualList::new(0, 20.0, 2).visible_range(0.0, 40.0), 0..0);
        assert_eq!(
            VirtualList::new(10, 20.0, 2).visible_range(0.0, f32::NAN),
            0..0
        );
    }
}
